-- Script para crear la tabla Productos en la base de datos abarrote
-- Ejecutar este script en SQL Server Management Studio

USE [abarrote]
GO

-- Eliminar la tabla si existe (opcional, para recrearla)
IF OBJECT_ID('dbo.Productos', 'U') IS NOT NULL
    DROP TABLE dbo.Productos
GO

-- Crear la tabla Productos
CREATE TABLE dbo.Productos (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Nombre NVARCHAR(100) NOT NULL,
    Descripcion NVARCHAR(500) NULL,
    CodigoBarras NVARCHAR(50) NULL,
    PrecioCosto DECIMAL(18,2) NOT NULL DEFAULT 0,
    PrecioVenta DECIMAL(18,2) NOT NULL DEFAULT 0,
    Departamento NVARCHAR(50) NULL,
    Hay INT NOT NULL DEFAULT 0,
    Minimo INT NOT NULL DEFAULT 0,
    Maximo INT NOT NULL DEFAULT 0,
    UsaInventario BIT NOT NULL DEFAULT 1,
    TipoVenta NVARCHAR(20) NOT NULL DEFAULT 'Unidad',
    FechaCreacion DATETIME NOT NULL DEFAULT GETDATE(),
    FechaActualizacion DATETIME NULL
)
GO

-- Insertar algunos datos de ejemplo (opcional)
INSERT INTO dbo.Productos (Nombre, Descripcion, CodigoBarras, PrecioCosto, PrecioVenta, Departamento, Hay, Minimo, Maximo, UsaInventario, TipoVenta)
VALUES 
('Refresco Coca-Cola 600ml', 'Refresco de cola original', '7501055502286', 12.50, 18.00, 'Bebidas', 50, 10, 100, 1, 'Unidad'),
('Papas Sabritas 45g', 'Papas de sabritas sabor original', '7501000301234', 8.00, 12.00, 'Botanas', 30, 5, 60, 1, 'Unidad'),
('Pan Bimbo Blanco', 'Pan de caja blanco grande', '7501000305678', 35.00, 45.00, 'Panadería', 20, 3, 40, 1, 'Unidad')
GO

-- Verificar que la tabla se creó correctamente
SELECT * FROM dbo.Productos
GO
