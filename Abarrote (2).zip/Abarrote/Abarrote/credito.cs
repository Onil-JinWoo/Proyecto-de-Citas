﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Abarrote
{
    public partial class credito : UserControl
    {
        private DataGridView _dgvClientes;
        private DataGridView _dgvDetalle;
        private int _idClienteSeleccionado;
        private string _nombreClienteSeleccionado;

        private Panel _pnlDetalleCuenta;
        private Label _lblDetalleNombre;
        private Label _lblDetalleSaldo;
        private DataGridView _dgvMovimientos;
        private DataGridView _dgvDetalleProductos;
        private Label _lblDetalleFolio;
        private Label _lblDetalleFecha;
        private Label _lblDetalleTotal;
        private Button _btnVolver;

        public credito()
        {
            InitializeComponent();

            this.Load += credito_Load;

            if (txtBusqueda != null)
                txtBusqueda.TextChanged += (s, e) => CargarClientes();
            if (btnAceptar != null)
                btnAceptar.Click += (s, e) => AbrirEstadoCuentaSeleccionado();
        }

        private void credito_Load(object sender, EventArgs e)
        {
            InicializarGrids();
            HookLayoutEvents();
            AjustarLayout();
            CargarClientes();
        }

        private void HookLayoutEvents()
        {
            if (panel1 != null)
                panel1.Resize -= Panel1_Resize;
            if (panel1 != null)
                panel1.Resize += Panel1_Resize;

            if (tabPage1 != null)
                tabPage1.Resize -= TabPage1_Resize;
            if (tabPage1 != null)
                tabPage1.Resize += TabPage1_Resize;
        }

        private void TabPage1_Resize(object sender, EventArgs e)
        {
            AjustarLayout();
        }

        private void Panel1_Resize(object sender, EventArgs e)
        {
            AjustarLayout();
        }

        private void AjustarLayout()
        {
            if (panel1 == null)
                return;

            panel1.Anchor = AnchorStyles.None;

            int targetW = Math.Max(520, (tabPage1 != null ? Math.Min(tabPage1.ClientSize.Width - 40, 720) : 520));
            int targetH = Math.Max(320, (tabPage1 != null ? Math.Min(tabPage1.ClientSize.Height - 40, 520) : 320));

            panel1.Size = new Size(targetW, targetH);

            if (tabPage1 != null)
            {
                int x = Math.Max(0, (tabPage1.ClientSize.Width - panel1.Width) / 2);
                int y = Math.Max(0, (tabPage1.ClientSize.Height - panel1.Height) / 2);
                panel1.Location = new Point(x, y);
            }

            int padding = 20;
            int btnH = btnAceptar != null ? btnAceptar.Height : 40;
            int btnW = btnAceptar != null ? btnAceptar.Width : 100;

            if (btnAceptar != null)
            {
                btnAceptar.Location = new Point((panel1.Width - btnW) / 2, panel1.Height - padding - btnH);
                btnAceptar.Anchor = AnchorStyles.Bottom;
            }

            if (_dgvClientes != null)
            {
                int top = _dgvClientes.Location.Y;
                int bottomLimit = (btnAceptar != null ? btnAceptar.Top : (panel1.Height - padding));
                int h = bottomLimit - top - 10;
                if (h < 80)
                    h = 80;

                _dgvClientes.Location = new Point(50, top);
                _dgvClientes.Size = new Size(panel1.Width - 100, h);
                _dgvClientes.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;
                _dgvClientes.ScrollBars = ScrollBars.Both;
            }
        }

        private void InicializarGrids()
        {
            if (_dgvClientes == null)
            {
                _dgvClientes = new DataGridView();
                _dgvClientes.AllowUserToAddRows = false;
                _dgvClientes.AllowUserToDeleteRows = false;
                _dgvClientes.ReadOnly = true;
                _dgvClientes.RowHeadersVisible = false;
                _dgvClientes.MultiSelect = false;
                _dgvClientes.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                _dgvClientes.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                _dgvClientes.Location = new Point(50, 150);
                _dgvClientes.Size = new Size(300, 120);
                _dgvClientes.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;
                _dgvClientes.CellClick += (s, e) => CapturarClienteSeleccionado();
                _dgvClientes.CellDoubleClick += (s, e) => AbrirEstadoCuentaSeleccionado();
                panel1.Controls.Add(_dgvClientes);
                _dgvClientes.BringToFront();

                _dgvClientes.ScrollBars = ScrollBars.Both;
            }

            if (_dgvDetalle == null)
            {
                _dgvDetalle = new DataGridView();
                _dgvDetalle.AllowUserToAddRows = false;
                _dgvDetalle.AllowUserToDeleteRows = false;
                _dgvDetalle.ReadOnly = true;
                _dgvDetalle.RowHeadersVisible = false;
                _dgvDetalle.MultiSelect = false;
                _dgvDetalle.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                _dgvDetalle.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                _dgvDetalle.Dock = DockStyle.Fill;
                tabPage2.Controls.Add(_dgvDetalle);
                _dgvDetalle.BringToFront();
            }
        }

        private void EnsureDetalleCuentaUi()
        {
            if (_pnlDetalleCuenta != null)
                return;

            _pnlDetalleCuenta = new Panel();
            _pnlDetalleCuenta.Dock = DockStyle.Fill;
            _pnlDetalleCuenta.BackColor = Color.White;
            _pnlDetalleCuenta.Visible = false;

            Panel pnlTop = new Panel();
            pnlTop.Dock = DockStyle.Top;
            pnlTop.Height = 80;
            pnlTop.Padding = new Padding(12, 10, 12, 10);
            pnlTop.BackColor = Color.White;

            Label lblTitulo = new Label();
            lblTitulo.Text = "ESTADO DE CUENTA";
            lblTitulo.Dock = DockStyle.Top;
            lblTitulo.Height = 26;
            lblTitulo.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblTitulo.ForeColor = Color.FromArgb(0, 122, 204);

            Panel pnlTopRow = new Panel();
            pnlTopRow.Dock = DockStyle.Fill;

            _btnVolver = new Button();
            _btnVolver.Text = "<";
            _btnVolver.Width = 36;
            _btnVolver.Height = 32;
            _btnVolver.Location = new Point(0, 10);
            _btnVolver.FlatStyle = FlatStyle.Flat;
            _btnVolver.FlatAppearance.BorderColor = Color.Silver;
            _btnVolver.Click += (s, e) => MostrarSelectorClientes();

            _lblDetalleNombre = new Label();
            _lblDetalleNombre.Text = "";
            _lblDetalleNombre.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            _lblDetalleNombre.AutoSize = false;
            _lblDetalleNombre.Location = new Point(44, 6);
            _lblDetalleNombre.Size = new Size(520, 34);
            _lblDetalleNombre.TextAlign = ContentAlignment.MiddleLeft;

            _lblDetalleSaldo = new Label();
            _lblDetalleSaldo.Text = "$0.00";
            _lblDetalleSaldo.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            _lblDetalleSaldo.ForeColor = Color.FromArgb(0, 150, 0);
            _lblDetalleSaldo.AutoSize = false;
            _lblDetalleSaldo.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            _lblDetalleSaldo.Location = new Point(600, 6);
            _lblDetalleSaldo.Size = new Size(200, 34);
            _lblDetalleSaldo.TextAlign = ContentAlignment.MiddleRight;

            pnlTopRow.Controls.Add(_btnVolver);
            pnlTopRow.Controls.Add(_lblDetalleNombre);
            pnlTopRow.Controls.Add(_lblDetalleSaldo);

            pnlTop.Controls.Add(pnlTopRow);
            pnlTop.Controls.Add(lblTitulo);

            Panel pnlActions = new Panel();
            pnlActions.Dock = DockStyle.Top;
            pnlActions.Height = 42;
            pnlActions.Padding = new Padding(12, 6, 12, 6);
            pnlActions.BackColor = Color.FromArgb(245, 245, 245);

            Button btnAbonar = new Button();
            btnAbonar.Text = "Abonar a deuda";
            btnAbonar.Width = 140;
            btnAbonar.Height = 28;
            btnAbonar.Location = new Point(12, 7);

            Button btnLiquidar = new Button();
            btnLiquidar.Text = "Liquidar";
            btnLiquidar.Width = 110;
            btnLiquidar.Height = 28;
            btnLiquidar.Location = new Point(160, 7);

            Button btnImprimir = new Button();
            btnImprimir.Text = "Imprimir Estado de Cuenta";
            btnImprimir.Width = 190;
            btnImprimir.Height = 28;
            btnImprimir.Location = new Point(278, 7);

            pnlActions.Controls.Add(btnAbonar);
            pnlActions.Controls.Add(btnLiquidar);
            pnlActions.Controls.Add(btnImprimir);

            Panel pnlBody = new Panel();
            pnlBody.Dock = DockStyle.Fill;
            pnlBody.BackColor = Color.White;

            Panel pnlRight = new Panel();
            pnlRight.Dock = DockStyle.Right;
            pnlRight.Width = 300;
            pnlRight.Padding = new Padding(10);
            pnlRight.BackColor = Color.FromArgb(248, 248, 248);

            Panel pnlRightTop = new Panel();
            pnlRightTop.Dock = DockStyle.Top;
            pnlRightTop.Height = 120;
            pnlRightTop.BackColor = Color.FromArgb(248, 248, 248);

            _lblDetalleFolio = new Label();
            _lblDetalleFolio.Text = "Folio: -";
            _lblDetalleFolio.Dock = DockStyle.Top;
            _lblDetalleFolio.Height = 22;

            _lblDetalleFecha = new Label();
            _lblDetalleFecha.Text = "Fecha: -";
            _lblDetalleFecha.Dock = DockStyle.Top;
            _lblDetalleFecha.Height = 22;

            Label lblCliente = new Label();
            lblCliente.Text = "Cliente: -";
            lblCliente.Dock = DockStyle.Top;
            lblCliente.Height = 22;

            pnlRightTop.Controls.Add(_lblDetalleFecha);
            pnlRightTop.Controls.Add(_lblDetalleFolio);
            pnlRightTop.Controls.Add(lblCliente);

            _dgvDetalleProductos = new DataGridView();
            _dgvDetalleProductos.Dock = DockStyle.Fill;
            _dgvDetalleProductos.AllowUserToAddRows = false;
            _dgvDetalleProductos.AllowUserToDeleteRows = false;
            _dgvDetalleProductos.ReadOnly = true;
            _dgvDetalleProductos.RowHeadersVisible = false;
            _dgvDetalleProductos.MultiSelect = false;
            _dgvDetalleProductos.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            _dgvDetalleProductos.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            Panel pnlRightBottom = new Panel();
            pnlRightBottom.Dock = DockStyle.Bottom;
            pnlRightBottom.Height = 110;
            pnlRightBottom.BackColor = Color.FromArgb(248, 248, 248);

            _lblDetalleTotal = new Label();
            _lblDetalleTotal.Text = "Total: $0.00";
            _lblDetalleTotal.Dock = DockStyle.Top;
            _lblDetalleTotal.Height = 22;
            _lblDetalleTotal.TextAlign = ContentAlignment.MiddleRight;

            Label lblPagoCon = new Label();
            lblPagoCon.Text = "Pago con: Crédito";
            lblPagoCon.Dock = DockStyle.Top;
            lblPagoCon.Height = 22;
            lblPagoCon.TextAlign = ContentAlignment.MiddleRight;

            Label lblPendiente = new Label();
            lblPendiente.Text = "Monto Pendiente: $0.00";
            lblPendiente.Dock = DockStyle.Top;
            lblPendiente.Height = 22;
            lblPendiente.TextAlign = ContentAlignment.MiddleRight;

            pnlRightBottom.Controls.Add(lblPendiente);
            pnlRightBottom.Controls.Add(lblPagoCon);
            pnlRightBottom.Controls.Add(_lblDetalleTotal);

            Panel pnlRightButtons = new Panel();
            pnlRightButtons.Dock = DockStyle.Bottom;
            pnlRightButtons.Height = 44;
            pnlRightButtons.BackColor = Color.FromArgb(248, 248, 248);

            Button btnReimprimir = new Button();
            btnReimprimir.Text = "Re-imprimir";
            btnReimprimir.Width = 90;
            btnReimprimir.Height = 28;
            btnReimprimir.Location = new Point(10, 8);

            Button btnFacturar = new Button();
            btnFacturar.Text = "Facturar";
            btnFacturar.Width = 80;
            btnFacturar.Height = 28;
            btnFacturar.Location = new Point(110, 8);

            Button btnCancelar = new Button();
            btnCancelar.Text = "Cancelar";
            btnCancelar.Width = 80;
            btnCancelar.Height = 28;
            btnCancelar.Location = new Point(200, 8);
            btnCancelar.Click += (s, e) => MostrarSelectorClientes();

            pnlRightButtons.Controls.Add(btnReimprimir);
            pnlRightButtons.Controls.Add(btnFacturar);
            pnlRightButtons.Controls.Add(btnCancelar);

            pnlRight.Controls.Add(_dgvDetalleProductos);
            pnlRight.Controls.Add(pnlRightButtons);
            pnlRight.Controls.Add(pnlRightBottom);
            pnlRight.Controls.Add(pnlRightTop);

            _dgvMovimientos = new DataGridView();
            _dgvMovimientos.Dock = DockStyle.Fill;
            _dgvMovimientos.AllowUserToAddRows = false;
            _dgvMovimientos.AllowUserToDeleteRows = false;
            _dgvMovimientos.ReadOnly = true;
            _dgvMovimientos.RowHeadersVisible = false;
            _dgvMovimientos.MultiSelect = false;
            _dgvMovimientos.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            _dgvMovimientos.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            _dgvMovimientos.CellClick += (s, e) => ActualizarResumenDesdeMovimientoSeleccionado();

            pnlBody.Controls.Add(_dgvMovimientos);
            pnlBody.Controls.Add(pnlRight);

            _pnlDetalleCuenta.Controls.Add(pnlBody);
            _pnlDetalleCuenta.Controls.Add(pnlActions);
            _pnlDetalleCuenta.Controls.Add(pnlTop);

            tabPage1.Controls.Add(_pnlDetalleCuenta);
            _pnlDetalleCuenta.BringToFront();
        }

        private void MostrarDetalleCuenta()
        {
            EnsureDetalleCuentaUi();

            if (panel1 != null)
                panel1.Visible = false;
            _pnlDetalleCuenta.Visible = true;

            _lblDetalleNombre.Text = string.IsNullOrWhiteSpace(_nombreClienteSeleccionado)
                ? ("Cliente #" + _idClienteSeleccionado.ToString())
                : _nombreClienteSeleccionado;

            DataTable dtMov = DatabaseHelper.ObtenerEstadoCuentaCliente(_idClienteSeleccionado, false);
            _dgvMovimientos.DataSource = dtMov;

            if (_dgvMovimientos.Columns.Contains("Monto"))
            {
                _dgvMovimientos.Columns["Monto"].DefaultCellStyle.Format = "C2";
                _dgvMovimientos.Columns["Monto"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            }

            decimal saldo = 0m;
            if (dtMov != null && dtMov.Columns.Contains("Monto"))
            {
                for (int i = 0; i < dtMov.Rows.Count; i++)
                {
                    object v = dtMov.Rows[i]["Monto"];
                    if (v != null && v != DBNull.Value)
                        saldo += Convert.ToDecimal(v);
                }
            }

            _lblDetalleSaldo.Text = saldo.ToString("C2", CultureInfo.CurrentCulture);
            _lblDetalleTotal.Text = "Total: " + saldo.ToString("C2", CultureInfo.CurrentCulture);

            DataTable dtProd = new DataTable();
            dtProd.Columns.Add("Cant.", typeof(int));
            dtProd.Columns.Add("Descripción", typeof(string));
            dtProd.Columns.Add("Importe", typeof(decimal));
            _dgvDetalleProductos.DataSource = dtProd;

            if (_dgvDetalleProductos.Columns.Contains("Importe"))
            {
                _dgvDetalleProductos.Columns["Importe"].DefaultCellStyle.Format = "C2";
                _dgvDetalleProductos.Columns["Importe"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            }

            if (_dgvMovimientos.Rows.Count > 0)
            {
                _dgvMovimientos.ClearSelection();
                _dgvMovimientos.Rows[0].Selected = true;
                ActualizarResumenDesdeMovimientoSeleccionado();
            }
        }

        private void MostrarSelectorClientes()
        {
            if (_pnlDetalleCuenta != null)
                _pnlDetalleCuenta.Visible = false;
            if (panel1 != null)
                panel1.Visible = true;

            HookLayoutEvents();
            AjustarLayout();
        }

        private void ActualizarResumenDesdeMovimientoSeleccionado()
        {
            if (_dgvMovimientos == null || _dgvMovimientos.SelectedRows == null || _dgvMovimientos.SelectedRows.Count == 0)
                return;

            DataGridViewRow row = _dgvMovimientos.SelectedRows[0];
            if (row == null)
                return;

            string folio = _dgvMovimientos.Columns.Contains("Folio") && row.Cells["Folio"].Value != null ? row.Cells["Folio"].Value.ToString() : "-";
            string fecha = _dgvMovimientos.Columns.Contains("Fecha/Hora") && row.Cells["Fecha/Hora"].Value != null ? row.Cells["Fecha/Hora"].Value.ToString() : "-";
            string monto = _dgvMovimientos.Columns.Contains("Monto") && row.Cells["Monto"].Value != null ? row.Cells["Monto"].Value.ToString() : "0";

            if (_lblDetalleFolio != null)
                _lblDetalleFolio.Text = "Folio: " + folio;
            if (_lblDetalleFecha != null)
                _lblDetalleFecha.Text = "Fecha: " + fecha;

            decimal tot = 0m;
            decimal.TryParse(monto, NumberStyles.Any, CultureInfo.CurrentCulture, out tot);
            if (tot <= 0m)
                decimal.TryParse(monto, NumberStyles.Any, CultureInfo.InvariantCulture, out tot);

            DataTable dtProd = new DataTable();
            dtProd.Columns.Add("Cant.", typeof(int));
            dtProd.Columns.Add("Descripción", typeof(string));
            dtProd.Columns.Add("Importe", typeof(decimal));
            dtProd.Rows.Add(1, "Venta folio #" + folio, tot);
            _dgvDetalleProductos.DataSource = dtProd;

            if (_dgvDetalleProductos.Columns.Contains("Importe"))
            {
                _dgvDetalleProductos.Columns["Importe"].DefaultCellStyle.Format = "C2";
                _dgvDetalleProductos.Columns["Importe"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            }
        }

        private void CargarClientes()
        {
            if (_dgvClientes == null)
                return;

            string q = txtBusqueda == null ? string.Empty : (txtBusqueda.Text ?? string.Empty).Trim();
            DataTable dt = DatabaseHelper.ObtenerClientesConSaldo(q, true, false);
            _dgvClientes.DataSource = dt;

            if (_dgvClientes.Columns.Contains("IdCliente"))
                _dgvClientes.Columns["IdCliente"].Visible = false;
            if (_dgvClientes.Columns.Contains("NombreCompleto"))
                _dgvClientes.Columns["NombreCompleto"].HeaderText = "Cliente";
            if (_dgvClientes.Columns.Contains("Saldo"))
            {
                _dgvClientes.Columns["Saldo"].HeaderText = "Saldo";
                _dgvClientes.Columns["Saldo"].DefaultCellStyle.Format = "C2";
                _dgvClientes.Columns["Saldo"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            }

            if (_dgvClientes.Rows.Count > 0)
            {
                _dgvClientes.ClearSelection();
                _dgvClientes.Rows[0].Selected = true;
                CapturarClienteSeleccionado();
            }
        }

        private void CapturarClienteSeleccionado()
        {
            if (_dgvClientes == null || _dgvClientes.SelectedRows == null || _dgvClientes.SelectedRows.Count == 0)
                return;

            DataGridViewRow row = _dgvClientes.SelectedRows[0];
            if (row == null)
                return;

            int id = 0;
            object idVal = row.Cells["IdCliente"].Value;
            if (idVal != null)
                int.TryParse(idVal.ToString(), out id);

            string nombre = string.Empty;
            object nVal = row.Cells["NombreCompleto"].Value;
            if (nVal != null)
                nombre = nVal.ToString();

            _idClienteSeleccionado = id;
            _nombreClienteSeleccionado = nombre;

            CargarDetalleEstadoCuenta();
        }

        private void CargarDetalleEstadoCuenta()
        {
            if (_dgvDetalle == null)
                return;

            if (_idClienteSeleccionado <= 0)
            {
                _dgvDetalle.DataSource = null;
                return;
            }

            DataTable dt = DatabaseHelper.ObtenerEstadoCuentaCliente(_idClienteSeleccionado, false);
            _dgvDetalle.DataSource = dt;
        }

        private void AbrirEstadoCuentaSeleccionado()
        {
            if (_idClienteSeleccionado <= 0)
                return;

            MostrarDetalleCuenta();
        }
    }
}
