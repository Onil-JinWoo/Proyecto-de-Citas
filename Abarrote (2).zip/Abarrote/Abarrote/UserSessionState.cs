namespace Abarrote
{
    public class UsuarioPermisosDetalle
    {
        // Ventas
        public bool Ventas_UtilizarProductoComun { get; set; }
        public bool Ventas_AplicarMayoreo { get; set; }
        public bool Ventas_AplicarDescuento { get; set; }
        public bool Ventas_RevisarHistorialVentas { get; set; }
        public bool Ventas_RegistrarEntradasEfectivo { get; set; }
        public bool Ventas_RegistrarSalidasEfectivo { get; set; }
        public bool Ventas_CobrarTicket { get; set; }
        public bool Ventas_CobrarCredito { get; set; }
        public bool Ventas_CancelarTicketsDevolverArticulos { get; set; }
        public bool Ventas_EliminarArticulosVenta { get; set; }
        public bool Ventas_FacturarVerFacturas { get; set; }
        public bool Ventas_VenderPagoServicio { get; set; }
        public bool Ventas_VenderRecargasElectronicas { get; set; }
        public bool Ventas_UsarBuscadorProductos { get; set; }

        // Clientes
        public bool Clientes_CrearModificarEliminar { get; set; }
        public bool Clientes_AsignarClienteVenta { get; set; }
        public bool Clientes_AsignarRemoverCredito { get; set; }
        public bool Clientes_VerCuentaRecibirAbonosReportesCredito { get; set; }

        // Productos
        public bool Productos_CrearNuevos { get; set; }
        public bool Productos_Modificar { get; set; }
        public bool Productos_Eliminar { get; set; }
        public bool Productos_VerReporteVentas { get; set; }
        public bool Productos_CrearPromociones { get; set; }
        public bool Productos_ModificarVarios { get; set; }

        // Inventario
        public bool Inventario_AgregarMercancia { get; set; }
        public bool Inventario_VerReportesExistenciasMinimos { get; set; }
        public bool Inventario_VerMovimientoInventarios { get; set; }
        public bool Inventario_AjustarInventario { get; set; }

        // Otros
        public bool Otros_RealizarCorteSuTurno { get; set; }
        public bool Otros_RealizarCorteTodosTurnos { get; set; }
        public bool Otros_RealizarCorteDelDia { get; set; }
        public bool Otros_VerGananciaDelDia { get; set; }
        public bool Otros_CambiarConfiguracionPrograma { get; set; }
        public bool Otros_AccederReportesVentasGanancias { get; set; }
        public bool Otros_CrearOrdenesCompra { get; set; }
        public bool Otros_RecibirOrdenesCompra { get; set; }

        public static UsuarioPermisosDetalle CrearTodoHabilitado()
        {
            return new UsuarioPermisosDetalle
            {
                Ventas_UtilizarProductoComun = true,
                Ventas_AplicarMayoreo = true,
                Ventas_AplicarDescuento = true,
                Ventas_RevisarHistorialVentas = true,
                Ventas_RegistrarEntradasEfectivo = true,
                Ventas_RegistrarSalidasEfectivo = true,
                Ventas_CobrarTicket = true,
                Ventas_CobrarCredito = true,
                Ventas_CancelarTicketsDevolverArticulos = true,
                Ventas_EliminarArticulosVenta = true,
                Ventas_FacturarVerFacturas = true,
                Ventas_VenderPagoServicio = true,
                Ventas_VenderRecargasElectronicas = true,
                Ventas_UsarBuscadorProductos = true,

                Clientes_CrearModificarEliminar = true,
                Clientes_AsignarClienteVenta = true,
                Clientes_AsignarRemoverCredito = true,
                Clientes_VerCuentaRecibirAbonosReportesCredito = true,

                Productos_CrearNuevos = true,
                Productos_Modificar = true,
                Productos_Eliminar = true,
                Productos_VerReporteVentas = true,
                Productos_CrearPromociones = true,
                Productos_ModificarVarios = true,

                Inventario_AgregarMercancia = true,
                Inventario_VerReportesExistenciasMinimos = true,
                Inventario_VerMovimientoInventarios = true,
                Inventario_AjustarInventario = true,

                Otros_RealizarCorteSuTurno = true,
                Otros_RealizarCorteTodosTurnos = true,
                Otros_RealizarCorteDelDia = true,
                Otros_VerGananciaDelDia = true,
                Otros_CambiarConfiguracionPrograma = true,
                Otros_AccederReportesVentasGanancias = true,
                Otros_CrearOrdenesCompra = true,
                Otros_RecibirOrdenesCompra = true
            };
        }
    }

    public static class UserSessionState
    {
        public static int IdUsuario { get; set; }
        public static string Usuario { get; set; }
        public static string Nombre { get; set; }
        public static string Rol { get; set; }

        public static bool PermisoVentas { get; set; }
        public static bool PermisoAgregarProductos { get; set; }

        public static UsuarioPermisosDetalle PermisosDetalle { get; set; }

        public static bool EsAdmin
        {
            get
            {
                return string.Equals((Rol ?? string.Empty).Trim(), "Administrador", System.StringComparison.OrdinalIgnoreCase)
                    || string.Equals((Usuario ?? string.Empty).Trim(), "admin", System.StringComparison.OrdinalIgnoreCase);
            }
        }

        public static string NombreParaMostrar
        {
            get
            {
                string n = (Nombre ?? string.Empty).Trim();
                if (!string.IsNullOrWhiteSpace(n))
                    return n;

                return (Usuario ?? string.Empty).Trim();
            }
        }

        public static void SetPermisosDetalle(UsuarioPermisosDetalle p)
        {
            PermisosDetalle = p;

            // Mantener compatibilidad con permisos existentes
            PermisoVentas = p != null && (
                p.Ventas_UtilizarProductoComun ||
                p.Ventas_AplicarMayoreo ||
                p.Ventas_AplicarDescuento ||
                p.Ventas_RevisarHistorialVentas ||
                p.Ventas_RegistrarEntradasEfectivo ||
                p.Ventas_RegistrarSalidasEfectivo ||
                p.Ventas_CobrarTicket ||
                p.Ventas_CobrarCredito ||
                p.Ventas_CancelarTicketsDevolverArticulos ||
                p.Ventas_EliminarArticulosVenta ||
                p.Ventas_FacturarVerFacturas ||
                p.Ventas_VenderPagoServicio ||
                p.Ventas_VenderRecargasElectronicas ||
                p.Ventas_UsarBuscadorProductos);

            PermisoAgregarProductos = p != null && p.Productos_CrearNuevos;
        }
    }
}
