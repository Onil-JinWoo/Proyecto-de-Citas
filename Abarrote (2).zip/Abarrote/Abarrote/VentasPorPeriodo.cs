using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace Abarrote
{
    public partial class VentasPorPeriodo : Form
    {
        public VentasPorPeriodo()
        {
            InitializeComponent();

            cboPeriodo.Items.Clear();
            cboPeriodo.Items.Add("Hoy");
            cboPeriodo.Items.Add("Ayer");
            cboPeriodo.Items.Add("Esta semana");
            cboPeriodo.Items.Add("La semana pasada");
            cboPeriodo.Items.Add("Del mes");
            cboPeriodo.Items.Add("De un periodo en particular...");
            cboPeriodo.SelectedIndex = 0;

            cboPeriodo.SelectedIndexChanged += cboPeriodo_SelectedIndexChanged;
            btnConsultar.Click += btnConsultar_Click;
            btnExportar.Click += btnExportar_Click;
            btnImprimir.Click += btnImprimir_Click;

            dtpDesde.ValueChanged += dtpDesde_ValueChanged;
            dtpHasta.ValueChanged += dtpHasta_ValueChanged;

            ConfigurarGrid();
            AplicarPeriodoSeleccionado();
            Consultar();
        }

        private void ConfigurarGrid()
        {
            dgvReporte.AutoGenerateColumns = false;
            dgvReporte.Columns.Clear();

            DataGridViewTextBoxColumn colProducto = new DataGridViewTextBoxColumn();
            colProducto.Name = "colProducto";
            colProducto.HeaderText = "Producto";
            colProducto.DataPropertyName = "Producto";
            colProducto.Width = 280;

            DataGridViewTextBoxColumn colCantidad = new DataGridViewTextBoxColumn();
            colCantidad.Name = "colCantidad";
            colCantidad.HeaderText = "Cantidad";
            colCantidad.DataPropertyName = "Cantidad";
            colCantidad.Width = 80;

            DataGridViewTextBoxColumn colPrecio = new DataGridViewTextBoxColumn();
            colPrecio.Name = "colPrecio";
            colPrecio.HeaderText = "Precio Venta";
            colPrecio.DataPropertyName = "PrecioVenta";
            colPrecio.Width = 90;
            colPrecio.DefaultCellStyle.Format = "C2";

            DataGridViewTextBoxColumn colDepartamento = new DataGridViewTextBoxColumn();
            colDepartamento.Name = "colDepartamento";
            colDepartamento.HeaderText = "Departamento";
            colDepartamento.DataPropertyName = "Departamento";
            colDepartamento.Width = 150;

            dgvReporte.Columns.Add(colProducto);
            dgvReporte.Columns.Add(colCantidad);
            dgvReporte.Columns.Add(colPrecio);
            dgvReporte.Columns.Add(colDepartamento);

            dgvReporte.ReadOnly = true;
            dgvReporte.RowHeadersVisible = false;
            dgvReporte.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvReporte.AllowUserToAddRows = false;
            dgvReporte.AllowUserToDeleteRows = false;
        }

        private void cboPeriodo_SelectedIndexChanged(object sender, EventArgs e)
        {
            AplicarPeriodoSeleccionado();
        }

        private void btnConsultar_Click(object sender, EventArgs e)
        {
            Consultar();
        }

        private void dtpDesde_ValueChanged(object sender, EventArgs e)
        {
            if (cboPeriodo.SelectedItem != null && cboPeriodo.SelectedItem.ToString().Contains("periodo"))
                return;
        }

        private void dtpHasta_ValueChanged(object sender, EventArgs e)
        {
            if (cboPeriodo.SelectedItem != null && cboPeriodo.SelectedItem.ToString().Contains("periodo"))
                return;
        }

        private void AplicarPeriodoSeleccionado()
        {
            string p = cboPeriodo.SelectedItem == null ? string.Empty : cboPeriodo.SelectedItem.ToString();

            DateTime hoy = DateTime.Today;
            DateTime desde = hoy;
            DateTime hasta = hoy;

            if (p == "Hoy")
            {
                desde = hoy;
                hasta = hoy;
                HabilitarFechas(false);
            }
            else if (p == "Ayer")
            {
                desde = hoy.AddDays(-1);
                hasta = hoy.AddDays(-1);
                HabilitarFechas(false);
            }
            else if (p == "Esta semana")
            {
                int diff = (int)hoy.DayOfWeek;
                if (diff == 0) diff = 7;
                desde = hoy.AddDays(-(diff - 1));
                hasta = hoy;
                HabilitarFechas(false);
            }
            else if (p == "La semana pasada")
            {
                int diff = (int)hoy.DayOfWeek;
                if (diff == 0) diff = 7;
                DateTime inicioSemana = hoy.AddDays(-(diff - 1));
                desde = inicioSemana.AddDays(-7);
                hasta = inicioSemana.AddDays(-1);
                HabilitarFechas(false);
            }
            else if (p == "Del mes")
            {
                desde = new DateTime(hoy.Year, hoy.Month, 1);
                hasta = hoy;
                HabilitarFechas(false);
            }
            else
            {
                // Periodo personalizado
                HabilitarFechas(true);
                return;
            }

            dtpDesde.Value = desde;
            dtpHasta.Value = hasta;
        }

        private void HabilitarFechas(bool habilitar)
        {
            dtpDesde.Enabled = habilitar;
            dtpHasta.Enabled = habilitar;
        }

        private void Consultar()
        {
            DateTime desde = dtpDesde.Value.Date;
            DateTime hasta = dtpHasta.Value.Date;

            if (hasta < desde)
            {
                MessageBox.Show("El periodo 'hasta' no puede ser menor que 'desde'.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            decimal total;
            DataTable dt = DatabaseHelper.ObtenerReporteProductosVendidos(desde, hasta, false, out total);
            dgvReporte.DataSource = dt;
            lblTotalValue.Text = total.ToString("C2");
        }

        private void btnExportar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Función pendiente de configurar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Función pendiente de configurar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
