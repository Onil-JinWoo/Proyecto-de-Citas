using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace Abarrote
{
    public class AssignClientForm : Form
    {
        private TextBox _txtBuscar;
        private DataGridView _dgv;
        private Button _btnAsignar;
        private Button _btnDesasignar;
        private Button _btnCancelar;

        public int IdClienteSeleccionado { get; private set; }
        public string NombreClienteSeleccionado { get; private set; }
        public bool Desasignar { get; private set; }

        public AssignClientForm()
        {
            InitializeUi();
        }

        private void InitializeUi()
        {
            Text = "Asignar venta a cliente";
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MinimizeBox = false;
            MaximizeBox = false;
            ShowInTaskbar = false;
            ClientSize = new Size(520, 420);

            Label lblTitle = new Label();
            lblTitle.Text = "ASIGNAR VENTA A CLIENTE";
            lblTitle.Dock = DockStyle.Top;
            lblTitle.Height = 34;
            lblTitle.TextAlign = ContentAlignment.MiddleLeft;
            lblTitle.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblTitle.Padding = new Padding(10, 0, 0, 0);
            lblTitle.BackColor = Color.FromArgb(245, 245, 245);

            Panel pnlBuscar = new Panel();
            pnlBuscar.Dock = DockStyle.Top;
            pnlBuscar.Height = 42;
            pnlBuscar.Padding = new Padding(10, 8, 10, 8);

            _txtBuscar = new TextBox();
            _txtBuscar.Dock = DockStyle.Fill;
            _txtBuscar.Font = new Font("Segoe UI", 10F);
            _txtBuscar.TextChanged += (s, e) => CargarClientes();
            _txtBuscar.KeyDown += (s, e) =>
            {
                if (e.KeyCode == Keys.Down)
                {
                    e.SuppressKeyPress = true;
                    if (_dgv.Rows.Count > 0)
                    {
                        _dgv.Focus();
                        _dgv.ClearSelection();
                        _dgv.Rows[0].Selected = true;
                    }
                }
                if (e.KeyCode == Keys.Enter)
                {
                    e.SuppressKeyPress = true;
                    ConfirmarAsignacion();
                }
            };

            pnlBuscar.Controls.Add(_txtBuscar);

            _dgv = new DataGridView();
            _dgv.Dock = DockStyle.Fill;
            _dgv.AllowUserToAddRows = false;
            _dgv.AllowUserToDeleteRows = false;
            _dgv.ReadOnly = true;
            _dgv.RowHeadersVisible = false;
            _dgv.MultiSelect = false;
            _dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            _dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            _dgv.CellDoubleClick += (s, e) => ConfirmarAsignacion();
            _dgv.KeyDown += (s, e) =>
            {
                if (e.KeyCode == Keys.Enter)
                {
                    e.SuppressKeyPress = true;
                    ConfirmarAsignacion();
                }
            };

            Panel pnlBottom = new Panel();
            pnlBottom.Dock = DockStyle.Bottom;
            pnlBottom.Height = 55;

            _btnDesasignar = new Button();
            _btnDesasignar.Text = "Des-asignar";
            _btnDesasignar.Location = new Point(10, 12);
            _btnDesasignar.Size = new Size(120, 30);
            _btnDesasignar.Click += (s, e) =>
            {
                Desasignar = true;
                DialogResult = DialogResult.OK;
                Close();
            };

            _btnAsignar = new Button();
            _btnAsignar.Text = "Asignar";
            _btnAsignar.Location = new Point(310, 12);
            _btnAsignar.Size = new Size(90, 30);
            _btnAsignar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            _btnAsignar.Click += (s, e) => ConfirmarAsignacion();

            _btnCancelar = new Button();
            _btnCancelar.Text = "Cancelar";
            _btnCancelar.Location = new Point(410, 12);
            _btnCancelar.Size = new Size(90, 30);
            _btnCancelar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            _btnCancelar.Click += (s, e) => { DialogResult = DialogResult.Cancel; Close(); };

            pnlBottom.Controls.Add(_btnDesasignar);
            pnlBottom.Controls.Add(_btnAsignar);
            pnlBottom.Controls.Add(_btnCancelar);

            Controls.Add(_dgv);
            Controls.Add(pnlBottom);
            Controls.Add(pnlBuscar);
            Controls.Add(lblTitle);

            KeyPreview = true;
            KeyDown += (s, e) =>
            {
                if (e.KeyCode == Keys.Escape)
                {
                    e.SuppressKeyPress = true;
                    DialogResult = DialogResult.Cancel;
                    Close();
                }
            };

            Shown += (s, e) =>
            {
                _txtBuscar.Focus();
                CargarClientes();
            };
        }

        private void CargarClientes()
        {
            string q = _txtBuscar == null ? string.Empty : (_txtBuscar.Text ?? string.Empty).Trim();
            DataTable dt = DatabaseHelper.ObtenerClientes(q, false);
            _dgv.DataSource = dt;

            if (_dgv.Columns.Contains("IdCliente"))
                _dgv.Columns["IdCliente"].Visible = false;

            if (_dgv.Columns.Contains("NombreCompleto"))
                _dgv.Columns["NombreCompleto"].HeaderText = "Cliente";
            if (_dgv.Columns.Contains("Telefono"))
                _dgv.Columns["Telefono"].HeaderText = "Teléfono";
            if (_dgv.Columns.Contains("CorreoElectronico"))
                _dgv.Columns["CorreoElectronico"].HeaderText = "Correo";
        }

        private void ConfirmarAsignacion()
        {
            if (_dgv.SelectedRows == null || _dgv.SelectedRows.Count == 0)
            {
                if (_dgv.Rows.Count > 0)
                {
                    _dgv.Rows[0].Selected = true;
                }
                else
                {
                    return;
                }
            }

            DataGridViewRow row = _dgv.SelectedRows[0];
            if (row == null)
                return;

            int id = 0;
            object idVal = row.Cells["IdCliente"].Value;
            if (idVal != null)
                int.TryParse(idVal.ToString(), out id);

            string nombre = string.Empty;
            object nVal = row.Cells["NombreCompleto"].Value;
            if (nVal != null)
                nombre = nVal.ToString();

            if (id <= 0)
                return;

            IdClienteSeleccionado = id;
            NombreClienteSeleccionado = nombre;
            Desasignar = false;
            DialogResult = DialogResult.OK;
            Close();
        }
    }
}
