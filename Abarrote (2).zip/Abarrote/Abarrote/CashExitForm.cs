using System;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace Abarrote
{
    public class CashExitForm : Form
    {
        private Panel _hdr;
        private Label _lblHdr;
        private Label _lblCantidad;
        private TextBox _txtMonto;
        private Label _lblRazon;
        private TextBox _txtRazon;
        private Button _btnGuardar;
        private Button _btnCancelar;
        private Label _lblWarning;

        public decimal Monto { get; private set; }
        public string Razon { get; private set; }

        public CashExitForm()
        {
            InitializeUi();
        }

        private void InitializeUi()
        {
            Text = "Registro de Salidas de Dinero";
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            ClientSize = new Size(440, 200);

            _hdr = new Panel();
            _hdr.Location = new Point(0, 0);
            _hdr.Size = new Size(440, 30);
            _hdr.BackColor = Color.FromArgb(255, 140, 0);

            _lblHdr = new Label();
            _lblHdr.AutoSize = false;
            _lblHdr.Location = new Point(10, 5);
            _lblHdr.Size = new Size(320, 20);
            _lblHdr.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            _lblHdr.ForeColor = Color.White;
            _lblHdr.Text = "SALIDAS DE EFECTIVO";

            _hdr.Controls.Add(_lblHdr);

            _lblCantidad = new Label();
            _lblCantidad.AutoSize = true;
            _lblCantidad.Location = new Point(20, 45);
            _lblCantidad.Font = new Font("Segoe UI", 9F);
            _lblCantidad.Text = "Cantidad:";

            _txtMonto = new TextBox();
            _txtMonto.Location = new Point(20, 65);
            _txtMonto.Size = new Size(240, 30);
            _txtMonto.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            _txtMonto.Text = 0m.ToString("C2", CultureInfo.CurrentCulture);
            _txtMonto.Enter += (s, e) =>
            {
                if (_txtMonto != null)
                    _txtMonto.SelectAll();
            };
            _txtMonto.TextChanged += (s, e) => ValidarMontoContraCaja();

            _lblRazon = new Label();
            _lblRazon.AutoSize = true;
            _lblRazon.Location = new Point(20, 110);
            _lblRazon.Font = new Font("Segoe UI", 9F);
            _lblRazon.Text = "Razón o Proveedor:";

            _txtRazon = new TextBox();
            _txtRazon.Location = new Point(20, 130);
            _txtRazon.Size = new Size(240, 23);

            _btnGuardar = new Button();
            _btnGuardar.Location = new Point(300, 55);
            _btnGuardar.Size = new Size(120, 32);
            _btnGuardar.Text = "Guardar";
            _btnGuardar.Click += btnGuardar_Click;

            _btnCancelar = new Button();
            _btnCancelar.Location = new Point(300, 95);
            _btnCancelar.Size = new Size(120, 32);
            _btnCancelar.Text = "Cancelar";
            _btnCancelar.Click += btnCancelar_Click;

            _lblWarning = new Label();
            _lblWarning.AutoSize = false;
            _lblWarning.Location = new Point(20, 160);
            _lblWarning.Size = new Size(400, 22);
            _lblWarning.ForeColor = Color.FromArgb(192, 0, 0);
            _lblWarning.Font = new Font("Segoe UI", 9F, FontStyle.Regular);
            _lblWarning.Text = "La salida es mayor que el efectivo que hay en caja";
            _lblWarning.Visible = false;

            AcceptButton = _btnGuardar;
            CancelButton = _btnCancelar;

            Controls.Add(_hdr);
            Controls.Add(_lblCantidad);
            Controls.Add(_txtMonto);
            Controls.Add(_lblRazon);
            Controls.Add(_txtRazon);
            Controls.Add(_btnGuardar);
            Controls.Add(_btnCancelar);
            Controls.Add(_lblWarning);

            ValidarMontoContraCaja();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            decimal monto;
            if (!TryParseMonto(_txtMonto == null ? string.Empty : (_txtMonto.Text ?? string.Empty), out monto) || monto <= 0m)
            {
                MessageBox.Show("Captura un monto válido.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (_txtMonto != null)
                {
                    _txtMonto.SelectAll();
                    _txtMonto.Focus();
                }
                return;
            }

            if (monto > CashBoxState.EfectivoEnCaja)
            {
                ValidarMontoContraCaja();
                return;
            }

            string razon = _txtRazon == null ? string.Empty : (_txtRazon.Text ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(razon))
            {
                MessageBox.Show("Captura una razón o proveedor.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (_txtRazon != null)
                    _txtRazon.Focus();
                return;
            }

            Monto = monto;
            Razon = razon;

            CashBoxState.EfectivoEnCaja -= monto;

            string err;
            DatabaseHelper.RegistrarMovimientoCaja("SALIDA", monto, Razon, UserSessionState.Usuario, out err);

            DialogResult = DialogResult.OK;
            Close();
        }

        private void ValidarMontoContraCaja()
        {
            decimal monto;
            bool ok = TryParseMonto(_txtMonto == null ? string.Empty : (_txtMonto.Text ?? string.Empty), out monto);
            bool excede = ok && monto > 0m && monto > CashBoxState.EfectivoEnCaja;

            if (_lblWarning != null)
                _lblWarning.Visible = excede;

            if (_btnGuardar != null)
                _btnGuardar.Enabled = !excede;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }

        private static bool TryParseMonto(string value, out decimal monto)
        {
            monto = 0m;
            string v = (value ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(v))
                return false;

            if (decimal.TryParse(v, NumberStyles.Currency, CultureInfo.CurrentCulture, out monto))
                return true;

            return decimal.TryParse(v, NumberStyles.Number, CultureInfo.CurrentCulture, out monto);
        }
    }
}
