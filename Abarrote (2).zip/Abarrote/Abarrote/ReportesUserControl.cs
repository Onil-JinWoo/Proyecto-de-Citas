using System;
using System.Drawing;
using System.Globalization;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Abarrote
{
    public class ReportesUserControl : UserControl
    {
        private Panel _topBar;
        private Label _lblTitle;

        private Panel _tabsBar;
        private Button _btnReporteVentas;
        private Button _btnVentasPorCliente;

        private Panel _content;
        private Panel _panelReporteVentas;
        private Panel _panelVentasPorCliente;

        private Label _lblResumen;
        private LinkLabel _lnkSemana;
        private LinkLabel _lnkMes;
        private LinkLabel _lnkAnio;

        private Chart _chartVentas;
        private Chart _chartDepto;
        private DateTime _rangeDesde;
        private DateTime _rangeHasta;

        public ReportesUserControl()
        {
            InitializeUi();
            Load += (s, e) => MostrarReporteVentas();
        }

        private void InitializeUi()
        {
            BackColor = Color.White;
            Dock = DockStyle.Fill;

            _topBar = new Panel();
            _topBar.Dock = DockStyle.Top;
            _topBar.Height = 32;
            _topBar.BackColor = Color.FromArgb(0, 70, 140);

            _lblTitle = new Label();
            _lblTitle.Dock = DockStyle.Fill;
            _lblTitle.ForeColor = Color.White;
            _lblTitle.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            _lblTitle.TextAlign = ContentAlignment.MiddleLeft;
            _lblTitle.Padding = new Padding(12, 0, 0, 0);
            _lblTitle.Text = "REPORTES";

            _topBar.Controls.Add(_lblTitle);

            _tabsBar = new Panel();
            _tabsBar.Dock = DockStyle.Top;
            _tabsBar.Height = 34;
            _tabsBar.BackColor = Color.FromArgb(245, 245, 245);
            _tabsBar.Padding = new Padding(8, 6, 8, 6);

            _btnReporteVentas = new Button();
            _btnReporteVentas.Text = "Reporte de Ventas";
            _btnReporteVentas.Width = 140;
            _btnReporteVentas.Height = 22;
            _btnReporteVentas.FlatStyle = FlatStyle.Flat;
            _btnReporteVentas.FlatAppearance.BorderColor = Color.FromArgb(200, 200, 200);
            _btnReporteVentas.FlatAppearance.BorderSize = 1;
            _btnReporteVentas.BackColor = Color.White;
            _btnReporteVentas.ForeColor = Color.FromArgb(30, 30, 30);
            _btnReporteVentas.Font = new Font("Segoe UI", 8.25F, FontStyle.Regular);
            _btnReporteVentas.Click += (s, e) => MostrarReporteVentas();

            _btnVentasPorCliente = new Button();
            _btnVentasPorCliente.Text = "Ventas por cliente";
            _btnVentasPorCliente.Width = 140;
            _btnVentasPorCliente.Height = 22;
            _btnVentasPorCliente.FlatStyle = FlatStyle.Flat;
            _btnVentasPorCliente.FlatAppearance.BorderColor = Color.FromArgb(200, 200, 200);
            _btnVentasPorCliente.FlatAppearance.BorderSize = 1;
            _btnVentasPorCliente.BackColor = Color.White;
            _btnVentasPorCliente.ForeColor = Color.FromArgb(30, 30, 30);
            _btnVentasPorCliente.Font = new Font("Segoe UI", 8.25F, FontStyle.Regular);
            _btnVentasPorCliente.Left = _btnReporteVentas.Right + 6;
            _btnVentasPorCliente.Click += (s, e) => MostrarVentasPorCliente();

            _tabsBar.Controls.Add(_btnReporteVentas);
            _tabsBar.Controls.Add(_btnVentasPorCliente);

            _content = new Panel();
            _content.Dock = DockStyle.Fill;
            _content.BackColor = Color.White;

            _panelReporteVentas = CrearPanelReporteVentas();
            _panelVentasPorCliente = CrearPanelVentasPorCliente();

            _content.Controls.Add(_panelReporteVentas);
            _content.Controls.Add(_panelVentasPorCliente);

            Controls.Add(_content);
            Controls.Add(_tabsBar);
            Controls.Add(_topBar);

            Layout += (s, e) => LayoutTabs();
        }

        private void LayoutTabs()
        {
            if (_btnReporteVentas == null || _btnVentasPorCliente == null)
                return;

            _btnReporteVentas.Location = new Point(8, 6);
            _btnVentasPorCliente.Location = new Point(_btnReporteVentas.Right + 6, 6);
        }

        private Panel CrearPanelReporteVentas()
        {
            Panel p = new Panel();
            p.Dock = DockStyle.Fill;
            p.BackColor = Color.White;

            _lblResumen = new Label();
            _lblResumen.AutoSize = false;
            _lblResumen.Location = new Point(18, 18);
            _lblResumen.Size = new Size(600, 26);
            _lblResumen.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            _lblResumen.ForeColor = Color.FromArgb(40, 40, 40);
            _lblResumen.Text = "Resumen de Ventas";

            _lnkSemana = new LinkLabel();
            _lnkSemana.Text = "Semana actual";
            _lnkSemana.Location = new Point(18, 52);
            _lnkSemana.AutoSize = true;
            _lnkSemana.LinkColor = Color.FromArgb(0, 102, 204);
            _lnkSemana.Click += (s, e) => SeleccionarRangoSemana();

            _lnkMes = new LinkLabel();
            _lnkMes.Text = "Mes actual";
            _lnkMes.Location = new Point(130, 52);
            _lnkMes.AutoSize = true;
            _lnkMes.LinkColor = Color.FromArgb(0, 102, 204);
            _lnkMes.Click += (s, e) => SeleccionarRangoMes();

            _lnkAnio = new LinkLabel();
            _lnkAnio.Text = "Año actual";
            _lnkAnio.Location = new Point(220, 52);
            _lnkAnio.AutoSize = true;
            _lnkAnio.LinkColor = Color.FromArgb(0, 102, 204);
            _lnkAnio.Click += (s, e) => SeleccionarRangoAnio();

            _chartVentas = CrearChartBarras();
            _chartVentas.Location = new Point(18, 82);
            _chartVentas.Size = new Size(460, 260);

            _chartDepto = CrearChartDona();
            _chartDepto.Location = new Point(510, 82);
            _chartDepto.Size = new Size(460, 260);

            p.Controls.Add(_lblResumen);
            p.Controls.Add(_lnkSemana);
            p.Controls.Add(_lnkMes);
            p.Controls.Add(_lnkAnio);
            p.Controls.Add(_chartVentas);
            p.Controls.Add(_chartDepto);

            return p;
        }

        private static Chart CrearChartBarras()
        {
            Chart c = new Chart();
            c.BackColor = Color.White;

            ChartArea area = new ChartArea("area");
            area.BackColor = Color.White;
            area.AxisX.MajorGrid.Enabled = false;
            area.AxisY.MajorGrid.LineColor = Color.FromArgb(230, 230, 230);
            area.AxisX.Interval = 1;
            area.AxisX.LabelStyle.Font = new Font("Segoe UI", 8F);
            area.AxisY.LabelStyle.Font = new Font("Segoe UI", 8F);
            c.ChartAreas.Add(area);

            Series s = new Series("Ventas");
            s.ChartType = SeriesChartType.Column;
            s.Color = Color.FromArgb(72, 180, 235);
            s.IsValueShownAsLabel = false;
            s.XValueType = ChartValueType.String;
            c.Series.Add(s);

            c.Legends.Clear();
            return c;
        }

        private static Chart CrearChartDona()
        {
            Chart c = new Chart();
            c.BackColor = Color.White;

            ChartArea area = new ChartArea("area");
            area.BackColor = Color.White;
            area.AxisX.MajorGrid.Enabled = false;
            area.AxisY.MajorGrid.Enabled = false;
            area.AxisX.LabelStyle.Enabled = false;
            area.AxisY.LabelStyle.Enabled = false;
            c.ChartAreas.Add(area);

            Series s = new Series("Depto");
            s.ChartType = SeriesChartType.Doughnut;
            s.IsValueShownAsLabel = false;
            s.LabelForeColor = Color.FromArgb(60, 60, 60);
            s.Font = new Font("Segoe UI", 8F);
            c.Series.Add(s);

            Legend l = new Legend();
            l.Docking = Docking.Right;
            l.Alignment = StringAlignment.Near;
            l.Font = new Font("Segoe UI", 8F);
            c.Legends.Add(l);

            return c;
        }

        private Panel CrearPanelVentasPorCliente()
        {
            Panel p = new Panel();
            p.Dock = DockStyle.Fill;
            p.BackColor = Color.White;

            Label lbl = new Label();
            lbl.AutoSize = false;
            lbl.Location = new Point(18, 18);
            lbl.Size = new Size(700, 26);
            lbl.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            lbl.ForeColor = Color.FromArgb(40, 40, 40);
            lbl.Text = "Ventas por cliente";

            Label lblInfo = new Label();
            lblInfo.AutoSize = false;
            lblInfo.Location = new Point(18, 55);
            lblInfo.Size = new Size(900, 40);
            lblInfo.Font = new Font("Segoe UI", 9.5F, FontStyle.Regular);
            lblInfo.ForeColor = Color.FromArgb(80, 80, 80);
            lblInfo.Text = "Esta sección se llenará con el ranking de clientes (por ventas y ganancia) usando las ventas registradas.";

            p.Controls.Add(lbl);
            p.Controls.Add(lblInfo);
            return p;
        }

        private void MostrarReporteVentas()
        {
            SetTabActivo(_btnReporteVentas);
            if (_panelReporteVentas != null) _panelReporteVentas.Visible = true;
            if (_panelVentasPorCliente != null) _panelVentasPorCliente.Visible = false;
            if (_panelReporteVentas != null) _panelReporteVentas.BringToFront();
            SeleccionarRangoSemana();
        }

        private void MostrarVentasPorCliente()
        {
            SetTabActivo(_btnVentasPorCliente);
            if (_panelReporteVentas != null) _panelReporteVentas.Visible = false;
            if (_panelVentasPorCliente != null) _panelVentasPorCliente.Visible = true;
            if (_panelVentasPorCliente != null) _panelVentasPorCliente.BringToFront();
        }

        private void SetTabActivo(Button activo)
        {
            Button[] tabs = new Button[] { _btnReporteVentas, _btnVentasPorCliente };
            for (int i = 0; i < tabs.Length; i++)
            {
                Button b = tabs[i];
                if (b == null)
                    continue;

                bool isActive = b == activo;
                b.BackColor = isActive ? Color.FromArgb(232, 242, 255) : Color.White;
                b.FlatAppearance.BorderColor = isActive ? Color.FromArgb(120, 170, 255) : Color.FromArgb(200, 200, 200);
            }
        }

        private void SeleccionarRangoSemana()
        {
            DateTime startWeek = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek);
            _rangeDesde = startWeek;
            _rangeHasta = DateTime.Now;
            CargarGraficas();
        }

        private void SeleccionarRangoMes()
        {
            DateTime startMonth = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
            _rangeDesde = startMonth;
            _rangeHasta = DateTime.Now;
            CargarGraficas();
        }

        private void SeleccionarRangoAnio()
        {
            DateTime startYear = new DateTime(DateTime.Today.Year, 1, 1);
            _rangeDesde = startYear;
            _rangeHasta = DateTime.Now;
            CargarGraficas();
        }

        private void CargarGraficas()
        {
            try
            {
                string err;

                List<KeyValuePair<DateTime, decimal>> ventas;
                DatabaseHelper.ObtenerVentasPorDia(_rangeDesde, _rangeHasta, out ventas, out err);

                if (_chartVentas != null && _chartVentas.Series.Count > 0)
                {
                    Series s = _chartVentas.Series[0];
                    s.Points.Clear();

                    for (int i = 0; i < ventas.Count; i++)
                    {
                        DateTime d = ventas[i].Key;
                        decimal tot = ventas[i].Value;
                        string label = d.ToString("ddd", new CultureInfo("es-MX"));
                        int idx = s.Points.AddXY(label, tot);
                        s.Points[idx].ToolTip = string.Format("{0}: {1}", d.ToString("dd/MM"), tot.ToString("C2", CultureInfo.CurrentCulture));
                    }
                }

                List<KeyValuePair<string, decimal>> depto;
                DatabaseHelper.ObtenerGananciaPorDepartamento(_rangeDesde, _rangeHasta, out depto, out err);

                if (_chartDepto != null && _chartDepto.Series.Count > 0)
                {
                    Series s = _chartDepto.Series[0];
                    s.Points.Clear();

                    int max = depto.Count;
                    if (max > 8) max = 8;

                    for (int i = 0; i < max; i++)
                    {
                        string name = depto[i].Key;
                        decimal val = depto[i].Value;
                        int idx = s.Points.AddXY(name, val);
                        s.Points[idx].LegendText = string.Format("{0} ({1})", name, val.ToString("C2", CultureInfo.CurrentCulture));
                        s.Points[idx].ToolTip = s.Points[idx].LegendText;
                    }
                }
            }
            catch
            {
            }
        }
    }
}
