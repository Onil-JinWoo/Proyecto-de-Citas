using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace Abarrote
{
    public class ConfiguracionUserControl : UserControl
    {
        private Panel _pnlHeader;
        private Label _lblTitle;
        private Panel _pnlBody;

        private Panel _pnlOpciones;
        private Button _btnOpcionCuentas;

        private Panel _pnlCajeros;

        private Panel _pnlLista;
        private TextBox _txtBuscar;
        private DataView _usuariosView;

        private Panel _pnlDerecha;

        private DataGridView _dgv;
        private Button _btnNuevo;
        private Button _btnEditar;
        private Button _btnActivar;
        private Button _btnDesactivar;

        private Panel _pnlEditor;
        private Label _lblEditorTitle;
        private TextBox _txtUsuario;
        private TextBox _txtNombre;
        private TextBox _txtPass;
        private ComboBox _cboRol;
        private CheckBox _chkActivo;
        private TabControl _tabsPermisos;

        private CheckBox _chkVentas_UtilizarProductoComun;
        private CheckBox _chkVentas_AplicarMayoreo;
        private CheckBox _chkVentas_AplicarDescuento;
        private CheckBox _chkVentas_RevisarHistorialVentas;
        private CheckBox _chkVentas_RegistrarEntradasEfectivo;
        private CheckBox _chkVentas_RegistrarSalidasEfectivo;
        private CheckBox _chkVentas_CobrarTicket;
        private CheckBox _chkVentas_CobrarCredito;
        private CheckBox _chkVentas_CancelarTicketsDevolverArticulos;
        private CheckBox _chkVentas_EliminarArticulosVenta;
        private CheckBox _chkVentas_FacturarVerFacturas;
        private CheckBox _chkVentas_VenderPagoServicio;
        private CheckBox _chkVentas_VenderRecargasElectronicas;
        private CheckBox _chkVentas_UsarBuscadorProductos;

        private CheckBox _chkClientes_CrearModificarEliminar;
        private CheckBox _chkClientes_AsignarClienteVenta;
        private CheckBox _chkClientes_AsignarRemoverCredito;
        private CheckBox _chkClientes_VerCuentaRecibirAbonosReportesCredito;

        private CheckBox _chkProductos_CrearNuevos;
        private CheckBox _chkProductos_Modificar;
        private CheckBox _chkProductos_Eliminar;
        private CheckBox _chkProductos_VerReporteVentas;
        private CheckBox _chkProductos_CrearPromociones;
        private CheckBox _chkProductos_ModificarVarios;

        private CheckBox _chkInventario_AgregarMercancia;
        private CheckBox _chkInventario_VerReportesExistenciasMinimos;
        private CheckBox _chkInventario_VerMovimientoInventarios;
        private CheckBox _chkInventario_AjustarInventario;

        private CheckBox _chkOtros_RealizarCorteSuTurno;
        private CheckBox _chkOtros_RealizarCorteTodosTurnos;
        private CheckBox _chkOtros_RealizarCorteDelDia;
        private CheckBox _chkOtros_VerGananciaDelDia;
        private CheckBox _chkOtros_CambiarConfiguracionPrograma;
        private CheckBox _chkOtros_AccederReportesVentasGanancias;
        private CheckBox _chkOtros_CrearOrdenesCompra;
        private CheckBox _chkOtros_RecibirOrdenesCompra;
        private Button _btnGuardar;
        private Button _btnCancelar;

        private int _idEditando;
        private bool _modoNuevo;

        public ConfiguracionUserControl()
        {
            Dock = DockStyle.Fill;
            InitializeUi();
            CargarUsuarios();
        }

        private void InitializeUi()
        {
            BackColor = Color.White;

            _pnlBody = new Panel { Dock = DockStyle.Fill, Padding = new Padding(12), BackColor = Color.White };
            Controls.Add(_pnlBody);

            _pnlHeader = new Panel { Dock = DockStyle.Top, Height = 48, BackColor = Color.WhiteSmoke, BorderStyle = BorderStyle.FixedSingle };
            _lblTitle = new Label { Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, Font = new Font("Segoe UI", 14F, FontStyle.Bold), Text = "CONFIGURACIÓN", Padding = new Padding(12, 0, 0, 0) };
            _pnlHeader.Controls.Add(_lblTitle);
            Controls.Add(_pnlHeader);
            _pnlHeader.BringToFront();

            _pnlOpciones = new Panel { Dock = DockStyle.Top, Height = 180, BackColor = Color.White, Padding = new Padding(6, 10, 6, 10) };
            _pnlBody.Controls.Add(_pnlOpciones);

            _btnOpcionCuentas = new Button();
            _btnOpcionCuentas.Size = new Size(120, 85);
            _btnOpcionCuentas.Location = new Point(0, 55);
            _btnOpcionCuentas.Text = "Cuentas";
            _btnOpcionCuentas.TextAlign = ContentAlignment.BottomCenter;
            _btnOpcionCuentas.ImageAlign = ContentAlignment.TopCenter;
            _btnOpcionCuentas.Image = SystemIcons.Information.ToBitmap();
            _btnOpcionCuentas.Click += (s, e) => MostrarCuentas();
            _pnlOpciones.Controls.Add(_btnOpcionCuentas);

            _pnlCajeros = new Panel { Dock = DockStyle.Fill, BackColor = Color.White, Visible = false };
            _pnlBody.Controls.Add(_pnlCajeros);

            Panel pnlToolbar = new Panel { Dock = DockStyle.Top, Height = 42, BackColor = Color.White };
            _btnNuevo = new Button { Text = "Nuevo", Width = 90, Height = 30, Location = new Point(0, 6) };
            _btnEditar = new Button { Text = "Editar", Width = 90, Height = 30, Location = new Point(100, 6) };
            _btnActivar = new Button { Text = "Activar", Width = 90, Height = 30, Location = new Point(200, 6) };
            _btnDesactivar = new Button { Text = "Desactivar", Width = 90, Height = 30, Location = new Point(300, 6) };

            _btnNuevo.Click += (s, e) => AbrirEditorNuevo();
            _btnEditar.Click += (s, e) => AbrirEditorEditarSeleccionado();
            _btnActivar.Click += (s, e) => CambiarActivoSeleccionado(true);
            _btnDesactivar.Click += (s, e) => CambiarActivoSeleccionado(false);

            pnlToolbar.Controls.Add(_btnNuevo);
            pnlToolbar.Controls.Add(_btnEditar);
            pnlToolbar.Controls.Add(_btnActivar);
            pnlToolbar.Controls.Add(_btnDesactivar);
            _pnlCajeros.Controls.Add(pnlToolbar);

            // IMPORTANTE: el orden de agregado afecta el Dock (z-order).
            // Para que el panel derecho respete el ancho del panel izquierdo,
            // se agrega primero el Fill y luego los Left.
            _pnlDerecha = new Panel { Dock = DockStyle.Fill, BackColor = Color.White, Padding = new Padding(12, 0, 0, 0) };
            _pnlCajeros.Controls.Add(_pnlDerecha);

            Splitter split = new Splitter { Dock = DockStyle.Left, Width = 6, BackColor = Color.Gainsboro };
            _pnlCajeros.Controls.Add(split);

            _pnlLista = new Panel { Dock = DockStyle.Left, Width = 260, BackColor = Color.White, Padding = new Padding(6, 12, 6, 6) };
            _pnlCajeros.Controls.Add(_pnlLista);

            Panel pnlBuscar = new Panel { Dock = DockStyle.Top, Height = 42, BackColor = Color.White, Padding = new Padding(0, 6, 0, 6) };
            _pnlLista.Controls.Add(pnlBuscar);

            _txtBuscar = new TextBox { Dock = DockStyle.Fill };
            _txtBuscar.TextChanged += (s, e) => AplicarFiltroUsuarios();
            pnlBuscar.Controls.Add(_txtBuscar);

            _dgv = new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false,
                BackgroundColor = Color.White,
                GridColor = Color.Gainsboro,
                BorderStyle = BorderStyle.FixedSingle
            };
            _dgv.SelectionChanged += (s, e) => CargarEditorDesdeSeleccion();
            _pnlLista.Controls.Add(_dgv);

            pnlBuscar.BringToFront();

            _pnlEditor = new Panel { Dock = DockStyle.Fill, Padding = new Padding(12), BackColor = Color.WhiteSmoke, BorderStyle = BorderStyle.FixedSingle, Visible = false };
            _pnlDerecha.Controls.Add(_pnlEditor);
            BuildEditorControls();
        }

        private void MostrarCuentas()
        {
            if (_lblTitle != null)
                _lblTitle.Text = "CONFIGURACIÓN - CUENTAS";
            if (_pnlCajeros != null)
                _pnlCajeros.Visible = true;
            if (_pnlOpciones != null)
                _pnlOpciones.Visible = false;
            CargarUsuarios();

            if (_pnlEditor != null)
                _pnlEditor.Visible = true;

            AbrirEditorNuevo();
        }

        private void BuildEditorControls()
        {
            if (_pnlEditor == null)
                return;

            _pnlEditor.Controls.Clear();

            TableLayoutPanel root = new TableLayoutPanel();
            root.Dock = DockStyle.Fill;
            root.ColumnCount = 1;
            root.RowCount = 3;
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            _pnlEditor.Controls.Add(root);

            Panel pnlTop = new Panel { Dock = DockStyle.Top, Height = 160, BackColor = Color.Transparent };
            root.Controls.Add(pnlTop, 0, 0);

            _lblEditorTitle = new Label { Dock = DockStyle.Top, Height = 26, Font = new Font("Segoe UI", 11F, FontStyle.Bold), Text = "Cuenta" };
            pnlTop.Controls.Add(_lblEditorTitle);

            TableLayoutPanel grid = new TableLayoutPanel();
            grid.Dock = DockStyle.Top;
            grid.AutoSize = true;
            grid.ColumnCount = 2;
            grid.RowCount = 4;
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 160F));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            pnlTop.Controls.Add(grid);
            grid.BringToFront();

            Label lblUsuario = new Label { AutoSize = true, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, Font = new Font("Segoe UI", 9F, FontStyle.Bold), Text = "Usuario:" };
            _txtUsuario = new TextBox { Dock = DockStyle.Fill };
            grid.Controls.Add(lblUsuario, 0, 0);
            grid.Controls.Add(_txtUsuario, 1, 0);

            Label lblPass = new Label { AutoSize = true, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, Font = new Font("Segoe UI", 9F, FontStyle.Bold), Text = "Contraseña (opcional):" };
            _txtPass = new TextBox { Dock = DockStyle.Fill, UseSystemPasswordChar = true };
            grid.Controls.Add(lblPass, 0, 1);
            grid.Controls.Add(_txtPass, 1, 1);

            Label lblNombre = new Label { AutoSize = true, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, Font = new Font("Segoe UI", 9F, FontStyle.Bold), Text = "Nombre completo:" };
            _txtNombre = new TextBox { Dock = DockStyle.Fill };
            grid.Controls.Add(lblNombre, 0, 2);
            grid.Controls.Add(_txtNombre, 1, 2);

            Label lblRol = new Label { AutoSize = true, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, Font = new Font("Segoe UI", 9F, FontStyle.Bold), Text = "Rol:" };
            _cboRol = new ComboBox { Dock = DockStyle.Left, Width = 220, DropDownStyle = ComboBoxStyle.DropDownList };
            _cboRol.Items.AddRange(new object[] { "Cajero", "Administrador" });
            _cboRol.SelectedIndexChanged += (s, e) => AplicarRolEnEditor();
            Panel pnlRol = new Panel { Dock = DockStyle.Fill };
            pnlRol.Controls.Add(_cboRol);
            grid.Controls.Add(lblRol, 0, 3);
            grid.Controls.Add(pnlRol, 1, 3);

            _tabsPermisos = new TabControl { Dock = DockStyle.Fill };
            root.Controls.Add(_tabsPermisos, 0, 1);

            TabPage tabVentas = new TabPage("Ventas") { AutoScroll = true };
            TabPage tabClientes = new TabPage("Clientes") { AutoScroll = true };
            TabPage tabProductos = new TabPage("Productos") { AutoScroll = true };
            TabPage tabInventario = new TabPage("Inventario") { AutoScroll = true };
            TabPage tabOtros = new TabPage("Otros") { AutoScroll = true };

            _tabsPermisos.TabPages.Add(tabVentas);
            _tabsPermisos.TabPages.Add(tabClientes);
            _tabsPermisos.TabPages.Add(tabProductos);
            _tabsPermisos.TabPages.Add(tabInventario);
            _tabsPermisos.TabPages.Add(tabOtros);

            _chkVentas_UtilizarProductoComun = new CheckBox { AutoSize = true, Text = "Utilizar Producto Común" };
            _chkVentas_AplicarMayoreo = new CheckBox { AutoSize = true, Text = "Aplicar Mayoreo" };
            _chkVentas_AplicarDescuento = new CheckBox { AutoSize = true, Text = "Aplicar Descuento" };
            _chkVentas_RevisarHistorialVentas = new CheckBox { AutoSize = true, Text = "Revisar el historial de Ventas" };
            _chkVentas_RegistrarEntradasEfectivo = new CheckBox { AutoSize = true, Text = "Registrar Entradas de Efectivo" };
            _chkVentas_RegistrarSalidasEfectivo = new CheckBox { AutoSize = true, Text = "Registrar Salidas de Efectivo" };
            _chkVentas_CobrarTicket = new CheckBox { AutoSize = true, Text = "Cobrar un ticket" };
            _chkVentas_CobrarCredito = new CheckBox { AutoSize = true, Text = "Cobrar a crédito" };
            _chkVentas_CancelarTicketsDevolverArticulos = new CheckBox { AutoSize = true, Text = "Cancelar tickets y devolver articulos" };
            _chkVentas_EliminarArticulosVenta = new CheckBox { AutoSize = true, Text = "Eliminar artículos de venta" };
            _chkVentas_FacturarVerFacturas = new CheckBox { AutoSize = true, Text = "Facturar / Ver Facturas" };
            _chkVentas_VenderPagoServicio = new CheckBox { AutoSize = true, Text = "Vender un pago de servicio" };
            _chkVentas_VenderRecargasElectronicas = new CheckBox { AutoSize = true, Text = "Vender Recargas Electrónicas" };
            _chkVentas_UsarBuscadorProductos = new CheckBox { AutoSize = true, Text = "Usar buscador de productos" };

            CheckBox[] ventasChecks = new CheckBox[]
            {
                _chkVentas_UtilizarProductoComun,
                _chkVentas_AplicarMayoreo,
                _chkVentas_AplicarDescuento,
                _chkVentas_RevisarHistorialVentas,
                _chkVentas_RegistrarEntradasEfectivo,
                _chkVentas_RegistrarSalidasEfectivo,
                _chkVentas_CobrarTicket,
                _chkVentas_CobrarCredito,
                _chkVentas_CancelarTicketsDevolverArticulos,
                _chkVentas_EliminarArticulosVenta,
                _chkVentas_FacturarVerFacturas,
                _chkVentas_VenderPagoServicio,
                _chkVentas_VenderRecargasElectronicas,
                _chkVentas_UsarBuscadorProductos
            };
            LayoutChecksTwoColumns(tabVentas, ventasChecks);

            _chkClientes_CrearModificarEliminar = new CheckBox { AutoSize = true, Text = "Crear, modificar o eliminar clientes" };
            _chkClientes_AsignarClienteVenta = new CheckBox { AutoSize = true, Text = "Asignar cliente a una venta" };
            _chkClientes_AsignarRemoverCredito = new CheckBox { AutoSize = true, Text = "Asignar o remover crédito a clientes" };
            _chkClientes_VerCuentaRecibirAbonosReportesCredito = new CheckBox { AutoSize = true, Text = "Ver cuenta, recibir abonos y reportes de clientes a crédito" };

            LayoutChecksOneColumn(tabClientes, new CheckBox[]
            {
                _chkClientes_CrearModificarEliminar,
                _chkClientes_AsignarClienteVenta,
                _chkClientes_AsignarRemoverCredito,
                _chkClientes_VerCuentaRecibirAbonosReportesCredito
            });

            _chkProductos_CrearNuevos = new CheckBox { AutoSize = true, Text = "Crear nuevos productos" };
            _chkProductos_Modificar = new CheckBox { AutoSize = true, Text = "Modificar productos" };
            _chkProductos_Eliminar = new CheckBox { AutoSize = true, Text = "Eliminar productos" };
            _chkProductos_VerReporteVentas = new CheckBox { AutoSize = true, Text = "Ver reporte de ventas" };
            _chkProductos_CrearPromociones = new CheckBox { AutoSize = true, Text = "Crear promociones" };
            _chkProductos_ModificarVarios = new CheckBox { AutoSize = true, Text = "Modificar Varios" };

            LayoutChecksOneColumn(tabProductos, new CheckBox[]
            {
                _chkProductos_CrearNuevos,
                _chkProductos_Modificar,
                _chkProductos_Eliminar,
                _chkProductos_VerReporteVentas,
                _chkProductos_CrearPromociones,
                _chkProductos_ModificarVarios
            });

            _chkInventario_AgregarMercancia = new CheckBox { AutoSize = true, Text = "Agregar mercancía" };
            _chkInventario_VerReportesExistenciasMinimos = new CheckBox { AutoSize = true, Text = "Ver reportes de existencias y mínimos" };
            _chkInventario_VerMovimientoInventarios = new CheckBox { AutoSize = true, Text = "Ver movimiento de inventarios" };
            _chkInventario_AjustarInventario = new CheckBox { AutoSize = true, Text = "Ajustar el inventario" };

            LayoutChecksOneColumn(tabInventario, new CheckBox[]
            {
                _chkInventario_AgregarMercancia,
                _chkInventario_VerReportesExistenciasMinimos,
                _chkInventario_VerMovimientoInventarios,
                _chkInventario_AjustarInventario
            });

            _chkOtros_RealizarCorteSuTurno = new CheckBox { AutoSize = true, Text = "Realizar el corte de su turno y ver efectivo esperado en caja" };
            _chkOtros_RealizarCorteTodosTurnos = new CheckBox { AutoSize = true, Text = "Realizar el corte de todos los turnos" };
            _chkOtros_RealizarCorteDelDia = new CheckBox { AutoSize = true, Text = "Realizar el corte del día (Todos los turnos)" };
            _chkOtros_VerGananciaDelDia = new CheckBox { AutoSize = true, Text = "Ver la ganancia del día" };
            _chkOtros_CambiarConfiguracionPrograma = new CheckBox { AutoSize = true, Text = "Cambiar la configuración del programa" };
            _chkOtros_AccederReportesVentasGanancias = new CheckBox { AutoSize = true, Text = "Acceder a los reportes de ventas y ganancias" };
            _chkOtros_CrearOrdenesCompra = new CheckBox { AutoSize = true, Text = "Crear órdenes de compra" };
            _chkOtros_RecibirOrdenesCompra = new CheckBox { AutoSize = true, Text = "Recibir órdenes de compra" };

            LayoutChecksOneColumn(tabOtros, new CheckBox[]
            {
                _chkOtros_RealizarCorteSuTurno,
                _chkOtros_RealizarCorteTodosTurnos,
                _chkOtros_RealizarCorteDelDia,
                _chkOtros_VerGananciaDelDia,
                _chkOtros_CambiarConfiguracionPrograma,
                _chkOtros_AccederReportesVentasGanancias,
                _chkOtros_CrearOrdenesCompra,
                _chkOtros_RecibirOrdenesCompra
            });

            Panel pnlBottom = new Panel { Dock = DockStyle.Bottom, Height = 54, BackColor = Color.Transparent };
            root.Controls.Add(pnlBottom, 0, 2);

            _chkActivo = new CheckBox { AutoSize = true, Location = new Point(4, 6), Text = "Activo", Checked = true };
            pnlBottom.Controls.Add(_chkActivo);

            _btnGuardar = new Button { Text = "Guardar", Width = 150, Height = 32, Location = new Point(4, 24) };
            _btnCancelar = new Button { Text = "Cancelar", Width = 150, Height = 32, Location = new Point(164, 24) };
            _btnGuardar.Click += (s, e) => GuardarEditor();
            _btnCancelar.Click += (s, e) => CerrarEditor();
            pnlBottom.Controls.Add(_btnGuardar);
            pnlBottom.Controls.Add(_btnCancelar);
        }

        private void AplicarRolEnEditor()
        {
            string rol = _cboRol == null ? string.Empty : Convert.ToString(_cboRol.SelectedItem);
            bool esAdmin = string.Equals((rol ?? string.Empty).Trim(), "Administrador", StringComparison.OrdinalIgnoreCase);

            UsuarioPermisosDetalle p = esAdmin ? UsuarioPermisosDetalle.CrearTodoHabilitado() : LeerPermisosDesdeEditor();
            if (esAdmin)
                CargarPermisosEnEditor(p);

            SetPermisosEditorEnabled(!esAdmin);
        }

        private void SetPermisosEditorEnabled(bool enabled)
        {
            if (_tabsPermisos != null) _tabsPermisos.Enabled = enabled;
        }

        private static bool BoolDeRow(DataRow row, string col)
        {
            if (row == null || !row.Table.Columns.Contains(col))
                return false;
            object v = row[col];
            return v != null && v != DBNull.Value && Convert.ToBoolean(v);
        }

        private UsuarioPermisosDetalle LeerPermisosDesdeEditor()
        {
            UsuarioPermisosDetalle p = new UsuarioPermisosDetalle();

            p.Ventas_UtilizarProductoComun = _chkVentas_UtilizarProductoComun != null && _chkVentas_UtilizarProductoComun.Checked;
            p.Ventas_AplicarMayoreo = _chkVentas_AplicarMayoreo != null && _chkVentas_AplicarMayoreo.Checked;
            p.Ventas_AplicarDescuento = _chkVentas_AplicarDescuento != null && _chkVentas_AplicarDescuento.Checked;
            p.Ventas_RevisarHistorialVentas = _chkVentas_RevisarHistorialVentas != null && _chkVentas_RevisarHistorialVentas.Checked;
            p.Ventas_RegistrarEntradasEfectivo = _chkVentas_RegistrarEntradasEfectivo != null && _chkVentas_RegistrarEntradasEfectivo.Checked;
            p.Ventas_RegistrarSalidasEfectivo = _chkVentas_RegistrarSalidasEfectivo != null && _chkVentas_RegistrarSalidasEfectivo.Checked;
            p.Ventas_CobrarTicket = _chkVentas_CobrarTicket != null && _chkVentas_CobrarTicket.Checked;
            p.Ventas_CobrarCredito = _chkVentas_CobrarCredito != null && _chkVentas_CobrarCredito.Checked;
            p.Ventas_CancelarTicketsDevolverArticulos = _chkVentas_CancelarTicketsDevolverArticulos != null && _chkVentas_CancelarTicketsDevolverArticulos.Checked;
            p.Ventas_EliminarArticulosVenta = _chkVentas_EliminarArticulosVenta != null && _chkVentas_EliminarArticulosVenta.Checked;
            p.Ventas_FacturarVerFacturas = _chkVentas_FacturarVerFacturas != null && _chkVentas_FacturarVerFacturas.Checked;
            p.Ventas_VenderPagoServicio = _chkVentas_VenderPagoServicio != null && _chkVentas_VenderPagoServicio.Checked;
            p.Ventas_VenderRecargasElectronicas = _chkVentas_VenderRecargasElectronicas != null && _chkVentas_VenderRecargasElectronicas.Checked;
            p.Ventas_UsarBuscadorProductos = _chkVentas_UsarBuscadorProductos != null && _chkVentas_UsarBuscadorProductos.Checked;

            p.Clientes_CrearModificarEliminar = _chkClientes_CrearModificarEliminar != null && _chkClientes_CrearModificarEliminar.Checked;
            p.Clientes_AsignarClienteVenta = _chkClientes_AsignarClienteVenta != null && _chkClientes_AsignarClienteVenta.Checked;
            p.Clientes_AsignarRemoverCredito = _chkClientes_AsignarRemoverCredito != null && _chkClientes_AsignarRemoverCredito.Checked;
            p.Clientes_VerCuentaRecibirAbonosReportesCredito = _chkClientes_VerCuentaRecibirAbonosReportesCredito != null && _chkClientes_VerCuentaRecibirAbonosReportesCredito.Checked;

            p.Productos_CrearNuevos = _chkProductos_CrearNuevos != null && _chkProductos_CrearNuevos.Checked;
            p.Productos_Modificar = _chkProductos_Modificar != null && _chkProductos_Modificar.Checked;
            p.Productos_Eliminar = _chkProductos_Eliminar != null && _chkProductos_Eliminar.Checked;
            p.Productos_VerReporteVentas = _chkProductos_VerReporteVentas != null && _chkProductos_VerReporteVentas.Checked;
            p.Productos_CrearPromociones = _chkProductos_CrearPromociones != null && _chkProductos_CrearPromociones.Checked;
            p.Productos_ModificarVarios = _chkProductos_ModificarVarios != null && _chkProductos_ModificarVarios.Checked;

            p.Inventario_AgregarMercancia = _chkInventario_AgregarMercancia != null && _chkInventario_AgregarMercancia.Checked;
            p.Inventario_VerReportesExistenciasMinimos = _chkInventario_VerReportesExistenciasMinimos != null && _chkInventario_VerReportesExistenciasMinimos.Checked;
            p.Inventario_VerMovimientoInventarios = _chkInventario_VerMovimientoInventarios != null && _chkInventario_VerMovimientoInventarios.Checked;
            p.Inventario_AjustarInventario = _chkInventario_AjustarInventario != null && _chkInventario_AjustarInventario.Checked;

            p.Otros_RealizarCorteSuTurno = _chkOtros_RealizarCorteSuTurno != null && _chkOtros_RealizarCorteSuTurno.Checked;
            p.Otros_RealizarCorteTodosTurnos = _chkOtros_RealizarCorteTodosTurnos != null && _chkOtros_RealizarCorteTodosTurnos.Checked;
            p.Otros_RealizarCorteDelDia = _chkOtros_RealizarCorteDelDia != null && _chkOtros_RealizarCorteDelDia.Checked;
            p.Otros_VerGananciaDelDia = _chkOtros_VerGananciaDelDia != null && _chkOtros_VerGananciaDelDia.Checked;
            p.Otros_CambiarConfiguracionPrograma = _chkOtros_CambiarConfiguracionPrograma != null && _chkOtros_CambiarConfiguracionPrograma.Checked;
            p.Otros_AccederReportesVentasGanancias = _chkOtros_AccederReportesVentasGanancias != null && _chkOtros_AccederReportesVentasGanancias.Checked;
            p.Otros_CrearOrdenesCompra = _chkOtros_CrearOrdenesCompra != null && _chkOtros_CrearOrdenesCompra.Checked;
            p.Otros_RecibirOrdenesCompra = _chkOtros_RecibirOrdenesCompra != null && _chkOtros_RecibirOrdenesCompra.Checked;

            return p;
        }

        private void CargarPermisosEnEditor(UsuarioPermisosDetalle p)
        {
            if (p == null)
                p = new UsuarioPermisosDetalle();

            if (_chkVentas_UtilizarProductoComun != null) _chkVentas_UtilizarProductoComun.Checked = p.Ventas_UtilizarProductoComun;
            if (_chkVentas_AplicarMayoreo != null) _chkVentas_AplicarMayoreo.Checked = p.Ventas_AplicarMayoreo;
            if (_chkVentas_AplicarDescuento != null) _chkVentas_AplicarDescuento.Checked = p.Ventas_AplicarDescuento;
            if (_chkVentas_RevisarHistorialVentas != null) _chkVentas_RevisarHistorialVentas.Checked = p.Ventas_RevisarHistorialVentas;
            if (_chkVentas_RegistrarEntradasEfectivo != null) _chkVentas_RegistrarEntradasEfectivo.Checked = p.Ventas_RegistrarEntradasEfectivo;
            if (_chkVentas_RegistrarSalidasEfectivo != null) _chkVentas_RegistrarSalidasEfectivo.Checked = p.Ventas_RegistrarSalidasEfectivo;
            if (_chkVentas_CobrarTicket != null) _chkVentas_CobrarTicket.Checked = p.Ventas_CobrarTicket;
            if (_chkVentas_CobrarCredito != null) _chkVentas_CobrarCredito.Checked = p.Ventas_CobrarCredito;
            if (_chkVentas_CancelarTicketsDevolverArticulos != null) _chkVentas_CancelarTicketsDevolverArticulos.Checked = p.Ventas_CancelarTicketsDevolverArticulos;
            if (_chkVentas_EliminarArticulosVenta != null) _chkVentas_EliminarArticulosVenta.Checked = p.Ventas_EliminarArticulosVenta;
            if (_chkVentas_FacturarVerFacturas != null) _chkVentas_FacturarVerFacturas.Checked = p.Ventas_FacturarVerFacturas;
            if (_chkVentas_VenderPagoServicio != null) _chkVentas_VenderPagoServicio.Checked = p.Ventas_VenderPagoServicio;
            if (_chkVentas_VenderRecargasElectronicas != null) _chkVentas_VenderRecargasElectronicas.Checked = p.Ventas_VenderRecargasElectronicas;
            if (_chkVentas_UsarBuscadorProductos != null) _chkVentas_UsarBuscadorProductos.Checked = p.Ventas_UsarBuscadorProductos;

            if (_chkClientes_CrearModificarEliminar != null) _chkClientes_CrearModificarEliminar.Checked = p.Clientes_CrearModificarEliminar;
            if (_chkClientes_AsignarClienteVenta != null) _chkClientes_AsignarClienteVenta.Checked = p.Clientes_AsignarClienteVenta;
            if (_chkClientes_AsignarRemoverCredito != null) _chkClientes_AsignarRemoverCredito.Checked = p.Clientes_AsignarRemoverCredito;
            if (_chkClientes_VerCuentaRecibirAbonosReportesCredito != null) _chkClientes_VerCuentaRecibirAbonosReportesCredito.Checked = p.Clientes_VerCuentaRecibirAbonosReportesCredito;

            if (_chkProductos_CrearNuevos != null) _chkProductos_CrearNuevos.Checked = p.Productos_CrearNuevos;
            if (_chkProductos_Modificar != null) _chkProductos_Modificar.Checked = p.Productos_Modificar;
            if (_chkProductos_Eliminar != null) _chkProductos_Eliminar.Checked = p.Productos_Eliminar;
            if (_chkProductos_VerReporteVentas != null) _chkProductos_VerReporteVentas.Checked = p.Productos_VerReporteVentas;
            if (_chkProductos_CrearPromociones != null) _chkProductos_CrearPromociones.Checked = p.Productos_CrearPromociones;
            if (_chkProductos_ModificarVarios != null) _chkProductos_ModificarVarios.Checked = p.Productos_ModificarVarios;

            if (_chkInventario_AgregarMercancia != null) _chkInventario_AgregarMercancia.Checked = p.Inventario_AgregarMercancia;
            if (_chkInventario_VerReportesExistenciasMinimos != null) _chkInventario_VerReportesExistenciasMinimos.Checked = p.Inventario_VerReportesExistenciasMinimos;
            if (_chkInventario_VerMovimientoInventarios != null) _chkInventario_VerMovimientoInventarios.Checked = p.Inventario_VerMovimientoInventarios;
            if (_chkInventario_AjustarInventario != null) _chkInventario_AjustarInventario.Checked = p.Inventario_AjustarInventario;

            if (_chkOtros_RealizarCorteSuTurno != null) _chkOtros_RealizarCorteSuTurno.Checked = p.Otros_RealizarCorteSuTurno;
            if (_chkOtros_RealizarCorteTodosTurnos != null) _chkOtros_RealizarCorteTodosTurnos.Checked = p.Otros_RealizarCorteTodosTurnos;
            if (_chkOtros_RealizarCorteDelDia != null) _chkOtros_RealizarCorteDelDia.Checked = p.Otros_RealizarCorteDelDia;
            if (_chkOtros_VerGananciaDelDia != null) _chkOtros_VerGananciaDelDia.Checked = p.Otros_VerGananciaDelDia;
            if (_chkOtros_CambiarConfiguracionPrograma != null) _chkOtros_CambiarConfiguracionPrograma.Checked = p.Otros_CambiarConfiguracionPrograma;
            if (_chkOtros_AccederReportesVentasGanancias != null) _chkOtros_AccederReportesVentasGanancias.Checked = p.Otros_AccederReportesVentasGanancias;
            if (_chkOtros_CrearOrdenesCompra != null) _chkOtros_CrearOrdenesCompra.Checked = p.Otros_CrearOrdenesCompra;
            if (_chkOtros_RecibirOrdenesCompra != null) _chkOtros_RecibirOrdenesCompra.Checked = p.Otros_RecibirOrdenesCompra;
        }

        private static void LayoutChecksOneColumn(Control parent, CheckBox[] checks)
        {
            if (parent == null || checks == null)
                return;

            int x = 12;
            int y = 12;
            int gapY = 22;

            for (int i = 0; i < checks.Length; i++)
            {
                CheckBox c = checks[i];
                if (c == null)
                    continue;

                c.Location = new Point(x, y);
                parent.Controls.Add(c);
                y += gapY;
            }
        }

        private static void LayoutChecksTwoColumns(Control parent, CheckBox[] checks)
        {
            if (parent == null || checks == null)
                return;

            int x1 = 12;
            int x2 = 360;
            int y1 = 12;
            int y2 = 12;
            int gapY = 22;

            for (int i = 0; i < checks.Length; i++)
            {
                CheckBox c = checks[i];
                if (c == null)
                    continue;

                bool left = (i % 2) == 0;
                if (left)
                {
                    c.Location = new Point(x1, y1);
                    y1 += gapY;
                }
                else
                {
                    c.Location = new Point(x2, y2);
                    y2 += gapY;
                }

                parent.Controls.Add(c);
            }
        }

        private DataRowView GetSelectedRow()
        {
            if (_dgv == null || _dgv.CurrentRow == null)
                return null;

            return _dgv.CurrentRow.DataBoundItem as DataRowView;
        }

        private void AbrirEditorNuevo()
        {
            _idEditando = 0;
            _modoNuevo = true;
            _lblEditorTitle.Text = "Nueva cuenta";
            _pnlEditor.Visible = true;
            _txtUsuario.Enabled = true;
            _txtUsuario.Text = string.Empty;
            _txtNombre.Text = string.Empty;
            _txtPass.Text = string.Empty;
            _chkActivo.Checked = true;

            try
            {
                if (_dgv != null)
                    _dgv.ClearSelection();
            }
            catch
            {
            }

            if (_cboRol != null)
                _cboRol.SelectedItem = "Cajero";

            CargarPermisosEnEditor(new UsuarioPermisosDetalle());

            AplicarRolEnEditor();
            _txtUsuario.Focus();
        }

        private void AbrirEditorEditarSeleccionado()
        {
            DataRowView row = GetSelectedRow();
            if (row == null)
                return;

            _modoNuevo = false;
            _idEditando = Convert.ToInt32(row["IdUsuario"]);
            _lblEditorTitle.Text = "Editar cuenta";
            _pnlEditor.Visible = true;
            _txtUsuario.Enabled = false;
            _txtUsuario.Text = Convert.ToString(row["Usuario"]);
            _txtNombre.Text = Convert.ToString(row["Nombre"]);
            _txtPass.Text = string.Empty;
            _chkActivo.Checked = row["Activo"] != DBNull.Value && Convert.ToBoolean(row["Activo"]);

            string rol = Convert.ToString(row["Rol"]);
            if (_cboRol != null)
            {
                if (string.Equals((rol ?? string.Empty).Trim(), "Administrador", StringComparison.OrdinalIgnoreCase))
                    _cboRol.SelectedItem = "Administrador";
                else
                    _cboRol.SelectedItem = "Cajero";
            }

            try
            {
                UsuarioPermisosDetalle p = new UsuarioPermisosDetalle();

                DataRow rowDet = DatabaseHelper.ObtenerPermisosDetalleUsuario(_idEditando, false);
                if (rowDet != null)
                {
                    p.Ventas_UtilizarProductoComun = BoolDeRow(rowDet, "Ventas_UtilizarProductoComun");
                    p.Ventas_AplicarMayoreo = BoolDeRow(rowDet, "Ventas_AplicarMayoreo");
                    p.Ventas_AplicarDescuento = BoolDeRow(rowDet, "Ventas_AplicarDescuento");
                    p.Ventas_RevisarHistorialVentas = BoolDeRow(rowDet, "Ventas_RevisarHistorialVentas");
                    p.Ventas_RegistrarEntradasEfectivo = BoolDeRow(rowDet, "Ventas_RegistrarEntradasEfectivo");
                    p.Ventas_RegistrarSalidasEfectivo = BoolDeRow(rowDet, "Ventas_RegistrarSalidasEfectivo");
                    p.Ventas_CobrarTicket = BoolDeRow(rowDet, "Ventas_CobrarTicket");
                    p.Ventas_CobrarCredito = BoolDeRow(rowDet, "Ventas_CobrarCredito");
                    p.Ventas_CancelarTicketsDevolverArticulos = BoolDeRow(rowDet, "Ventas_CancelarTicketsDevolverArticulos");
                    p.Ventas_EliminarArticulosVenta = BoolDeRow(rowDet, "Ventas_EliminarArticulosVenta");
                    p.Ventas_FacturarVerFacturas = BoolDeRow(rowDet, "Ventas_FacturarVerFacturas");
                    p.Ventas_VenderPagoServicio = BoolDeRow(rowDet, "Ventas_VenderPagoServicio");
                    p.Ventas_VenderRecargasElectronicas = BoolDeRow(rowDet, "Ventas_VenderRecargasElectronicas");
                    p.Ventas_UsarBuscadorProductos = BoolDeRow(rowDet, "Ventas_UsarBuscadorProductos");

                    p.Clientes_CrearModificarEliminar = BoolDeRow(rowDet, "Clientes_CrearModificarEliminar");
                    p.Clientes_AsignarClienteVenta = BoolDeRow(rowDet, "Clientes_AsignarClienteVenta");
                    p.Clientes_AsignarRemoverCredito = BoolDeRow(rowDet, "Clientes_AsignarRemoverCredito");
                    p.Clientes_VerCuentaRecibirAbonosReportesCredito = BoolDeRow(rowDet, "Clientes_VerCuentaRecibirAbonosReportesCredito");

                    p.Productos_CrearNuevos = BoolDeRow(rowDet, "Productos_CrearNuevos");
                    p.Productos_Modificar = BoolDeRow(rowDet, "Productos_Modificar");
                    p.Productos_Eliminar = BoolDeRow(rowDet, "Productos_Eliminar");
                    p.Productos_VerReporteVentas = BoolDeRow(rowDet, "Productos_VerReporteVentas");
                    p.Productos_CrearPromociones = BoolDeRow(rowDet, "Productos_CrearPromociones");
                    p.Productos_ModificarVarios = BoolDeRow(rowDet, "Productos_ModificarVarios");

                    p.Inventario_AgregarMercancia = BoolDeRow(rowDet, "Inventario_AgregarMercancia");
                    p.Inventario_VerReportesExistenciasMinimos = BoolDeRow(rowDet, "Inventario_VerReportesExistenciasMinimos");
                    p.Inventario_VerMovimientoInventarios = BoolDeRow(rowDet, "Inventario_VerMovimientoInventarios");
                    p.Inventario_AjustarInventario = BoolDeRow(rowDet, "Inventario_AjustarInventario");

                    p.Otros_RealizarCorteSuTurno = BoolDeRow(rowDet, "Otros_RealizarCorteSuTurno");
                    p.Otros_RealizarCorteTodosTurnos = BoolDeRow(rowDet, "Otros_RealizarCorteTodosTurnos");
                    p.Otros_RealizarCorteDelDia = BoolDeRow(rowDet, "Otros_RealizarCorteDelDia");
                    p.Otros_VerGananciaDelDia = BoolDeRow(rowDet, "Otros_VerGananciaDelDia");
                    p.Otros_CambiarConfiguracionPrograma = BoolDeRow(rowDet, "Otros_CambiarConfiguracionPrograma");
                    p.Otros_AccederReportesVentasGanancias = BoolDeRow(rowDet, "Otros_AccederReportesVentasGanancias");
                    p.Otros_CrearOrdenesCompra = BoolDeRow(rowDet, "Otros_CrearOrdenesCompra");
                    p.Otros_RecibirOrdenesCompra = BoolDeRow(rowDet, "Otros_RecibirOrdenesCompra");
                }
                else
                {
                    // Fallback a permisos anteriores (2 checks)
                    DataRow perms = DatabaseHelper.ObtenerPermisosUsuario(_idEditando, false);
                    bool pv = perms != null && perms.Table.Columns.Contains("PermisoVentas") && perms["PermisoVentas"] != DBNull.Value && Convert.ToBoolean(perms["PermisoVentas"]);
                    bool pap = perms != null && perms.Table.Columns.Contains("PermisoAgregarProductos") && perms["PermisoAgregarProductos"] != DBNull.Value && Convert.ToBoolean(perms["PermisoAgregarProductos"]);
                    if (pv) p.Ventas_CobrarTicket = true;
                    if (pap) p.Productos_CrearNuevos = true;
                }

                CargarPermisosEnEditor(p);
            }
            catch
            {
                CargarPermisosEnEditor(new UsuarioPermisosDetalle());
            }

            AplicarRolEnEditor();
            _txtNombre.Focus();
        }

        private void CargarEditorDesdeSeleccion()
        {
            if (_pnlEditor != null && !_pnlEditor.Visible)
                _pnlEditor.Visible = true;

            if (_modoNuevo)
                return;

            DataRowView row = GetSelectedRow();
            if (row == null)
                return;

            // Si estás creando una cuenta nueva, no pisar la captura al seleccionar algo
            if (_idEditando <= 0 && _txtUsuario != null && _txtUsuario.Enabled && !string.IsNullOrWhiteSpace(_txtUsuario.Text))
                return;

            AbrirEditorEditarSeleccionado();
        }

        private void AplicarFiltroUsuarios()
        {
            if (_usuariosView == null)
                return;

            string t = (_txtBuscar == null ? string.Empty : (_txtBuscar.Text ?? string.Empty)).Trim().Replace("'", "''");
            if (string.IsNullOrWhiteSpace(t))
            {
                _usuariosView.RowFilter = string.Empty;
            }
            else
            {
                _usuariosView.RowFilter = string.Format("Usuario LIKE '%{0}%' OR Nombre LIKE '%{0}%'", t);
            }
        }

        private void CerrarEditor()
        {
            _pnlEditor.Visible = false;
            _idEditando = 0;
        }

        private void CambiarActivoSeleccionado(bool activo)
        {
            DataRowView row = GetSelectedRow();
            if (row == null)
                return;

            int id = Convert.ToInt32(row["IdUsuario"]);
            if (!DatabaseHelper.CambiarActivoUsuarioInicioSeccion(id, activo, true))
                return;

            CargarUsuarios();
        }

        private void GuardarEditor()
        {
            string usuario = (_txtUsuario == null ? string.Empty : (_txtUsuario.Text ?? string.Empty)).Trim();
            string nombre = (_txtNombre == null ? string.Empty : (_txtNombre.Text ?? string.Empty)).Trim();
            string pass = _txtPass == null ? string.Empty : (_txtPass.Text ?? string.Empty);
            bool activo = _chkActivo != null && _chkActivo.Checked;
            string rol = _cboRol == null ? "Cajero" : Convert.ToString(_cboRol.SelectedItem);
            if (string.IsNullOrWhiteSpace(rol)) rol = "Cajero";

            bool esAdmin = string.Equals((rol ?? string.Empty).Trim(), "Administrador", StringComparison.OrdinalIgnoreCase);
            UsuarioPermisosDetalle detalle = esAdmin ? UsuarioPermisosDetalle.CrearTodoHabilitado() : LeerPermisosDesdeEditor();
            bool permisoVentasCompat = detalle != null && (
                detalle.Ventas_UtilizarProductoComun || detalle.Ventas_AplicarMayoreo || detalle.Ventas_AplicarDescuento ||
                detalle.Ventas_RevisarHistorialVentas || detalle.Ventas_RegistrarEntradasEfectivo || detalle.Ventas_RegistrarSalidasEfectivo ||
                detalle.Ventas_CobrarTicket || detalle.Ventas_CobrarCredito || detalle.Ventas_CancelarTicketsDevolverArticulos ||
                detalle.Ventas_EliminarArticulosVenta || detalle.Ventas_FacturarVerFacturas || detalle.Ventas_VenderPagoServicio ||
                detalle.Ventas_VenderRecargasElectronicas || detalle.Ventas_UsarBuscadorProductos);
            bool permisoAgregarProductosCompat = detalle != null && detalle.Productos_CrearNuevos;

            if (_idEditando <= 0)
            {
                if (string.IsNullOrWhiteSpace(usuario))
                {
                    MessageBox.Show("Captura un usuario.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    if (_txtUsuario != null) _txtUsuario.Focus();
                    return;
                }

                if (string.IsNullOrWhiteSpace(pass))
                {
                    MessageBox.Show("Captura una contraseña.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    if (_txtPass != null) _txtPass.Focus();
                    return;
                }

                if (!DatabaseHelper.CrearUsuarioInicioSeccion(usuario, nombre, pass, rol, true))
                    return;

                int idNuevo = 0;
                try
                {
                    DataRow info = DatabaseHelper.ObtenerInfoUsuarioInicioSeccion(usuario, false);
                    if (info != null && info["IdUsuario"] != DBNull.Value)
                        idNuevo = Convert.ToInt32(info["IdUsuario"]);
                }
                catch
                {
                }

                if (idNuevo > 0)
                {
                    DatabaseHelper.GuardarPermisosDetalleUsuario(idNuevo, detalle, false);
                    DatabaseHelper.GuardarPermisosUsuario(idNuevo, permisoVentasCompat, permisoAgregarProductosCompat, false);
                }

                if (!activo)
                {
                    try
                    {
                        if (idNuevo > 0)
                            DatabaseHelper.CambiarActivoUsuarioInicioSeccion(idNuevo, false, false);
                    }
                    catch
                    {
                    }
                }
            }
            else
            {
                if (!DatabaseHelper.ActualizarUsuarioInicioSeccion(_idEditando, nombre, pass, rol, activo, true))
                    return;

                DatabaseHelper.GuardarPermisosDetalleUsuario(_idEditando, detalle, false);
                DatabaseHelper.GuardarPermisosUsuario(_idEditando, permisoVentasCompat, permisoAgregarProductosCompat, false);
            }

            CargarUsuarios();
            CerrarEditor();
        }

        private void CargarUsuarios()
        {
            DataTable dt = DatabaseHelper.ObtenerUsuariosInicioSeccion(false, false);
            if (dt == null)
                return;

            _usuariosView = dt.DefaultView;
            _dgv.DataSource = _usuariosView;
            AplicarFiltroUsuarios();

            if (_pnlEditor != null)
                _pnlEditor.Visible = true;

            try
            {
                if (_dgv.Rows.Count > 0 && _dgv.CurrentRow == null)
                {
                    _dgv.ClearSelection();
                    _dgv.Rows[0].Selected = true;
                    _dgv.CurrentCell = _dgv.Rows[0].Cells[0];
                }
            }
            catch
            {
            }
        }
    }
}
