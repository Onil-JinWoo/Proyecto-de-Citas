using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace Abarrote
{
    public partial class InventarioUserControl : UserControl
    {
        private enum InventarioModo
        {
            Agregar,
            Ajustes,
            ProductosBajos,
            ReporteInventario,
            ReporteMovimientos,
            Kardex
        }

        private ProductoInfo _producto;

        private InventarioModo _modo = InventarioModo.Agregar;

        private Panel _pnlAgregar;
        private Panel _pnlAjustes;
        private Panel _pnlBajos;
        private Panel _pnlReporte;
        private Panel _pnlMovimientos;
        private Panel _pnlKardex;

        private Label _lblDescripcion;
        private Label _lblHay;
        private NumericUpDown _numAgregar;
        private NumericUpDown _numCosto;
        private NumericUpDown _numVenta;
        private NumericUpDown _numMayoreo;
        private Button _btnGuardar;
        private Label _lblMensaje;

        private Label _lblAjDescripcion;
        private Label _lblAjActual;
        private NumericUpDown _numAjDelta;
        private TextBox _txtAjNueva;
        private NumericUpDown _numAjCosto;
        private NumericUpDown _numAjVenta;
        private NumericUpDown _numAjMayoreo;
        private TextBox _txtAjMotivo;
        private Button _btnAjGuardar;
        private Label _lblAjMensaje;

        private DataGridView _dgvBajos;
        private Label _lblBajosInfo;

        private ComboBox _cmbRepDepto;
        private Label _lblRepCostoValor;
        private Label _lblRepCantidadValor;
        private DataGridView _dgvRep;

        private DateTimePicker _dtMovDia;
        private ComboBox _cmbMovTipo;
        private TextBox _txtMovBuscar;
        private DataGridView _dgvMov;

        private TextBox _txtKardexCodigo;
        private ComboBox _cmbKardexPeriodo;
        private Label _lblKardexProducto;
        private Label _lblKardexDepto;
        private Label _lblKardexMin;
        private Label _lblKardexMax;
        private Label _lblKardexExist;
        private DataGridView _dgvKardex;

        public InventarioUserControl()
        {
            InitializeComponent();

            if (txtCodigoProducto != null)
                txtCodigoProducto.KeyDown += TxtCodigoProducto_KeyDown;
            if (btnAgregar != null)
                btnAgregar.Click += (s, e) => CambiarModo(InventarioModo.Agregar);
            if (btnAjustes != null)
                btnAjustes.Click += (s, e) => CambiarModo(InventarioModo.Ajustes);
            if (btnProductosBajos != null)
                btnProductosBajos.Click += (s, e) => CambiarModo(InventarioModo.ProductosBajos);
            if (btnReporteInventario != null)
                btnReporteInventario.Click += (s, e) => CambiarModo(InventarioModo.ReporteInventario);
            if (btnReporteMovimientos != null)
                btnReporteMovimientos.Click += (s, e) => CambiarModo(InventarioModo.ReporteMovimientos);
            if (btnKardex != null)
                btnKardex.Click += (s, e) => CambiarModo(InventarioModo.Kardex);

            EnsureEditorEmbebido();
            CambiarModo(InventarioModo.Agregar);
        }

        private void TxtCodigoProducto_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                if (_modo == InventarioModo.Ajustes)
                {
                    CargarProductoParaAjuste();
                }
                else if (_modo == InventarioModo.Agregar)
                {
                    CargarProductoDesdeCodigo();
                }
            }
        }

        private void CambiarModo(InventarioModo modo)
        {
            _modo = modo;

            EnsureEditorEmbebido();
            EnsureAjustesEmbebido();
            EnsureBajosEmbebido();
            EnsureReporteInventarioEmbebido();
            EnsureMovimientosEmbebido();
            EnsureKardexEmbebido();

            bool mostrarCodigoProducto = (_modo == InventarioModo.Agregar || _modo == InventarioModo.Ajustes);
            if (txtCodigoProducto != null) txtCodigoProducto.Visible = mostrarCodigoProducto;
            if (lblCodigoProducto != null) lblCodigoProducto.Visible = mostrarCodigoProducto;

            if (lblAgregarInventario != null)
            {
                if (_modo == InventarioModo.Agregar) lblAgregarInventario.Text = "AGREGAR INVENTARIO";
                else if (_modo == InventarioModo.Ajustes) lblAgregarInventario.Text = "AJUSTES DE INVENTARIO";
                else if (_modo == InventarioModo.ProductosBajos) lblAgregarInventario.Text = "PRODUCTOS BAJOS EN INVENTARIO";
                else if (_modo == InventarioModo.ReporteInventario) lblAgregarInventario.Text = "REPORTE DE INVENTARIO";
                else if (_modo == InventarioModo.ReporteMovimientos) lblAgregarInventario.Text = "REPORTE DE MOVIMIENTOS";
                else if (_modo == InventarioModo.Kardex) lblAgregarInventario.Text = "KARDEX DE INVENTARIO";
            }

            if (_pnlAgregar != null) _pnlAgregar.Visible = (_modo == InventarioModo.Agregar);
            if (_pnlAjustes != null) _pnlAjustes.Visible = (_modo == InventarioModo.Ajustes);
            if (_pnlBajos != null) _pnlBajos.Visible = (_modo == InventarioModo.ProductosBajos);
            if (_pnlReporte != null) _pnlReporte.Visible = (_modo == InventarioModo.ReporteInventario);
            if (_pnlMovimientos != null) _pnlMovimientos.Visible = (_modo == InventarioModo.ReporteMovimientos);
            if (_pnlKardex != null) _pnlKardex.Visible = (_modo == InventarioModo.Kardex);

            if (_modo == InventarioModo.Ajustes)
                LimpiarAjustes();
            else if (_modo == InventarioModo.ProductosBajos)
                CargarProductosBajos();
            else if (_modo == InventarioModo.ReporteInventario)
                CargarReporteInventario();
            else if (_modo == InventarioModo.ReporteMovimientos)
                CargarMovimientosInventario();
            else if (_modo == InventarioModo.Kardex)
                PrepararKardex();
            else
                LimpiarEditor();

            if (_modo == InventarioModo.Kardex)
            {
                if (_txtKardexCodigo != null)
                {
                    _txtKardexCodigo.Focus();
                    _txtKardexCodigo.SelectAll();
                }
            }
            else if (_modo == InventarioModo.ReporteMovimientos)
            {
                if (_txtMovBuscar != null)
                {
                    _txtMovBuscar.Focus();
                    _txtMovBuscar.SelectAll();
                }
            }
            else
            {
                EnfocarCodigoProducto();
            }
        }

        private void EnfocarCodigoProducto()
        {
            if (txtCodigoProducto != null)
            {
                txtCodigoProducto.Focus();
                txtCodigoProducto.SelectAll();
            }
        }

        private void EnsureEditorEmbebido()
        {
            if (pnlAgregarInventario == null)
                return;
            if (_lblDescripcion != null)
                return;

            pnlAgregarInventario.AutoScroll = true;

            _pnlAgregar = new Panel();
            _pnlAgregar.Dock = DockStyle.Fill;
            _pnlAgregar.BackColor = Color.Transparent;

            _pnlAjustes = new Panel();
            _pnlAjustes.Dock = DockStyle.Fill;
            _pnlAjustes.BackColor = Color.Transparent;
            _pnlAjustes.Visible = false;

            _pnlBajos = new Panel();
            _pnlBajos.Dock = DockStyle.Fill;
            _pnlBajos.BackColor = Color.Transparent;
            _pnlBajos.Visible = false;

            _pnlReporte = new Panel();
            _pnlReporte.Dock = DockStyle.Fill;
            _pnlReporte.BackColor = Color.Transparent;
            _pnlReporte.Visible = false;

            _pnlMovimientos = new Panel();
            _pnlMovimientos.Dock = DockStyle.Fill;
            _pnlMovimientos.BackColor = Color.Transparent;
            _pnlMovimientos.Visible = false;

            _pnlKardex = new Panel();
            _pnlKardex.Dock = DockStyle.Fill;
            _pnlKardex.BackColor = Color.Transparent;
            _pnlKardex.Visible = false;

            pnlAgregarInventario.Controls.Add(_pnlKardex);
            pnlAgregarInventario.Controls.Add(_pnlMovimientos);
            pnlAgregarInventario.Controls.Add(_pnlReporte);
            pnlAgregarInventario.Controls.Add(_pnlBajos);
            pnlAgregarInventario.Controls.Add(_pnlAjustes);
            pnlAgregarInventario.Controls.Add(_pnlAgregar);

            int xLabel = 25;
            int xValue = 135;

            Label lblDesc = new Label();
            lblDesc.AutoSize = true;
            lblDesc.Font = new Font("Segoe UI", 9F);
            lblDesc.Text = "Descripción";
            lblDesc.Location = new Point(xLabel + 35, 105);

            _lblDescripcion = new Label();
            _lblDescripcion.AutoSize = false;
            _lblDescripcion.Font = new Font("Segoe UI", 9F);
            _lblDescripcion.Location = new Point(xValue, 105);
            _lblDescripcion.Size = new Size(780, 20);

            Label lblHay = new Label();
            lblHay.AutoSize = true;
            lblHay.Font = new Font("Segoe UI", 9F);
            lblHay.Text = "Hay";
            lblHay.Location = new Point(xLabel + 70, 135);

            _lblHay = new Label();
            _lblHay.AutoSize = false;
            _lblHay.Font = new Font("Segoe UI", 9F);
            _lblHay.Location = new Point(xValue, 135);
            _lblHay.Size = new Size(120, 20);

            Label lblAgregar = new Label();
            lblAgregar.AutoSize = true;
            lblAgregar.Font = new Font("Segoe UI", 9F);
            lblAgregar.Text = "Agregar";
            lblAgregar.Location = new Point(xLabel + 52, 165);

            _numAgregar = new NumericUpDown();
            _numAgregar.Location = new Point(xValue, 162);
            _numAgregar.Size = new Size(120, 23);
            _numAgregar.Maximum = 1000000;
            _numAgregar.DecimalPlaces = 0;

            Label lblCosto = new Label();
            lblCosto.AutoSize = true;
            lblCosto.Font = new Font("Segoe UI", 9F);
            lblCosto.Text = "Precio Costo";
            lblCosto.Location = new Point(xLabel + 40, 197);

            _numCosto = new NumericUpDown();
            _numCosto.Location = new Point(xValue, 194);
            _numCosto.Size = new Size(120, 23);
            _numCosto.Maximum = 100000000;
            _numCosto.DecimalPlaces = 2;
            _numCosto.ThousandsSeparator = true;

            Label lblVenta = new Label();
            lblVenta.AutoSize = true;
            lblVenta.Font = new Font("Segoe UI", 9F);
            lblVenta.Text = "Precio Venta";
            lblVenta.Location = new Point(xLabel + 42, 229);

            _numVenta = new NumericUpDown();
            _numVenta.Location = new Point(xValue, 226);
            _numVenta.Size = new Size(120, 23);
            _numVenta.Maximum = 100000000;
            _numVenta.DecimalPlaces = 2;
            _numVenta.ThousandsSeparator = true;

            Label lblMayoreo = new Label();
            lblMayoreo.AutoSize = true;
            lblMayoreo.Font = new Font("Segoe UI", 9F);
            lblMayoreo.Text = "Precio Mayoreo";
            lblMayoreo.Location = new Point(xLabel + 22, 261);

            _numMayoreo = new NumericUpDown();
            _numMayoreo.Location = new Point(xValue, 258);
            _numMayoreo.Size = new Size(120, 23);
            _numMayoreo.Maximum = 100000000;
            _numMayoreo.DecimalPlaces = 2;
            _numMayoreo.ThousandsSeparator = true;

            _btnGuardar = new Button();
            _btnGuardar.Text = "✓ Agregar cantidad a inventario";
            _btnGuardar.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            _btnGuardar.FlatStyle = FlatStyle.Flat;
            _btnGuardar.FlatAppearance.BorderColor = Color.Silver;
            _btnGuardar.Size = new Size(240, 34);
            _btnGuardar.Location = new Point(xValue, 292);
            _btnGuardar.Click += (s, e) => GuardarAjuste();

            _lblMensaje = new Label();
            _lblMensaje.AutoSize = false;
            _lblMensaje.Font = new Font("Segoe UI", 8.5F);
            _lblMensaje.ForeColor = Color.FromArgb(80, 80, 80);
            _lblMensaje.BackColor = Color.FromArgb(255, 249, 220);
            _lblMensaje.BorderStyle = BorderStyle.FixedSingle;
            _lblMensaje.Location = new Point(xValue, 332);
            _lblMensaje.Size = new Size(780, 40);
            _lblMensaje.Visible = false;

            _pnlAgregar.Controls.Add(lblDesc);
            _pnlAgregar.Controls.Add(_lblDescripcion);
            _pnlAgregar.Controls.Add(lblHay);
            _pnlAgregar.Controls.Add(_lblHay);
            _pnlAgregar.Controls.Add(lblAgregar);
            _pnlAgregar.Controls.Add(_numAgregar);
            _pnlAgregar.Controls.Add(lblCosto);
            _pnlAgregar.Controls.Add(_numCosto);
            _pnlAgregar.Controls.Add(lblVenta);
            _pnlAgregar.Controls.Add(_numVenta);
            _pnlAgregar.Controls.Add(lblMayoreo);
            _pnlAgregar.Controls.Add(_numMayoreo);
            _pnlAgregar.Controls.Add(_btnGuardar);
            _pnlAgregar.Controls.Add(_lblMensaje);

            LimpiarEditor();
        }

        private void EnsureReporteInventarioEmbebido()
        {
            if (_pnlReporte == null)
                return;
            if (_dgvRep != null)
                return;

            Panel header = new Panel();
            header.Dock = DockStyle.Top;
            header.Height = 160;
            header.BackColor = Color.Transparent;

            Label lblCosto = new Label();
            lblCosto.AutoSize = true;
            lblCosto.Font = new Font("Segoe UI", 8.5F, FontStyle.Bold);
            lblCosto.ForeColor = Color.FromArgb(80, 80, 80);
            lblCosto.Text = "Costo del inventario";
            lblCosto.Location = new Point(20, 10);

            _lblRepCostoValor = new Label();
            _lblRepCostoValor.AutoSize = true;
            _lblRepCostoValor.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            _lblRepCostoValor.ForeColor = Color.FromArgb(80, 80, 80);
            _lblRepCostoValor.Text = "$0.00";
            _lblRepCostoValor.Location = new Point(20, 27);

            Label lblCantidad = new Label();
            lblCantidad.AutoSize = true;
            lblCantidad.Font = new Font("Segoe UI", 8.5F, FontStyle.Bold);
            lblCantidad.ForeColor = Color.FromArgb(80, 80, 80);
            lblCantidad.Text = "Cantidad de productos en Inventario";
            lblCantidad.Location = new Point(260, 10);

            _lblRepCantidadValor = new Label();
            _lblRepCantidadValor.AutoSize = true;
            _lblRepCantidadValor.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            _lblRepCantidadValor.ForeColor = Color.FromArgb(80, 80, 80);
            _lblRepCantidadValor.Text = "0";
            _lblRepCantidadValor.Location = new Point(260, 27);

            Label lblDepto = new Label();
            lblDepto.AutoSize = true;
            lblDepto.Font = new Font("Segoe UI", 9F);
            lblDepto.ForeColor = Color.FromArgb(70, 70, 70);
            lblDepto.Text = "Departamento:";
            lblDepto.Location = new Point(20, 80);

            _cmbRepDepto = new ComboBox();
            _cmbRepDepto.DropDownStyle = ComboBoxStyle.DropDownList;
            _cmbRepDepto.Location = new Point(110, 76);
            _cmbRepDepto.Size = new Size(320, 23);
            _cmbRepDepto.SelectedIndexChanged += (s, e) => CargarReporteInventario();

            Panel pnlInfo = new Panel();
            pnlInfo.Location = new Point(20, 110);
            pnlInfo.Size = new Size(980, 30);
            pnlInfo.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            pnlInfo.BackColor = Color.FromArgb(255, 249, 220);
            pnlInfo.BorderStyle = BorderStyle.FixedSingle;

            Label lblInfo = new Label();
            lblInfo.Dock = DockStyle.Fill;
            lblInfo.Font = new Font("Segoe UI", 8.5F);
            lblInfo.ForeColor = Color.FromArgb(80, 80, 80);
            lblInfo.TextAlign = ContentAlignment.MiddleLeft;
            lblInfo.Padding = new Padding(8, 0, 8, 0);
            lblInfo.Text = "Ahora en este reporte solo se muestran los productos que manejan inventario.";
            pnlInfo.Controls.Add(lblInfo);

            header.Controls.Add(lblCosto);
            header.Controls.Add(_lblRepCostoValor);
            header.Controls.Add(lblCantidad);
            header.Controls.Add(_lblRepCantidadValor);
            header.Controls.Add(lblDepto);
            header.Controls.Add(_cmbRepDepto);
            header.Controls.Add(pnlInfo);

            _dgvRep = new DataGridView();
            _dgvRep.Dock = DockStyle.Fill;
            _dgvRep.ReadOnly = true;
            _dgvRep.AllowUserToAddRows = false;
            _dgvRep.AllowUserToDeleteRows = false;
            _dgvRep.MultiSelect = false;
            _dgvRep.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            _dgvRep.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            _dgvRep.RowHeadersVisible = false;

            _pnlReporte.Padding = new Padding(20);
            _pnlReporte.Controls.Add(_dgvRep);
            _pnlReporte.Controls.Add(header);
        }

        private void CargarReporteInventario()
        {
            EnsureReporteInventarioEmbebido();
            if (_dgvRep == null)
                return;

            string depto = "TODOS";
            if (_cmbRepDepto != null && _cmbRepDepto.SelectedItem != null)
                depto = _cmbRepDepto.SelectedItem.ToString();

            string err;
            decimal costoTotal;
            int cantidadProductos;
            DataTable dt = DatabaseHelper.ObtenerReporteInventario(depto, out costoTotal, out cantidadProductos, out err);
            if (!string.IsNullOrWhiteSpace(err))
                MessageBox.Show(err, "Inventario", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            _dgvRep.DataSource = dt;

            if (_lblRepCostoValor != null) _lblRepCostoValor.Text = costoTotal.ToString("C2", CultureInfo.CurrentCulture);
            if (_lblRepCantidadValor != null) _lblRepCantidadValor.Text = cantidadProductos.ToString(CultureInfo.CurrentCulture);

            if (_cmbRepDepto != null && _cmbRepDepto.Items.Count == 0)
            {
                List<string> deptos = DatabaseHelper.ObtenerDepartamentosProductos(out err);
                if (!string.IsNullOrWhiteSpace(err))
                {
                    MessageBox.Show(err, "Inventario", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                _cmbRepDepto.Items.Clear();
                _cmbRepDepto.Items.Add("TODOS");
                for (int i = 0; i < deptos.Count; i++)
                {
                    string d = deptos[i];
                    if (!string.IsNullOrWhiteSpace(d))
                        _cmbRepDepto.Items.Add(d);
                }

                if (_cmbRepDepto.Items.Count > 0)
                    _cmbRepDepto.SelectedIndex = 0;
            }
        }

        private void EnsureBajosEmbebido()
        {
            if (_pnlBajos == null)
                return;
            if (_dgvBajos != null)
                return;

            _lblBajosInfo = new Label();
            _lblBajosInfo.AutoSize = false;
            _lblBajosInfo.Font = new Font("Segoe UI", 9F);
            _lblBajosInfo.ForeColor = Color.FromArgb(60, 60, 60);
            _lblBajosInfo.Location = new Point(20, 70);
            _lblBajosInfo.Size = new Size(950, 30);
            _lblBajosInfo.Text = "A continuación se muestra un listado con los productos con inventario debajo de su mínimo:";

            _dgvBajos = new DataGridView();
            _dgvBajos.Location = new Point(20, 105);
            _dgvBajos.Size = new Size(980, 420);
            _dgvBajos.ReadOnly = true;
            _dgvBajos.AllowUserToAddRows = false;
            _dgvBajos.AllowUserToDeleteRows = false;
            _dgvBajos.MultiSelect = false;
            _dgvBajos.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            _dgvBajos.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            _dgvBajos.RowHeadersVisible = false;

            _pnlBajos.Controls.Add(_lblBajosInfo);
            _pnlBajos.Controls.Add(_dgvBajos);
        }

        private void CargarProductosBajos()
        {
            EnsureEditorEmbebido();
            EnsureBajosEmbebido();

            string err;
            var dt = DatabaseHelper.ObtenerProductosBajosInventario(out err);
            if (!string.IsNullOrWhiteSpace(err))
            {
                MessageBox.Show(err, "Inventario", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            if (_dgvBajos != null)
                _dgvBajos.DataSource = dt;

            if (txtCodigoProducto != null)
                txtCodigoProducto.Clear();
        }

        private void EnsureMovimientosEmbebido()
        {
            if (_pnlMovimientos == null)
                return;
            if (_dgvMov != null)
                return;

            Label lblDia = new Label();
            lblDia.AutoSize = true;
            lblDia.Font = new Font("Segoe UI", 9F);
            lblDia.Text = "Del día:";
            lblDia.Location = new Point(20, 70);

            _dtMovDia = new DateTimePicker();
            _dtMovDia.Format = DateTimePickerFormat.Short;
            _dtMovDia.Location = new Point(70, 66);
            _dtMovDia.Size = new Size(120, 23);
            _dtMovDia.ValueChanged += (s, e) => CargarMovimientosInventario();

            Label lblBuscar = new Label();
            lblBuscar.AutoSize = true;
            lblBuscar.Font = new Font("Segoe UI", 9F);
            lblBuscar.Text = "Buscar por:";
            lblBuscar.Location = new Point(210, 70);

            _txtMovBuscar = new TextBox();
            _txtMovBuscar.Location = new Point(280, 66);
            _txtMovBuscar.Size = new Size(250, 23);
            _txtMovBuscar.TextChanged += (s, e) => CargarMovimientosInventario();

            Label lblTipo = new Label();
            lblTipo.AutoSize = true;
            lblTipo.Font = new Font("Segoe UI", 9F);
            lblTipo.Text = "Movimientos";
            lblTipo.Location = new Point(550, 70);

            _cmbMovTipo = new ComboBox();
            _cmbMovTipo.DropDownStyle = ComboBoxStyle.DropDownList;
            _cmbMovTipo.Location = new Point(635, 66);
            _cmbMovTipo.Size = new Size(140, 23);
            _cmbMovTipo.Items.AddRange(new object[] { "TODOS", "ENTRADA", "SALIDA", "AJUSTE" });
            _cmbMovTipo.SelectedIndex = 0;
            _cmbMovTipo.SelectedIndexChanged += (s, e) => CargarMovimientosInventario();

            _dgvMov = new DataGridView();
            _dgvMov.Location = new Point(20, 105);
            _dgvMov.Size = new Size(980, 420);
            _dgvMov.ReadOnly = true;
            _dgvMov.AllowUserToAddRows = false;
            _dgvMov.AllowUserToDeleteRows = false;
            _dgvMov.MultiSelect = false;
            _dgvMov.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            _dgvMov.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            _dgvMov.RowHeadersVisible = false;

            _pnlMovimientos.Controls.Add(lblDia);
            _pnlMovimientos.Controls.Add(_dtMovDia);
            _pnlMovimientos.Controls.Add(lblBuscar);
            _pnlMovimientos.Controls.Add(_txtMovBuscar);
            _pnlMovimientos.Controls.Add(lblTipo);
            _pnlMovimientos.Controls.Add(_cmbMovTipo);
            _pnlMovimientos.Controls.Add(_dgvMov);
        }

        private void CargarMovimientosInventario()
        {
            EnsureMovimientosEmbebido();
            if (_dtMovDia == null || _dgvMov == null)
                return;

            DateTime dia = _dtMovDia.Value.Date;
            DateTime desde = dia;
            DateTime hasta = dia.AddDays(1);
            string tipo = _cmbMovTipo == null ? "TODOS" : (_cmbMovTipo.SelectedItem == null ? "TODOS" : _cmbMovTipo.SelectedItem.ToString());
            string buscar = _txtMovBuscar == null ? string.Empty : _txtMovBuscar.Text;

            string err;
            var dt = DatabaseHelper.ObtenerMovimientosInventario(desde, hasta, tipo, buscar, out err);
            if (!string.IsNullOrWhiteSpace(err))
                MessageBox.Show(err, "Inventario", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            _dgvMov.DataSource = dt;
        }

        private void EnsureKardexEmbebido()
        {
            if (_pnlKardex == null)
                return;
            if (_dgvKardex != null)
                return;

            Label lblCodigo = new Label();
            lblCodigo.AutoSize = true;
            lblCodigo.Font = new Font("Segoe UI", 9F);
            lblCodigo.Text = "Código del Producto";
            lblCodigo.Location = new Point(20, 70);

            _txtKardexCodigo = new TextBox();
            _txtKardexCodigo.Location = new Point(140, 66);
            _txtKardexCodigo.Size = new Size(250, 23);
            _txtKardexCodigo.KeyDown += (s, e) =>
            {
                if (e.KeyCode == Keys.Enter)
                {
                    e.SuppressKeyPress = true;
                    CargarKardex();
                }
            };

            Label lblPeriodo = new Label();
            lblPeriodo.AutoSize = true;
            lblPeriodo.Font = new Font("Segoe UI", 9F);
            lblPeriodo.Text = "Periodo:";
            lblPeriodo.Location = new Point(420, 70);

            _cmbKardexPeriodo = new ComboBox();
            _cmbKardexPeriodo.DropDownStyle = ComboBoxStyle.DropDownList;
            _cmbKardexPeriodo.Location = new Point(475, 66);
            _cmbKardexPeriodo.Size = new Size(160, 23);
            _cmbKardexPeriodo.Items.AddRange(new object[] { "DESDE EL COMIENZO", "HOY", "7 DÍAS", "30 DÍAS" });
            _cmbKardexPeriodo.SelectedIndex = 0;
            _cmbKardexPeriodo.SelectedIndexChanged += (s, e) => CargarKardex();

            _lblKardexProducto = new Label();
            _lblKardexProducto.Font = new Font("Segoe UI", 9F);
            _lblKardexProducto.Location = new Point(20, 110);
            _lblKardexProducto.Size = new Size(450, 18);

            _lblKardexDepto = new Label();
            _lblKardexDepto.Font = new Font("Segoe UI", 9F);
            _lblKardexDepto.Location = new Point(20, 132);
            _lblKardexDepto.Size = new Size(450, 18);

            _lblKardexMin = new Label();
            _lblKardexMin.Font = new Font("Segoe UI", 9F);
            _lblKardexMin.Location = new Point(520, 110);
            _lblKardexMin.Size = new Size(220, 18);

            _lblKardexMax = new Label();
            _lblKardexMax.Font = new Font("Segoe UI", 9F);
            _lblKardexMax.Location = new Point(520, 132);
            _lblKardexMax.Size = new Size(220, 18);

            _lblKardexExist = new Label();
            _lblKardexExist.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            _lblKardexExist.Location = new Point(760, 121);
            _lblKardexExist.Size = new Size(240, 18);

            _dgvKardex = new DataGridView();
            _dgvKardex.Location = new Point(20, 170);
            _dgvKardex.Size = new Size(980, 355);
            _dgvKardex.ReadOnly = true;
            _dgvKardex.AllowUserToAddRows = false;
            _dgvKardex.AllowUserToDeleteRows = false;
            _dgvKardex.MultiSelect = false;
            _dgvKardex.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            _dgvKardex.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            _dgvKardex.RowHeadersVisible = false;

            _pnlKardex.Controls.Add(lblCodigo);
            _pnlKardex.Controls.Add(_txtKardexCodigo);
            _pnlKardex.Controls.Add(lblPeriodo);
            _pnlKardex.Controls.Add(_cmbKardexPeriodo);
            _pnlKardex.Controls.Add(_lblKardexProducto);
            _pnlKardex.Controls.Add(_lblKardexDepto);
            _pnlKardex.Controls.Add(_lblKardexMin);
            _pnlKardex.Controls.Add(_lblKardexMax);
            _pnlKardex.Controls.Add(_lblKardexExist);
            _pnlKardex.Controls.Add(_dgvKardex);
        }

        private void PrepararKardex()
        {
            EnsureKardexEmbebido();
            if (_txtKardexCodigo != null)
            {
                _txtKardexCodigo.Focus();
                _txtKardexCodigo.SelectAll();
            }
        }

        private void CargarKardex()
        {
            EnsureKardexEmbebido();
            if (_txtKardexCodigo == null || _dgvKardex == null)
                return;

            string codigo = (_txtKardexCodigo.Text ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(codigo))
                return;

            DateTime hasta = DateTime.Now.Date.AddDays(1);
            DateTime desde = new DateTime(1753, 1, 1);
            string per = _cmbKardexPeriodo == null || _cmbKardexPeriodo.SelectedItem == null ? "DESDE EL COMIENZO" : _cmbKardexPeriodo.SelectedItem.ToString();
            if (string.Equals(per, "HOY", StringComparison.OrdinalIgnoreCase))
                desde = DateTime.Now.Date;
            else if (string.Equals(per, "7 DÍAS", StringComparison.OrdinalIgnoreCase))
                desde = DateTime.Now.Date.AddDays(-7);
            else if (string.Equals(per, "30 DÍAS", StringComparison.OrdinalIgnoreCase))
                desde = DateTime.Now.Date.AddDays(-30);

            ProductoInfo p;
            string err;
            var dt = DatabaseHelper.ObtenerKardexProducto(codigo, desde, hasta, out p, out err);
            if (!string.IsNullOrWhiteSpace(err))
            {
                MessageBox.Show(err, "Inventario", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            _dgvKardex.DataSource = dt;

            if (p != null)
            {
                if (_lblKardexProducto != null) _lblKardexProducto.Text = "Producto: " + (p.Descripcion ?? string.Empty);
                if (_lblKardexDepto != null) _lblKardexDepto.Text = "Departamento: " + (p.Departamento ?? string.Empty);
                if (_lblKardexMin != null) _lblKardexMin.Text = "Inventario Mínimo: " + p.StockMinimo.ToString(CultureInfo.CurrentCulture);
                if (_lblKardexMax != null) _lblKardexMax.Text = "Inventario Máximo: " + p.StockMaximo.ToString(CultureInfo.CurrentCulture);
                if (_lblKardexExist != null) _lblKardexExist.Text = "Existencia Actual: " + p.StockActual.ToString(CultureInfo.CurrentCulture);
            }
            else
            {
                if (_lblKardexProducto != null) _lblKardexProducto.Text = "";
                if (_lblKardexDepto != null) _lblKardexDepto.Text = "";
                if (_lblKardexMin != null) _lblKardexMin.Text = "";
                if (_lblKardexMax != null) _lblKardexMax.Text = "";
                if (_lblKardexExist != null) _lblKardexExist.Text = "";
            }
        }

        private void CargarProductoParaAjuste()
        {
            EnsureEditorEmbebido();
            EnsureAjustesEmbebido();

            string codigo = txtCodigoProducto == null ? string.Empty : (txtCodigoProducto.Text ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(codigo))
                return;

            _producto = DatabaseHelper.ObtenerProductoPorCodigoBarras(codigo);
            if (_producto == null)
            {
                MessageBox.Show("Producto no encontrado.", "Inventario", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                EnfocarCodigoProducto();
                LimpiarAjustes();
                return;
            }

            if (_lblAjDescripcion != null) _lblAjDescripcion.Text = _producto.Descripcion;
            if (_lblAjActual != null) _lblAjActual.Text = _producto.StockActual.ToString(CultureInfo.CurrentCulture);
            if (_numAjDelta != null) _numAjDelta.Value = 0;
            if (_numAjCosto != null) _numAjCosto.Value = ClampDecimal(_producto.PrecioCosto, _numAjCosto.Maximum);
            if (_numAjVenta != null) _numAjVenta.Value = ClampDecimal(_producto.PrecioVenta, _numAjVenta.Maximum);
            if (_numAjMayoreo != null) _numAjMayoreo.Value = ClampDecimal(_producto.PrecioMayoreo, _numAjMayoreo.Maximum);
            if (_txtAjMotivo != null) _txtAjMotivo.Text = string.Empty;
            if (_lblAjMensaje != null) _lblAjMensaje.Visible = false;

            RecalcularNuevaCantidad();

            if (_numAjDelta != null)
            {
                _numAjDelta.Focus();
                _numAjDelta.Select(0, _numAjDelta.Text.Length);
            }
        }

        private void RecalcularNuevaCantidad()
        {
            if (_txtAjNueva == null)
                return;

            if (_producto == null)
            {
                _txtAjNueva.Text = string.Empty;
                return;
            }

            int delta = _numAjDelta == null ? 0 : (int)_numAjDelta.Value;
            int nueva = _producto.StockActual + delta;
            if (nueva < 0)
                nueva = 0;

            _txtAjNueva.Text = nueva.ToString(CultureInfo.CurrentCulture);
        }

        private void GuardarAjusteInventario()
        {
            if (_producto == null)
            {
                MessageBox.Show("Primero capture el código del producto y presione Enter.", "Inventario", MessageBoxButtons.OK, MessageBoxIcon.Information);
                EnfocarCodigoProducto();
                return;
            }

            int delta = _numAjDelta == null ? 0 : (int)_numAjDelta.Value;
            int nuevaCantidad = _producto.StockActual + delta;
            if (nuevaCantidad < 0)
                nuevaCantidad = 0;

            decimal costo = _numAjCosto == null ? 0m : _numAjCosto.Value;
            decimal venta = _numAjVenta == null ? 0m : _numAjVenta.Value;
            decimal mayoreo = _numAjMayoreo == null ? 0m : _numAjMayoreo.Value;

            string motivo = _txtAjMotivo == null ? string.Empty : (_txtAjMotivo.Text ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(motivo))
                motivo = "";

            string err;
            if (!DatabaseHelper.AjustarInventarioYActualizarPrecios(_producto.CodigoBarras, nuevaCantidad, costo, venta, mayoreo, out err))
            {
                MessageBox.Show(string.IsNullOrWhiteSpace(err) ? "No se pudo ajustar el inventario." : err, "Inventario", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (_lblAjMensaje != null)
            {
                _lblAjMensaje.Text = string.Format(CultureInfo.CurrentCulture,
                    "Se ajustó el inventario. Cantidad actual: {0}, cambio: {1}, nueva cantidad: {2}. Costo: {3}, Venta: {4}, Mayoreo: {5}.",
                    _producto.StockActual,
                    delta,
                    nuevaCantidad,
                    costo.ToString("C2"),
                    venta.ToString("C2"),
                    mayoreo.ToString("C2"));
                _lblAjMensaje.Visible = true;
            }

            txtCodigoProducto.Clear();
            EnfocarCodigoProducto();

            _producto.StockActual = nuevaCantidad;
            if (_lblAjActual != null) _lblAjActual.Text = _producto.StockActual.ToString(CultureInfo.CurrentCulture);
            if (_numAjDelta != null) _numAjDelta.Value = 0;
            RecalcularNuevaCantidad();
        }

        private void EnsureAjustesEmbebido()
        {
            if (_pnlAjustes == null)
                return;
            if (_lblAjDescripcion != null)
                return;

            int xLabel = 25;
            int xValue = 135;

            Label lblDesc = new Label();
            lblDesc.AutoSize = true;
            lblDesc.Font = new Font("Segoe UI", 9F);
            lblDesc.Text = "Descripción";
            lblDesc.Location = new Point(xLabel + 35, 105);

            _lblAjDescripcion = new Label();
            _lblAjDescripcion.AutoSize = false;
            _lblAjDescripcion.Font = new Font("Segoe UI", 9F);
            _lblAjDescripcion.Location = new Point(xValue, 105);
            _lblAjDescripcion.Size = new Size(780, 20);

            Label lblActual = new Label();
            lblActual.AutoSize = true;
            lblActual.Font = new Font("Segoe UI", 9F);
            lblActual.Text = "Cantidad Actual";
            lblActual.Location = new Point(xLabel + 16, 135);

            _lblAjActual = new Label();
            _lblAjActual.AutoSize = false;
            _lblAjActual.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            _lblAjActual.Location = new Point(xValue, 135);
            _lblAjActual.Size = new Size(120, 20);

            Label lblDelta = new Label();
            lblDelta.AutoSize = true;
            lblDelta.Font = new Font("Segoe UI", 9F);
            lblDelta.Text = "+ / -";
            lblDelta.Location = new Point(xLabel + 67, 165);

            _numAjDelta = new NumericUpDown();
            _numAjDelta.Location = new Point(xValue, 162);
            _numAjDelta.Size = new Size(120, 23);
            _numAjDelta.Minimum = -1000000;
            _numAjDelta.Maximum = 1000000;
            _numAjDelta.DecimalPlaces = 0;
            _numAjDelta.ValueChanged += (s, e) => RecalcularNuevaCantidad();

            Label lblNueva = new Label();
            lblNueva.AutoSize = true;
            lblNueva.Font = new Font("Segoe UI", 9F);
            lblNueva.Text = "Nueva Cantidad";
            lblNueva.Location = new Point(xLabel + 16, 197);

            _txtAjNueva = new TextBox();
            _txtAjNueva.Location = new Point(xValue, 194);
            _txtAjNueva.Size = new Size(120, 23);
            _txtAjNueva.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            _txtAjNueva.ReadOnly = true;
            _txtAjNueva.TextAlign = HorizontalAlignment.Right;

            Label lblCosto = new Label();
            lblCosto.AutoSize = true;
            lblCosto.Font = new Font("Segoe UI", 9F);
            lblCosto.Text = "Costo";
            lblCosto.Location = new Point(xLabel + 74, 229);

            _numAjCosto = new NumericUpDown();
            _numAjCosto.Location = new Point(xValue, 226);
            _numAjCosto.Size = new Size(120, 23);
            _numAjCosto.Maximum = 100000000;
            _numAjCosto.DecimalPlaces = 2;
            _numAjCosto.ThousandsSeparator = true;

            Label lblVenta = new Label();
            lblVenta.AutoSize = true;
            lblVenta.Font = new Font("Segoe UI", 9F);
            lblVenta.Text = "Precio Venta";
            lblVenta.Location = new Point(xLabel + 42, 261);

            _numAjVenta = new NumericUpDown();
            _numAjVenta.Location = new Point(xValue, 258);
            _numAjVenta.Size = new Size(120, 23);
            _numAjVenta.Maximum = 100000000;
            _numAjVenta.DecimalPlaces = 2;
            _numAjVenta.ThousandsSeparator = true;

            Label lblMayoreo = new Label();
            lblMayoreo.AutoSize = true;
            lblMayoreo.Font = new Font("Segoe UI", 9F);
            lblMayoreo.Text = "Precio Mayoreo";
            lblMayoreo.Location = new Point(xLabel + 22, 293);

            _numAjMayoreo = new NumericUpDown();
            _numAjMayoreo.Location = new Point(xValue, 290);
            _numAjMayoreo.Size = new Size(120, 23);
            _numAjMayoreo.Maximum = 100000000;
            _numAjMayoreo.DecimalPlaces = 2;
            _numAjMayoreo.ThousandsSeparator = true;

            Label lblMotivo = new Label();
            lblMotivo.AutoSize = true;
            lblMotivo.Font = new Font("Segoe UI", 9F);
            lblMotivo.Text = "Motivo del ajuste";
            lblMotivo.Location = new Point(xLabel + 8, 325);

            _txtAjMotivo = new TextBox();
            _txtAjMotivo.Location = new Point(xValue, 322);
            _txtAjMotivo.Size = new Size(780, 23);
            _txtAjMotivo.Font = new Font("Segoe UI", 9F);

            _lblAjMensaje = new Label();
            _lblAjMensaje.AutoSize = false;
            _lblAjMensaje.Font = new Font("Segoe UI", 8.5F);
            _lblAjMensaje.ForeColor = Color.FromArgb(80, 80, 80);
            _lblAjMensaje.BackColor = Color.FromArgb(255, 249, 220);
            _lblAjMensaje.BorderStyle = BorderStyle.FixedSingle;
            _lblAjMensaje.Location = new Point(xValue, 352);
            _lblAjMensaje.Size = new Size(780, 40);
            _lblAjMensaje.Visible = false;

            _btnAjGuardar = new Button();
            _btnAjGuardar.Text = "Realizar ajuste de inventario";
            _btnAjGuardar.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            _btnAjGuardar.FlatStyle = FlatStyle.Flat;
            _btnAjGuardar.FlatAppearance.BorderColor = Color.Silver;
            _btnAjGuardar.Size = new Size(240, 34);
            _btnAjGuardar.Location = new Point(xValue, 402);
            _btnAjGuardar.Click += (s, e) => GuardarAjusteInventario();

            _pnlAjustes.Controls.Add(lblDesc);
            _pnlAjustes.Controls.Add(_lblAjDescripcion);
            _pnlAjustes.Controls.Add(lblActual);
            _pnlAjustes.Controls.Add(_lblAjActual);
            _pnlAjustes.Controls.Add(lblDelta);
            _pnlAjustes.Controls.Add(_numAjDelta);
            _pnlAjustes.Controls.Add(lblNueva);
            _pnlAjustes.Controls.Add(_txtAjNueva);
            _pnlAjustes.Controls.Add(lblCosto);
            _pnlAjustes.Controls.Add(_numAjCosto);
            _pnlAjustes.Controls.Add(lblVenta);
            _pnlAjustes.Controls.Add(_numAjVenta);
            _pnlAjustes.Controls.Add(lblMayoreo);
            _pnlAjustes.Controls.Add(_numAjMayoreo);
            _pnlAjustes.Controls.Add(lblMotivo);
            _pnlAjustes.Controls.Add(_txtAjMotivo);
            _pnlAjustes.Controls.Add(_lblAjMensaje);
            _pnlAjustes.Controls.Add(_btnAjGuardar);

            LimpiarAjustes();
        }

        private void LimpiarAjustes()
        {
            _producto = null;
            if (_lblAjDescripcion != null) _lblAjDescripcion.Text = string.Empty;
            if (_lblAjActual != null) _lblAjActual.Text = string.Empty;
            if (_numAjDelta != null) _numAjDelta.Value = 0;
            if (_txtAjNueva != null) _txtAjNueva.Text = string.Empty;
            if (_numAjCosto != null) _numAjCosto.Value = 0;
            if (_numAjVenta != null) _numAjVenta.Value = 0;
            if (_numAjMayoreo != null) _numAjMayoreo.Value = 0;
            if (_txtAjMotivo != null) _txtAjMotivo.Text = string.Empty;
            if (_lblAjMensaje != null) _lblAjMensaje.Visible = false;
        }

        private void LimpiarEditor()
        {
            _producto = null;
            if (_lblDescripcion != null) _lblDescripcion.Text = string.Empty;
            if (_lblHay != null) _lblHay.Text = string.Empty;
            if (_numAgregar != null) _numAgregar.Value = 0;
            if (_numCosto != null) _numCosto.Value = 0;
            if (_numVenta != null) _numVenta.Value = 0;
            if (_numMayoreo != null) _numMayoreo.Value = 0;
            if (_lblMensaje != null) _lblMensaje.Visible = false;
        }

        private void CargarProductoDesdeCodigo()
        {
            EnsureEditorEmbebido();
            string codigo = txtCodigoProducto == null ? string.Empty : (txtCodigoProducto.Text ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(codigo))
                return;

            _producto = DatabaseHelper.ObtenerProductoPorCodigoBarras(codigo);
            if (_producto == null)
            {
                MessageBox.Show("Producto no encontrado.", "Inventario", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                EnfocarCodigoProducto();
                LimpiarEditor();
                return;
            }

            if (_lblDescripcion != null) _lblDescripcion.Text = _producto.Descripcion;
            if (_lblHay != null) _lblHay.Text = _producto.StockActual.ToString(CultureInfo.CurrentCulture);
            if (_numCosto != null) _numCosto.Value = ClampDecimal(_producto.PrecioCosto, _numCosto.Maximum);
            if (_numVenta != null) _numVenta.Value = ClampDecimal(_producto.PrecioVenta, _numVenta.Maximum);
            if (_numMayoreo != null) _numMayoreo.Value = ClampDecimal(_producto.PrecioMayoreo, _numMayoreo.Maximum);
            if (_numAgregar != null)
            {
                _numAgregar.Value = 0;
                _numAgregar.Focus();
                _numAgregar.Select(0, _numAgregar.Text.Length);
            }
            if (_lblMensaje != null) _lblMensaje.Visible = false;
        }

        private static decimal ClampDecimal(decimal value, decimal max)
        {
            if (value < 0m) return 0m;
            if (value > max) return max;
            return value;
        }

        private void GuardarAjuste()
        {
            if (_producto == null)
            {
                MessageBox.Show("Primero capture el código del producto y presione Enter.", "Inventario", MessageBoxButtons.OK, MessageBoxIcon.Information);
                EnfocarCodigoProducto();
                return;
            }

            int agregar = _numAgregar == null ? 0 : (int)_numAgregar.Value;
            if (agregar <= 0)
            {
                MessageBox.Show("Captura la cantidad a agregar.", "Inventario", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (_numAgregar != null) _numAgregar.Focus();
                return;
            }

            decimal costo = _numCosto == null ? 0m : _numCosto.Value;
            decimal venta = _numVenta == null ? 0m : _numVenta.Value;
            decimal mayoreo = _numMayoreo == null ? 0m : _numMayoreo.Value;

            string err;
            if (!DatabaseHelper.AgregarInventarioYActualizarPrecios(_producto.CodigoBarras, agregar, costo, venta, mayoreo, out err))
            {
                MessageBox.Show(string.IsNullOrWhiteSpace(err) ? "No se pudo actualizar el inventario." : err, "Inventario", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (_lblMensaje != null)
            {
                _lblMensaje.Text = string.Format(CultureInfo.CurrentCulture,
                    "Se recibieron {0} de inventario para el producto, el costo se quedo igual en {1}, el precio de venta sera de {2} y el precio de mayoreo de {3}.",
                    agregar,
                    costo.ToString("C2"),
                    venta.ToString("C2"),
                    mayoreo.ToString("C2"));
                _lblMensaje.Visible = true;
            }

            txtCodigoProducto.Clear();
            EnfocarCodigoProducto();
            LimpiarEditor();
        }
    }
}
