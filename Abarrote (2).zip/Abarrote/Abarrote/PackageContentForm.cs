using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace Abarrote
{
    public class PackageContentForm : Form
    {
        private readonly DataTable _dt;
        private readonly bool _embedded;

        private TextBox _txtCodigo;
        private NumericUpDown _nudCantidad;
        private Button _btnAgregar;
        private Button _btnQuitar;
        private DataGridView _dgv;
        private Button _btnOk;
        private Button _btnCancel;

        public PackageContentForm(DataTable data, bool embedded)
        {
            _dt = data ?? new DataTable();
            _embedded = embedded;
            EnsureSchema(_dt);

            InitializeUi();
        }

        public PackageContentForm(DataTable data)
            : this(data, false)
        {
        }

        private static void EnsureSchema(DataTable dt)
        {
            if (dt.Columns.Contains("CodigoBarras") == false)
                dt.Columns.Add("CodigoBarras", typeof(string));
            if (dt.Columns.Contains("Cantidad") == false)
                dt.Columns.Add("Cantidad", typeof(int));
        }

        private void InitializeUi()
        {
            Text = "Contenido del paquete";
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = _embedded ? FormBorderStyle.None : FormBorderStyle.FixedDialog;
            MinimizeBox = false;
            MaximizeBox = false;
            ShowInTaskbar = false;
            ClientSize = new Size(720, 420);

            Label lblHint = new Label();
            lblHint.Text = "Ingrese el código y la cantidad de cada artículo que incluye este producto";
            lblHint.AutoSize = false;
            lblHint.Dock = DockStyle.Top;
            lblHint.Height = 26;
            lblHint.TextAlign = ContentAlignment.MiddleLeft;
            lblHint.Padding = new Padding(10, 0, 0, 0);

            Panel pnlTop = new Panel();
            pnlTop.Dock = DockStyle.Top;
            pnlTop.Height = 58;

            Label lblCodigo = new Label();
            lblCodigo.Text = "Código de Barras";
            lblCodigo.AutoSize = true;
            lblCodigo.Location = new Point(12, 8);

            _txtCodigo = new TextBox();
            _txtCodigo.Location = new Point(12, 28);
            _txtCodigo.Size = new Size(240, 23);
            _txtCodigo.KeyDown += (s, e) =>
            {
                if (e.KeyCode == Keys.Enter)
                {
                    e.SuppressKeyPress = true;
                    Agregar();
                }
            };

            Label lblCant = new Label();
            lblCant.Text = "Cantidad";
            lblCant.AutoSize = true;
            lblCant.Location = new Point(270, 8);

            _nudCantidad = new NumericUpDown();
            _nudCantidad.Location = new Point(270, 28);
            _nudCantidad.Size = new Size(90, 23);
            _nudCantidad.Minimum = 1;
            _nudCantidad.Maximum = 100000;
            _nudCantidad.Value = 1;

            _btnAgregar = new Button();
            _btnAgregar.Text = "Agregar";
            _btnAgregar.Location = new Point(380, 26);
            _btnAgregar.Size = new Size(90, 26);
            _btnAgregar.Click += (s, e) => Agregar();

            _btnQuitar = new Button();
            _btnQuitar.Text = "Remover seleccionado";
            _btnQuitar.Location = new Point(480, 26);
            _btnQuitar.Size = new Size(150, 26);
            _btnQuitar.Click += (s, e) => Quitar();

            pnlTop.Controls.Add(lblCodigo);
            pnlTop.Controls.Add(_txtCodigo);
            pnlTop.Controls.Add(lblCant);
            pnlTop.Controls.Add(_nudCantidad);
            pnlTop.Controls.Add(_btnAgregar);
            pnlTop.Controls.Add(_btnQuitar);

            _dgv = new DataGridView();
            _dgv.Dock = DockStyle.Fill;
            _dgv.AllowUserToAddRows = false;
            _dgv.AllowUserToDeleteRows = false;
            _dgv.ReadOnly = true;
            _dgv.RowHeadersVisible = false;
            _dgv.MultiSelect = false;
            _dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            _dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            _dgv.DataSource = _dt;

            Panel pnlBottom = new Panel();
            pnlBottom.Dock = DockStyle.Bottom;
            pnlBottom.Height = 55;

            _btnOk = new Button();
            _btnOk.Text = "Aceptar";
            _btnOk.DialogResult = DialogResult.OK;
            _btnOk.Location = new Point(12, 12);
            _btnOk.Size = new Size(100, 30);

            _btnCancel = new Button();
            _btnCancel.Text = "Cancelar";
            _btnCancel.DialogResult = DialogResult.Cancel;
            _btnCancel.Location = new Point(120, 12);
            _btnCancel.Size = new Size(100, 30);

            pnlBottom.Controls.Add(_btnOk);
            pnlBottom.Controls.Add(_btnCancel);

            Controls.Add(_dgv);
            if (!_embedded)
            {
                Controls.Add(pnlBottom);
                Controls.Add(pnlTop);
                Controls.Add(lblHint);

                AcceptButton = _btnOk;
                CancelButton = _btnCancel;
            }
            else
            {
                Controls.Add(pnlTop);
                Controls.Add(lblHint);
                pnlBottom.Visible = false;
                lblHint.Height = 0;
            }
        }

        private void Agregar()
        {
            string codigo = (_txtCodigo.Text ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(codigo))
                return;

            int cant = (int)_nudCantidad.Value;
            if (cant <= 0)
                cant = 1;

            for (int i = 0; i < _dt.Rows.Count; i++)
            {
                string c = _dt.Rows[i]["CodigoBarras"] == null ? string.Empty : _dt.Rows[i]["CodigoBarras"].ToString();
                if (string.Equals(c, codigo, StringComparison.OrdinalIgnoreCase))
                {
                    int prev = 0;
                    int.TryParse(_dt.Rows[i]["Cantidad"].ToString(), out prev);
                    _dt.Rows[i]["Cantidad"] = prev + cant;
                    _txtCodigo.Clear();
                    _txtCodigo.Focus();
                    return;
                }
            }

            DataRow r = _dt.NewRow();
            r["CodigoBarras"] = codigo;
            r["Cantidad"] = cant;
            _dt.Rows.Add(r);

            _txtCodigo.Clear();
            _txtCodigo.Focus();
        }

        private void Quitar()
        {
            if (_dgv.SelectedRows == null || _dgv.SelectedRows.Count == 0)
                return;

            int ix = _dgv.SelectedRows[0].Index;
            if (ix < 0 || ix >= _dt.Rows.Count)
                return;

            _dt.Rows.RemoveAt(ix);
        }
    }
}
