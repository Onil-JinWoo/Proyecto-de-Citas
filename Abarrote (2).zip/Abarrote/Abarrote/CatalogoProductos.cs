using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace Abarrote
{
    public partial class CatalogoProductos : Form
    {
        public CatalogoProductos()
        {
            InitializeComponent();

            txtBuscar.TextChanged += txtBuscar_TextChanged;
            cboDepartamento.SelectedIndexChanged += cboDepartamento_SelectedIndexChanged;
            btnExportar.Click += btnExportar_Click;

            ConfigurarGrid();
            CargarDepartamentos();
            Consultar();
        }

        private void ConfigurarGrid()
        {
            dgvProductos.AutoGenerateColumns = true;
            dgvProductos.ReadOnly = true;
            dgvProductos.RowHeadersVisible = false;
            dgvProductos.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvProductos.AllowUserToAddRows = false;
            dgvProductos.AllowUserToDeleteRows = false;
            dgvProductos.BackgroundColor = Color.White;
        }

        private void CargarDepartamentos()
        {
            cboDepartamento.Items.Clear();
            cboDepartamento.Items.Add("- Todos -");

            DataTable dt = DatabaseHelper.ObtenerDepartamentos(false);
            if (dt != null)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    object v = dt.Rows[i]["Nombre"];
                    string nombre = v == null ? string.Empty : v.ToString();
                    if (!string.IsNullOrWhiteSpace(nombre))
                        cboDepartamento.Items.Add(nombre);
                }
            }

            cboDepartamento.SelectedIndex = 0;
        }

        private void Consultar()
        {
            string texto = txtBuscar.Text == null ? string.Empty : txtBuscar.Text.Trim();
            string depto = cboDepartamento.SelectedItem == null ? string.Empty : cboDepartamento.SelectedItem.ToString();
            if (string.Equals(depto, "- Todos -", StringComparison.OrdinalIgnoreCase))
                depto = string.Empty;

            DataTable dt = DatabaseHelper.ObtenerProductosCatalogo(texto, depto, false);
            dgvProductos.DataSource = dt;
        }

        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            Consultar();
        }

        private void cboDepartamento_SelectedIndexChanged(object sender, EventArgs e)
        {
            Consultar();
        }

        private void btnExportar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Función pendiente de configurar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
