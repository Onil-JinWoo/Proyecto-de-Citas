namespace Abarrote
{
    partial class VentasUserControl
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        private void InitializeComponent()
        {
            this.btnVarios = new System.Windows.Forms.Button();
            this.btnArtComun = new System.Windows.Forms.Button();
            this.btnBuscar = new System.Windows.Forms.Button();
            this.btnMayoreo = new System.Windows.Forms.Button();
            this.btnEntradas = new System.Windows.Forms.Button();
            this.btnSalidas = new System.Windows.Forms.Button();
            this.btnBorrarArt = new System.Windows.Forms.Button();
            this.btnVerificador = new System.Windows.Forms.Button();
            this.colCodigoBarras = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDescripcion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPrecioVenta = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCantidad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colImporte = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colExistencia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlRightSummary = new System.Windows.Forms.Panel();
            this.btnVentasDevoluciones = new System.Windows.Forms.Button();
            this.btnReimprimir = new System.Windows.Forms.Button();
            this.lblTotalDisplay = new System.Windows.Forms.Label();
            this.btnCobrar = new System.Windows.Forms.Button();
            this.pnlLeftSummary = new System.Windows.Forms.Panel();
            this.lblCambio = new System.Windows.Forms.Label();
            this.lblPagoCon = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.btnAsignarCliente = new System.Windows.Forms.Button();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.btnPendiente = new System.Windows.Forms.Button();
            this.btnCambiar = new System.Windows.Forms.Button();
            this.lblProductCount = new System.Windows.Forms.Label();
            this.dgvProductos = new System.Windows.Forms.DataGridView();
            this.pnlActionButtons = new System.Windows.Forms.Panel();
            this.btnAgregarProducto = new System.Windows.Forms.Button();
            this.txtCodigoProducto = new System.Windows.Forms.TextBox();
            this.lblCodigoProducto = new System.Windows.Forms.Label();
            this.lblVentaTitle = new System.Windows.Forms.Label();
            this.pnlRightSummary.SuspendLayout();
            this.pnlLeftSummary.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductos)).BeginInit();
            this.pnlActionButtons.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblVentaTitle
            // 
            this.lblVentaTitle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(80)))), ((int)(((byte)(160)))));
            this.lblVentaTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblVentaTitle.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblVentaTitle.ForeColor = System.Drawing.Color.White;
            this.lblVentaTitle.Location = new System.Drawing.Point(0, 0);
            this.lblVentaTitle.Name = "lblVentaTitle";
            this.lblVentaTitle.Padding = new System.Windows.Forms.Padding(8, 5, 0, 5);
            this.lblVentaTitle.Size = new System.Drawing.Size(1164, 32);
            this.lblVentaTitle.TabIndex = 0;
            this.lblVentaTitle.Text = "VENTA - Ticket 4";
            this.lblVentaTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblCodigoProducto
            // 
            this.lblCodigoProducto.AutoSize = true;
            this.lblCodigoProducto.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblCodigoProducto.Location = new System.Drawing.Point(13, 48);
            this.lblCodigoProducto.Name = "lblCodigoProducto";
            this.lblCodigoProducto.Size = new System.Drawing.Size(120, 15);
            this.lblCodigoProducto.TabIndex = 1;
            this.lblCodigoProducto.Text = "Código del Producto:";
            // 
            // txtCodigoProducto
            // 
            this.txtCodigoProducto.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtCodigoProducto.Location = new System.Drawing.Point(125, 45);
            this.txtCodigoProducto.Name = "txtCodigoProducto";
            this.txtCodigoProducto.Size = new System.Drawing.Size(350, 25);
            this.txtCodigoProducto.TabIndex = 2;
            // 
            // btnAgregarProducto
            // 
            this.btnAgregarProducto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(175)))), ((int)(((byte)(80)))));
            this.btnAgregarProducto.FlatAppearance.BorderSize = 0;
            this.btnAgregarProducto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAgregarProducto.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnAgregarProducto.ForeColor = System.Drawing.Color.White;
            this.btnAgregarProducto.Location = new System.Drawing.Point(485, 43);
            this.btnAgregarProducto.Name = "btnAgregarProducto";
            this.btnAgregarProducto.Size = new System.Drawing.Size(180, 28);
            this.btnAgregarProducto.TabIndex = 3;
            this.btnAgregarProducto.Text = "ENTER - Agregar Producto";
            this.btnAgregarProducto.UseVisualStyleBackColor = false;
            // 
            // pnlActionButtons
            // 
            this.pnlActionButtons.Controls.Add(this.btnVerificador);
            this.pnlActionButtons.Controls.Add(this.btnBorrarArt);
            this.pnlActionButtons.Controls.Add(this.btnSalidas);
            this.pnlActionButtons.Controls.Add(this.btnEntradas);
            this.pnlActionButtons.Controls.Add(this.btnMayoreo);
            this.pnlActionButtons.Controls.Add(this.btnBuscar);
            this.pnlActionButtons.Controls.Add(this.btnArtComun);
            this.pnlActionButtons.Controls.Add(this.btnVarios);
            this.pnlActionButtons.Location = new System.Drawing.Point(16, 81);
            this.pnlActionButtons.Name = "pnlActionButtons";
            this.pnlActionButtons.Size = new System.Drawing.Size(900, 35);
            this.pnlActionButtons.TabIndex = 4;
            // 
            // btnVarios through btnVerificador
            // 
            this.btnVarios.BackColor = System.Drawing.Color.White;
            this.btnVarios.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnVarios.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVarios.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.btnVarios.Location = new System.Drawing.Point(0, 5);
            this.btnVarios.Name = "btnVarios";
            this.btnVarios.Size = new System.Drawing.Size(90, 25);
            this.btnVarios.TabIndex = 0;
            this.btnVarios.Text = "INS Varios";
            this.btnVarios.UseVisualStyleBackColor = false;
            //
            this.btnArtComun.BackColor = System.Drawing.Color.White;
            this.btnArtComun.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnArtComun.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnArtComun.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.btnArtComun.Location = new System.Drawing.Point(96, 5);
            this.btnArtComun.Name = "btnArtComun";
            this.btnArtComun.Size = new System.Drawing.Size(110, 25);
            this.btnArtComun.TabIndex = 1;
            this.btnArtComun.Text = "CTRL+P Art. Común";
            this.btnArtComun.UseVisualStyleBackColor = false;
            //
            this.btnBuscar.BackColor = System.Drawing.Color.White;
            this.btnBuscar.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnBuscar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBuscar.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.btnBuscar.Location = new System.Drawing.Point(212, 5);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(85, 25);
            this.btnBuscar.TabIndex = 2;
            this.btnBuscar.Text = "F10 Buscar";
            this.btnBuscar.UseVisualStyleBackColor = false;
            //
            this.btnMayoreo.BackColor = System.Drawing.Color.White;
            this.btnMayoreo.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnMayoreo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMayoreo.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.btnMayoreo.Location = new System.Drawing.Point(303, 5);
            this.btnMayoreo.Name = "btnMayoreo";
            this.btnMayoreo.Size = new System.Drawing.Size(85, 25);
            this.btnMayoreo.TabIndex = 3;
            this.btnMayoreo.Text = "F11 Mayoreo";
            this.btnMayoreo.UseVisualStyleBackColor = false;
            //
            this.btnEntradas.BackColor = System.Drawing.Color.White;
            this.btnEntradas.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnEntradas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEntradas.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.btnEntradas.Location = new System.Drawing.Point(394, 5);
            this.btnEntradas.Name = "btnEntradas";
            this.btnEntradas.Size = new System.Drawing.Size(90, 25);
            this.btnEntradas.TabIndex = 4;
            this.btnEntradas.Text = "F7 Entradas";
            this.btnEntradas.UseVisualStyleBackColor = false;
            //
            this.btnSalidas.BackColor = System.Drawing.Color.White;
            this.btnSalidas.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnSalidas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalidas.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.btnSalidas.Location = new System.Drawing.Point(490, 5);
            this.btnSalidas.Name = "btnSalidas";
            this.btnSalidas.Size = new System.Drawing.Size(85, 25);
            this.btnSalidas.TabIndex = 5;
            this.btnSalidas.Text = "F8 Salidas";
            this.btnSalidas.UseVisualStyleBackColor = false;
            //
            this.btnBorrarArt.BackColor = System.Drawing.Color.White;
            this.btnBorrarArt.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnBorrarArt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBorrarArt.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.btnBorrarArt.Location = new System.Drawing.Point(581, 5);
            this.btnBorrarArt.Name = "btnBorrarArt";
            this.btnBorrarArt.Size = new System.Drawing.Size(85, 25);
            this.btnBorrarArt.TabIndex = 6;
            this.btnBorrarArt.Text = "DEL Borrar Art.";
            this.btnBorrarArt.UseVisualStyleBackColor = false;
            //
            this.btnVerificador.BackColor = System.Drawing.Color.White;
            this.btnVerificador.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnVerificador.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVerificador.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.btnVerificador.Location = new System.Drawing.Point(672, 5);
            this.btnVerificador.Name = "btnVerificador";
            this.btnVerificador.Size = new System.Drawing.Size(95, 25);
            this.btnVerificador.TabIndex = 7;
            this.btnVerificador.Text = "F9 Verificador";
            this.btnVerificador.UseVisualStyleBackColor = false;
            // 
            // dgvProductos
            // 
            this.dgvProductos.AllowUserToAddRows = false;
            this.dgvProductos.AllowUserToDeleteRows = false;
            this.dgvProductos.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvProductos.BackgroundColor = System.Drawing.Color.White;
            this.dgvProductos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProductos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colCodigoBarras, this.colDescripcion, this.colPrecioVenta, this.colCantidad, this.colImporte, this.colExistencia});
            this.dgvProductos.Location = new System.Drawing.Point(16, 123);
            this.dgvProductos.Name = "dgvProductos";
            this.dgvProductos.ReadOnly = true;
            this.dgvProductos.RowHeadersVisible = false;
            this.dgvProductos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvProductos.Size = new System.Drawing.Size(900, 315);
            this.dgvProductos.TabIndex = 5;
            // 
            // colCodigoBarras
            // 
            this.colCodigoBarras.HeaderText = "Código de Barras";
            this.colCodigoBarras.Name = "colCodigoBarras";
            this.colCodigoBarras.ReadOnly = true;
            this.colCodigoBarras.Width = 150;
            // 
            // colDescripcion
            // 
            this.colDescripcion.HeaderText = "Descripción del Producto";
            this.colDescripcion.Name = "colDescripcion";
            this.colDescripcion.ReadOnly = true;
            this.colDescripcion.Width = 350;
            // 
            // colPrecioVenta
            // 
            this.colPrecioVenta.HeaderText = "Precio Venta";
            this.colPrecioVenta.Name = "colPrecioVenta";
            this.colPrecioVenta.ReadOnly = true;
            // 
            // colCantidad
            // 
            this.colCantidad.HeaderText = "Cant.";
            this.colCantidad.Name = "colCantidad";
            this.colCantidad.ReadOnly = true;
            this.colCantidad.Width = 60;
            // 
            // colImporte
            // 
            this.colImporte.HeaderText = "Importe";
            this.colImporte.Name = "colImporte";
            this.colImporte.ReadOnly = true;
            // 
            // colExistencia
            // 
            this.colExistencia.HeaderText = "Existencia";
            this.colExistencia.Name = "colExistencia";
            this.colExistencia.ReadOnly = true;
            this.colExistencia.Width = 80;
            // 
            // pnlLeftSummary
            // 
            this.pnlLeftSummary.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlLeftSummary.BackColor = System.Drawing.Color.White;
            this.pnlLeftSummary.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlLeftSummary.Controls.Add(this.lblCambio);
            this.pnlLeftSummary.Controls.Add(this.lblPagoCon);
            this.pnlLeftSummary.Controls.Add(this.lblTotal);
            this.pnlLeftSummary.Controls.Add(this.btnAsignarCliente);
            this.pnlLeftSummary.Controls.Add(this.btnEliminar);
            this.pnlLeftSummary.Controls.Add(this.btnPendiente);
            this.pnlLeftSummary.Controls.Add(this.btnCambiar);
            this.pnlLeftSummary.Controls.Add(this.lblProductCount);
            this.pnlLeftSummary.Location = new System.Drawing.Point(16, 455);
            this.pnlLeftSummary.Name = "pnlLeftSummary";
            this.pnlLeftSummary.Size = new System.Drawing.Size(450, 120);
            this.pnlLeftSummary.TabIndex = 6;
            // 
            this.lblProductCount.AutoSize = true;
            this.lblProductCount.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblProductCount.Location = new System.Drawing.Point(8, 8);
            this.lblProductCount.Name = "lblProductCount";
            this.lblProductCount.Size = new System.Drawing.Size(168, 15);
            this.lblProductCount.TabIndex = 0;
            this.lblProductCount.Text = "0 Productos en la venta actual.";
            this.btnCambiar.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnCambiar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCambiar.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.btnCambiar.Location = new System.Drawing.Point(11, 28);
            this.btnCambiar.Name = "btnCambiar";
            this.btnCambiar.Size = new System.Drawing.Size(90, 28);
            this.btnCambiar.TabIndex = 1;
            this.btnCambiar.Text = "F5 - Cambiar";
            this.btnCambiar.UseVisualStyleBackColor = true;
            this.btnPendiente.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnPendiente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPendiente.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.btnPendiente.Location = new System.Drawing.Point(107, 28);
            this.btnPendiente.Name = "btnPendiente";
            this.btnPendiente.Size = new System.Drawing.Size(90, 28);
            this.btnPendiente.TabIndex = 2;
            this.btnPendiente.Text = "F6 - Pendiente";
            this.btnPendiente.UseVisualStyleBackColor = true;
            this.btnEliminar.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnEliminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEliminar.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.btnEliminar.Location = new System.Drawing.Point(203, 28);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(75, 28);
            this.btnEliminar.TabIndex = 3;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = true;
            this.btnAsignarCliente.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnAsignarCliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAsignarCliente.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.btnAsignarCliente.Location = new System.Drawing.Point(284, 28);
            this.btnAsignarCliente.Name = "btnAsignarCliente";
            this.btnAsignarCliente.Size = new System.Drawing.Size(110, 28);
            this.btnAsignarCliente.TabIndex = 4;
            this.btnAsignarCliente.Text = "Asignar cliente";
            this.btnAsignarCliente.UseVisualStyleBackColor = true;
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblTotal.Location = new System.Drawing.Point(11, 70);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(71, 15);
            this.lblTotal.TabIndex = 5;
            this.lblTotal.Text = "Total: $0.00";
            this.lblPagoCon.AutoSize = true;
            this.lblPagoCon.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblPagoCon.Location = new System.Drawing.Point(11, 90);
            this.lblPagoCon.Name = "lblPagoCon";
            this.lblPagoCon.Size = new System.Drawing.Size(92, 15);
            this.lblPagoCon.TabIndex = 6;
            this.lblPagoCon.Text = "Pagó Con: $0.00";
            this.lblCambio.AutoSize = true;
            this.lblCambio.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblCambio.Location = new System.Drawing.Point(180, 90);
            this.lblCambio.Name = "lblCambio";
            this.lblCambio.Size = new System.Drawing.Size(82, 15);
            this.lblCambio.TabIndex = 7;
            this.lblCambio.Text = "Cambio: $0.00";
            // 
            // pnlRightSummary
            // 
            this.pnlRightSummary.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlRightSummary.BackColor = System.Drawing.Color.White;
            this.pnlRightSummary.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlRightSummary.Controls.Add(this.btnVentasDevoluciones);
            this.pnlRightSummary.Controls.Add(this.btnReimprimir);
            this.pnlRightSummary.Controls.Add(this.lblTotalDisplay);
            this.pnlRightSummary.Controls.Add(this.btnCobrar);
            this.pnlRightSummary.Location = new System.Drawing.Point(932, 45);
            this.pnlRightSummary.Name = "pnlRightSummary";
            this.pnlRightSummary.Size = new System.Drawing.Size(240, 530);
            this.pnlRightSummary.TabIndex = 7;
            // 
            this.btnCobrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(175)))), ((int)(((byte)(80)))));
            this.btnCobrar.FlatAppearance.BorderSize = 0;
            this.btnCobrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCobrar.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnCobrar.ForeColor = System.Drawing.Color.White;
            this.btnCobrar.Location = new System.Drawing.Point(20, 20);
            this.btnCobrar.Name = "btnCobrar";
            this.btnCobrar.Size = new System.Drawing.Size(200, 50);
            this.btnCobrar.TabIndex = 0;
            this.btnCobrar.Text = "F12 - Cobrar";
            this.btnCobrar.UseVisualStyleBackColor = false;
            this.lblTotalDisplay.Font = new System.Drawing.Font("Segoe UI", 28F, System.Drawing.FontStyle.Bold);
            this.lblTotalDisplay.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.lblTotalDisplay.Location = new System.Drawing.Point(10, 85);
            this.lblTotalDisplay.Name = "lblTotalDisplay";
            this.lblTotalDisplay.Size = new System.Drawing.Size(220, 60);
            this.lblTotalDisplay.TabIndex = 1;
            this.lblTotalDisplay.Text = "$0.00";
            this.lblTotalDisplay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnReimprimir.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnReimprimir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReimprimir.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.btnReimprimir.Location = new System.Drawing.Point(20, 160);
            this.btnReimprimir.Name = "btnReimprimir";
            this.btnReimprimir.Size = new System.Drawing.Size(200, 35);
            this.btnReimprimir.TabIndex = 2;
            this.btnReimprimir.Text = "Reimprimir Último Ticket";
            this.btnReimprimir.UseVisualStyleBackColor = true;
            this.btnVentasDevoluciones.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnVentasDevoluciones.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVentasDevoluciones.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.btnVentasDevoluciones.Location = new System.Drawing.Point(20, 205);
            this.btnVentasDevoluciones.Name = "btnVentasDevoluciones";
            this.btnVentasDevoluciones.Size = new System.Drawing.Size(200, 35);
            this.btnVentasDevoluciones.TabIndex = 3;
            this.btnVentasDevoluciones.Text = "Ventas del día y Devoluciones";
            this.btnVentasDevoluciones.UseVisualStyleBackColor = true;
            // 
            // VentasUserControl
            // 
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.Controls.Add(this.pnlRightSummary);
            this.Controls.Add(this.pnlLeftSummary);
            this.Controls.Add(this.dgvProductos);
            this.Controls.Add(this.pnlActionButtons);
            this.Controls.Add(this.btnAgregarProducto);
            this.Controls.Add(this.txtCodigoProducto);
            this.Controls.Add(this.lblCodigoProducto);
            this.Controls.Add(this.lblVentaTitle);
            this.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Name = "VentasUserControl";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.Size = new System.Drawing.Size(1184, 593);
            this.pnlRightSummary.ResumeLayout(false);
            this.pnlLeftSummary.ResumeLayout(false);
            this.pnlLeftSummary.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductos)).EndInit();
            this.pnlActionButtons.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Panel pnlRightSummary;
        private System.Windows.Forms.Button btnVentasDevoluciones;
        private System.Windows.Forms.Button btnReimprimir;
        private System.Windows.Forms.Label lblTotalDisplay;
        private System.Windows.Forms.Button btnCobrar;
        private System.Windows.Forms.Panel pnlLeftSummary;
        private System.Windows.Forms.Label lblCambio;
        private System.Windows.Forms.Label lblPagoCon;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Button btnAsignarCliente;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.Button btnPendiente;
        private System.Windows.Forms.Button btnCambiar;
        private System.Windows.Forms.Label lblProductCount;
        private System.Windows.Forms.DataGridView dgvProductos;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCodigoBarras;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDescripcion;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPrecioVenta;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCantidad;
        private System.Windows.Forms.DataGridViewTextBoxColumn colImporte;
        private System.Windows.Forms.DataGridViewTextBoxColumn colExistencia;
        private System.Windows.Forms.Panel pnlActionButtons;
        private System.Windows.Forms.Button btnVerificador;
        private System.Windows.Forms.Button btnBorrarArt;
        private System.Windows.Forms.Button btnSalidas;
        private System.Windows.Forms.Button btnEntradas;
        private System.Windows.Forms.Button btnMayoreo;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.Button btnArtComun;
        private System.Windows.Forms.Button btnVarios;
        private System.Windows.Forms.Button btnAgregarProducto;
        private System.Windows.Forms.TextBox txtCodigoProducto;
        private System.Windows.Forms.Label lblCodigoProducto;
        private System.Windows.Forms.Label lblVentaTitle;
    }
}
