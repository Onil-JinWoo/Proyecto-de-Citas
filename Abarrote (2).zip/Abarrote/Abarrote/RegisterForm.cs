using System;
using System.Drawing;
using System.Windows.Forms;

namespace Abarrote
{
    public class RegisterForm : Form
    {
        private Label _lblTitle;
        private Label _lblUsuario;
        private TextBox _txtUsuario;
        private Label _lblNombre;
        private TextBox _txtNombre;
        private Label _lblPass;
        private TextBox _txtPass;
        private Label _lblPass2;
        private TextBox _txtPass2;
        private Button _btnCrear;
        private Button _btnCancelar;

        public string UsuarioCreado { get; private set; }

        public RegisterForm()
        {
            InitializeUi();
        }

        private void InitializeUi()
        {
            Text = "Crear cuenta";
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            ClientSize = new Size(420, 250);

            _lblTitle = new Label();
            _lblTitle.AutoSize = false;
            _lblTitle.Location = new Point(12, 10);
            _lblTitle.Size = new Size(396, 25);
            _lblTitle.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            _lblTitle.Text = "Crear nueva cuenta";

            _lblUsuario = new Label();
            _lblUsuario.AutoSize = true;
            _lblUsuario.Location = new Point(12, 50);
            _lblUsuario.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            _lblUsuario.Text = "Usuario:";

            _txtUsuario = new TextBox();
            _txtUsuario.Location = new Point(130, 46);
            _txtUsuario.Size = new Size(260, 23);

            _lblNombre = new Label();
            _lblNombre.AutoSize = true;
            _lblNombre.Location = new Point(12, 85);
            _lblNombre.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            _lblNombre.Text = "Nombre:";

            _txtNombre = new TextBox();
            _txtNombre.Location = new Point(130, 81);
            _txtNombre.Size = new Size(260, 23);

            _lblPass = new Label();
            _lblPass.AutoSize = true;
            _lblPass.Location = new Point(12, 120);
            _lblPass.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            _lblPass.Text = "Contraseña:";

            _txtPass = new TextBox();
            _txtPass.Location = new Point(130, 116);
            _txtPass.Size = new Size(260, 23);
            _txtPass.UseSystemPasswordChar = true;

            _lblPass2 = new Label();
            _lblPass2.AutoSize = true;
            _lblPass2.Location = new Point(12, 155);
            _lblPass2.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            _lblPass2.Text = "Confirmar:";

            _txtPass2 = new TextBox();
            _txtPass2.Location = new Point(130, 151);
            _txtPass2.Size = new Size(260, 23);
            _txtPass2.UseSystemPasswordChar = true;

            _btnCrear = new Button();
            _btnCrear.Text = "Crear";
            _btnCrear.Location = new Point(130, 195);
            _btnCrear.Size = new Size(120, 30);
            _btnCrear.Click += btnCrear_Click;

            _btnCancelar = new Button();
            _btnCancelar.Text = "Cancelar";
            _btnCancelar.Location = new Point(270, 195);
            _btnCancelar.Size = new Size(120, 30);
            _btnCancelar.Click += btnCancelar_Click;

            AcceptButton = _btnCrear;
            CancelButton = _btnCancelar;

            Controls.Add(_lblTitle);
            Controls.Add(_lblUsuario);
            Controls.Add(_txtUsuario);
            Controls.Add(_lblNombre);
            Controls.Add(_txtNombre);
            Controls.Add(_lblPass);
            Controls.Add(_txtPass);
            Controls.Add(_lblPass2);
            Controls.Add(_txtPass2);
            Controls.Add(_btnCrear);
            Controls.Add(_btnCancelar);
        }

        private void btnCrear_Click(object sender, EventArgs e)
        {
            string usuario = _txtUsuario == null ? string.Empty : (_txtUsuario.Text ?? string.Empty).Trim();
            string nombre = _txtNombre == null ? string.Empty : (_txtNombre.Text ?? string.Empty).Trim();
            string pass = _txtPass == null ? string.Empty : (_txtPass.Text ?? string.Empty);
            string pass2 = _txtPass2 == null ? string.Empty : (_txtPass2.Text ?? string.Empty);

            if (string.IsNullOrWhiteSpace(usuario))
            {
                MessageBox.Show("Captura un usuario.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (_txtUsuario != null) _txtUsuario.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(pass))
            {
                MessageBox.Show("Captura una contraseña.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (_txtPass != null) _txtPass.Focus();
                return;
            }

            if (!string.Equals(pass, pass2, StringComparison.Ordinal))
            {
                MessageBox.Show("Las contraseñas no coinciden.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (_txtPass2 != null)
                {
                    _txtPass2.SelectAll();
                    _txtPass2.Focus();
                }
                return;
            }

            if (!DatabaseHelper.CrearUsuarioInicioSeccion(usuario, nombre, pass, "Cajero", true))
            {
                return;
            }

            UsuarioCreado = usuario;
            DialogResult = DialogResult.OK;
            Close();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}
