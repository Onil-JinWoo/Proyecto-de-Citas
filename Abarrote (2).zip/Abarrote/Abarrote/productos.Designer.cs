namespace Abarrote
{
    partial class productos
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblProductosTitle = new System.Windows.Forms.Label();
            this.pnlActionBar = new System.Windows.Forms.Panel();
            this.btnNuevo = new System.Windows.Forms.Button();
            this.btnModificar = new System.Windows.Forms.Button();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.btnDepartamentosBar = new System.Windows.Forms.Button();
            this.btnVentasPeriodo = new System.Windows.Forms.Button();
            this.btnPromociones = new System.Windows.Forms.Button();
            this.btnImportar = new System.Windows.Forms.Button();
            this.btnCatalogo = new System.Windows.Forms.Button();
            this.pnlNuevoProducto = new System.Windows.Forms.Panel();
            this.btnGuardarProducto = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.txtMaximo = new System.Windows.Forms.TextBox();
            this.lblMaximo = new System.Windows.Forms.Label();
            this.txtMinimo = new System.Windows.Forms.TextBox();
            this.lblMinimo = new System.Windows.Forms.Label();
            this.txtHay = new System.Windows.Forms.TextBox();
            this.lblHay = new System.Windows.Forms.Label();
            this.chkUsaInventario = new System.Windows.Forms.CheckBox();
            this.lblInventario = new System.Windows.Forms.Label();
            this.cboDepartamento = new System.Windows.Forms.ComboBox();
            this.btnAdministrarDepartamentos = new System.Windows.Forms.Button();
            this.lblDepartamento = new System.Windows.Forms.Label();
            this.txtPrecioMayoreo = new System.Windows.Forms.TextBox();
            this.lblPrecioMayoreo = new System.Windows.Forms.Label();
            this.txtPrecioVenta = new System.Windows.Forms.TextBox();
            this.lblPrecioVenta = new System.Windows.Forms.Label();
            this.cboGanancia = new System.Windows.Forms.ComboBox();
            this.txtGanancia = new System.Windows.Forms.TextBox();
            this.lblGanancia = new System.Windows.Forms.Label();
            this.txtPrecioCosto = new System.Windows.Forms.TextBox();
            this.lblPrecioCosto = new System.Windows.Forms.Label();
            this.rdbPaquete = new System.Windows.Forms.RadioButton();
            this.rdbGranel = new System.Windows.Forms.RadioButton();
            this.rdbUnidad = new System.Windows.Forms.RadioButton();
            this.lblSeVende = new System.Windows.Forms.Label();
            this.txtDescripcion = new System.Windows.Forms.TextBox();
            this.lblDescripcion = new System.Windows.Forms.Label();
            this.txtCodigoBarras = new System.Windows.Forms.TextBox();
            this.lblCodigoBarras = new System.Windows.Forms.Label();
            this.txtProducto = new System.Windows.Forms.TextBox();
            this.lblProducto = new System.Windows.Forms.Label();
            this.lblNuevoProducto = new System.Windows.Forms.Label();
            this.pnlActionBar.SuspendLayout();
            this.pnlNuevoProducto.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblProductosTitle
            // 
            this.lblProductosTitle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(140)))), ((int)(((byte)(70)))));
            this.lblProductosTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblProductosTitle.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblProductosTitle.ForeColor = System.Drawing.Color.White;
            this.lblProductosTitle.Location = new System.Drawing.Point(0, 0);
            this.lblProductosTitle.Name = "lblProductosTitle";
            this.lblProductosTitle.Padding = new System.Windows.Forms.Padding(8, 5, 0, 5);
            this.lblProductosTitle.Size = new System.Drawing.Size(1302, 35);
            this.lblProductosTitle.TabIndex = 0;
            this.lblProductosTitle.Text = "PRODUCTOS";
            this.lblProductosTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pnlActionBar
            // 
            this.pnlActionBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(245)))), ((int)(((byte)(245)))));
            this.pnlActionBar.Controls.Add(this.btnNuevo);
            this.pnlActionBar.Controls.Add(this.btnModificar);
            this.pnlActionBar.Controls.Add(this.btnEliminar);
            this.pnlActionBar.Controls.Add(this.btnDepartamentosBar);
            this.pnlActionBar.Controls.Add(this.btnVentasPeriodo);
            this.pnlActionBar.Controls.Add(this.btnPromociones);
            this.pnlActionBar.Controls.Add(this.btnImportar);
            this.pnlActionBar.Controls.Add(this.btnCatalogo);
            this.pnlActionBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlActionBar.Location = new System.Drawing.Point(0, 35);
            this.pnlActionBar.Name = "pnlActionBar";
            this.pnlActionBar.Size = new System.Drawing.Size(1302, 40);
            this.pnlActionBar.TabIndex = 1;
            // 
            // btnNuevo
            // 
            this.btnNuevo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(175)))), ((int)(((byte)(80)))));
            this.btnNuevo.FlatAppearance.BorderSize = 0;
            this.btnNuevo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNuevo.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnNuevo.ForeColor = System.Drawing.Color.White;
            this.btnNuevo.Location = new System.Drawing.Point(5, 5);
            this.btnNuevo.Name = "btnNuevo";
            this.btnNuevo.Size = new System.Drawing.Size(90, 30);
            this.btnNuevo.TabIndex = 0;
            this.btnNuevo.Text = "+ Nuevo";
            this.btnNuevo.UseVisualStyleBackColor = false;
            // 
            // btnModificar
            // 
            this.btnModificar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(193)))), ((int)(((byte)(7)))));
            this.btnModificar.FlatAppearance.BorderSize = 0;
            this.btnModificar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnModificar.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnModificar.ForeColor = System.Drawing.Color.Black;
            this.btnModificar.Location = new System.Drawing.Point(100, 5);
            this.btnModificar.Name = "btnModificar";
            this.btnModificar.Size = new System.Drawing.Size(95, 30);
            this.btnModificar.TabIndex = 1;
            this.btnModificar.Text = "Modificar";
            this.btnModificar.UseVisualStyleBackColor = false;
            // 
            // btnEliminar
            // 
            this.btnEliminar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(67)))), ((int)(((byte)(54)))));
            this.btnEliminar.FlatAppearance.BorderSize = 0;
            this.btnEliminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEliminar.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnEliminar.ForeColor = System.Drawing.Color.White;
            this.btnEliminar.Location = new System.Drawing.Point(200, 5);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(85, 30);
            this.btnEliminar.TabIndex = 2;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = false;
            // 
            // btnDepartamentosBar
            // 
            this.btnDepartamentosBar.BackColor = System.Drawing.Color.White;
            this.btnDepartamentosBar.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnDepartamentosBar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDepartamentosBar.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnDepartamentosBar.ForeColor = System.Drawing.Color.Black;
            this.btnDepartamentosBar.Location = new System.Drawing.Point(290, 5);
            this.btnDepartamentosBar.Name = "btnDepartamentosBar";
            this.btnDepartamentosBar.Size = new System.Drawing.Size(120, 30);
            this.btnDepartamentosBar.TabIndex = 3;
            this.btnDepartamentosBar.Text = "Departamentos";
            this.btnDepartamentosBar.UseVisualStyleBackColor = false;
            // 
            // btnVentasPeriodo
            // 
            this.btnVentasPeriodo.BackColor = System.Drawing.Color.White;
            this.btnVentasPeriodo.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnVentasPeriodo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVentasPeriodo.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnVentasPeriodo.ForeColor = System.Drawing.Color.Black;
            this.btnVentasPeriodo.Location = new System.Drawing.Point(415, 5);
            this.btnVentasPeriodo.Name = "btnVentasPeriodo";
            this.btnVentasPeriodo.Size = new System.Drawing.Size(140, 30);
            this.btnVentasPeriodo.TabIndex = 4;
            this.btnVentasPeriodo.Text = "Ventas por Periodo";
            this.btnVentasPeriodo.UseVisualStyleBackColor = false;
            // 
            // btnPromociones
            // 
            this.btnPromociones.BackColor = System.Drawing.Color.White;
            this.btnPromociones.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnPromociones.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPromociones.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnPromociones.ForeColor = System.Drawing.Color.Black;
            this.btnPromociones.Location = new System.Drawing.Point(560, 5);
            this.btnPromociones.Name = "btnPromociones";
            this.btnPromociones.Size = new System.Drawing.Size(110, 30);
            this.btnPromociones.TabIndex = 5;
            this.btnPromociones.Text = "Promociones";
            this.btnPromociones.UseVisualStyleBackColor = false;
            // 
            // btnImportar
            // 
            this.btnImportar.BackColor = System.Drawing.Color.White;
            this.btnImportar.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnImportar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnImportar.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnImportar.ForeColor = System.Drawing.Color.Black;
            this.btnImportar.Location = new System.Drawing.Point(675, 5);
            this.btnImportar.Name = "btnImportar";
            this.btnImportar.Size = new System.Drawing.Size(90, 30);
            this.btnImportar.TabIndex = 6;
            this.btnImportar.Text = "Importar";
            this.btnImportar.UseVisualStyleBackColor = false;
            // 
            // btnCatalogo
            // 
            this.btnCatalogo.BackColor = System.Drawing.Color.White;
            this.btnCatalogo.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnCatalogo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCatalogo.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnCatalogo.ForeColor = System.Drawing.Color.Black;
            this.btnCatalogo.Location = new System.Drawing.Point(770, 5);
            this.btnCatalogo.Name = "btnCatalogo";
            this.btnCatalogo.Size = new System.Drawing.Size(90, 30);
            this.btnCatalogo.TabIndex = 7;
            this.btnCatalogo.Text = "Catálogo";
            this.btnCatalogo.UseVisualStyleBackColor = false;
            // 
            // pnlNuevoProducto
            // 
            this.pnlNuevoProducto.BackColor = System.Drawing.Color.White;
            this.pnlNuevoProducto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlNuevoProducto.Controls.Add(this.btnGuardarProducto);
            this.pnlNuevoProducto.Controls.Add(this.btnCancelar);
            this.pnlNuevoProducto.Controls.Add(this.txtMaximo);
            this.pnlNuevoProducto.Controls.Add(this.lblMaximo);
            this.pnlNuevoProducto.Controls.Add(this.txtMinimo);
            this.pnlNuevoProducto.Controls.Add(this.lblMinimo);
            this.pnlNuevoProducto.Controls.Add(this.txtHay);
            this.pnlNuevoProducto.Controls.Add(this.lblHay);
            this.pnlNuevoProducto.Controls.Add(this.chkUsaInventario);
            this.pnlNuevoProducto.Controls.Add(this.lblInventario);
            this.pnlNuevoProducto.Controls.Add(this.cboDepartamento);
            this.pnlNuevoProducto.Controls.Add(this.btnAdministrarDepartamentos);
            this.pnlNuevoProducto.Controls.Add(this.lblDepartamento);
            this.pnlNuevoProducto.Controls.Add(this.txtPrecioMayoreo);
            this.pnlNuevoProducto.Controls.Add(this.lblPrecioMayoreo);
            this.pnlNuevoProducto.Controls.Add(this.txtPrecioVenta);
            this.pnlNuevoProducto.Controls.Add(this.lblPrecioVenta);
            this.pnlNuevoProducto.Controls.Add(this.cboGanancia);
            this.pnlNuevoProducto.Controls.Add(this.txtGanancia);
            this.pnlNuevoProducto.Controls.Add(this.lblGanancia);
            this.pnlNuevoProducto.Controls.Add(this.txtPrecioCosto);
            this.pnlNuevoProducto.Controls.Add(this.lblPrecioCosto);
            this.pnlNuevoProducto.Controls.Add(this.rdbPaquete);
            this.pnlNuevoProducto.Controls.Add(this.rdbGranel);
            this.pnlNuevoProducto.Controls.Add(this.rdbUnidad);
            this.pnlNuevoProducto.Controls.Add(this.lblSeVende);
            this.pnlNuevoProducto.Controls.Add(this.txtDescripcion);
            this.pnlNuevoProducto.Controls.Add(this.lblDescripcion);
            this.pnlNuevoProducto.Controls.Add(this.txtCodigoBarras);
            this.pnlNuevoProducto.Controls.Add(this.lblCodigoBarras);
            this.pnlNuevoProducto.Controls.Add(this.txtProducto);
            this.pnlNuevoProducto.Controls.Add(this.lblProducto);
            this.pnlNuevoProducto.Controls.Add(this.lblNuevoProducto);
            this.pnlNuevoProducto.Location = new System.Drawing.Point(28, 114);
            this.pnlNuevoProducto.Name = "pnlNuevoProducto";
            this.pnlNuevoProducto.Padding = new System.Windows.Forms.Padding(15);
            this.pnlNuevoProducto.Size = new System.Drawing.Size(1018, 468);
            this.pnlNuevoProducto.TabIndex = 2;
            // 
            // btnGuardarProducto
            // 
            this.btnGuardarProducto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(175)))), ((int)(((byte)(80)))));
            this.btnGuardarProducto.FlatAppearance.BorderSize = 0;
            this.btnGuardarProducto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGuardarProducto.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnGuardarProducto.ForeColor = System.Drawing.Color.White;
            this.btnGuardarProducto.Location = new System.Drawing.Point(890, 400);
            this.btnGuardarProducto.Name = "btnGuardarProducto";
            this.btnGuardarProducto.Size = new System.Drawing.Size(100, 35);
            this.btnGuardarProducto.TabIndex = 31;
            this.btnGuardarProducto.Text = "✓ Guardar";
            this.btnGuardarProducto.UseVisualStyleBackColor = false;
            this.btnGuardarProducto.Click += new System.EventHandler(this.btnGuardarProducto_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancelar.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnCancelar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.btnCancelar.Location = new System.Drawing.Point(780, 400);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(100, 35);
            this.btnCancelar.TabIndex = 30;
            this.btnCancelar.Text = "X Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            // 
            // txtMaximo
            // 
            this.txtMaximo.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtMaximo.Location = new System.Drawing.Point(575, 305);
            this.txtMaximo.Name = "txtMaximo";
            this.txtMaximo.Size = new System.Drawing.Size(60, 23);
            this.txtMaximo.TabIndex = 29;
            this.txtMaximo.Text = "0";
            // 
            // lblMaximo
            // 
            this.lblMaximo.AutoSize = true;
            this.lblMaximo.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblMaximo.Location = new System.Drawing.Point(520, 305);
            this.lblMaximo.Name = "lblMaximo";
            this.lblMaximo.Size = new System.Drawing.Size(53, 15);
            this.lblMaximo.TabIndex = 28;
            this.lblMaximo.Text = "Máximo:";
            // 
            // txtMinimo
            // 
            this.txtMinimo.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtMinimo.Location = new System.Drawing.Point(450, 305);
            this.txtMinimo.Name = "txtMinimo";
            this.txtMinimo.Size = new System.Drawing.Size(60, 23);
            this.txtMinimo.TabIndex = 27;
            this.txtMinimo.Text = "0";
            // 
            // lblMinimo
            // 
            this.lblMinimo.AutoSize = true;
            this.lblMinimo.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblMinimo.Location = new System.Drawing.Point(400, 305);
            this.lblMinimo.Name = "lblMinimo";
            this.lblMinimo.Size = new System.Drawing.Size(52, 15);
            this.lblMinimo.TabIndex = 26;
            this.lblMinimo.Text = "Mínimo:";
            // 
            // txtHay
            // 
            this.txtHay.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtHay.Location = new System.Drawing.Point(330, 305);
            this.txtHay.Name = "txtHay";
            this.txtHay.Size = new System.Drawing.Size(60, 23);
            this.txtHay.TabIndex = 25;
            this.txtHay.Text = "0";
            // 
            // lblHay
            // 
            this.lblHay.AutoSize = true;
            this.lblHay.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblHay.Location = new System.Drawing.Point(295, 305);
            this.lblHay.Name = "lblHay";
            this.lblHay.Size = new System.Drawing.Size(31, 15);
            this.lblHay.TabIndex = 24;
            this.lblHay.Text = "Hay:";
            // 
            // chkUsaInventario
            // 
            this.chkUsaInventario.AutoSize = true;
            this.chkUsaInventario.Checked = true;
            this.chkUsaInventario.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkUsaInventario.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.chkUsaInventario.Location = new System.Drawing.Point(85, 265);
            this.chkUsaInventario.Name = "chkUsaInventario";
            this.chkUsaInventario.Size = new System.Drawing.Size(204, 19);
            this.chkUsaInventario.TabIndex = 23;
            this.chkUsaInventario.Text = "Este producto SI utiliza inventario.";
            this.chkUsaInventario.UseVisualStyleBackColor = true;
            // 
            // lblInventario
            // 
            this.lblInventario.AutoSize = true;
            this.lblInventario.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblInventario.Location = new System.Drawing.Point(15, 265);
            this.lblInventario.Name = "lblInventario";
            this.lblInventario.Size = new System.Drawing.Size(65, 15);
            this.lblInventario.TabIndex = 22;
            this.lblInventario.Text = "Inventario";
            // 
            // cboDepartamento
            // 
            this.cboDepartamento.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboDepartamento.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.cboDepartamento.FormattingEnabled = true;
            this.cboDepartamento.Items.AddRange(new object[] {
            "- Sin Departamento -"});
            this.cboDepartamento.Location = new System.Drawing.Point(560, 225);
            this.cboDepartamento.Name = "cboDepartamento";
            this.cboDepartamento.Size = new System.Drawing.Size(200, 23);
            this.cboDepartamento.TabIndex = 21;
            // 
            // btnAdministrarDepartamentos
            // 
            this.btnAdministrarDepartamentos.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnAdministrarDepartamentos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdministrarDepartamentos.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.btnAdministrarDepartamentos.Location = new System.Drawing.Point(770, 224);
            this.btnAdministrarDepartamentos.Name = "btnAdministrarDepartamentos";
            this.btnAdministrarDepartamentos.Size = new System.Drawing.Size(200, 25);
            this.btnAdministrarDepartamentos.TabIndex = 21;
            this.btnAdministrarDepartamentos.Text = "Administrar Departamentos...";
            this.btnAdministrarDepartamentos.UseVisualStyleBackColor = true;
            // 
            // lblDepartamento
            // 
            this.lblDepartamento.AutoSize = true;
            this.lblDepartamento.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblDepartamento.Location = new System.Drawing.Point(470, 225);
            this.lblDepartamento.Name = "lblDepartamento";
            this.lblDepartamento.Size = new System.Drawing.Size(86, 15);
            this.lblDepartamento.TabIndex = 20;
            this.lblDepartamento.Text = "Departamento:";
            // 
            // txtPrecioMayoreo
            // 
            this.txtPrecioMayoreo.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtPrecioMayoreo.Location = new System.Drawing.Point(330, 225);
            this.txtPrecioMayoreo.Name = "txtPrecioMayoreo";
            this.txtPrecioMayoreo.Size = new System.Drawing.Size(120, 23);
            this.txtPrecioMayoreo.TabIndex = 19;
            this.txtPrecioMayoreo.Text = "$0.00";
            // 
            // lblPrecioMayoreo
            // 
            this.lblPrecioMayoreo.AutoSize = true;
            this.lblPrecioMayoreo.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblPrecioMayoreo.Location = new System.Drawing.Point(230, 225);
            this.lblPrecioMayoreo.Name = "lblPrecioMayoreo";
            this.lblPrecioMayoreo.Size = new System.Drawing.Size(93, 15);
            this.lblPrecioMayoreo.TabIndex = 18;
            this.lblPrecioMayoreo.Text = "Precio Mayoreo:";
            // 
            // txtPrecioVenta
            // 
            this.txtPrecioVenta.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtPrecioVenta.Location = new System.Drawing.Point(95, 225);
            this.txtPrecioVenta.Name = "txtPrecioVenta";
            this.txtPrecioVenta.Size = new System.Drawing.Size(120, 23);
            this.txtPrecioVenta.TabIndex = 17;
            this.txtPrecioVenta.Text = "$0.00";
            // 
            // lblPrecioVenta
            // 
            this.lblPrecioVenta.AutoSize = true;
            this.lblPrecioVenta.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblPrecioVenta.Location = new System.Drawing.Point(15, 225);
            this.lblPrecioVenta.Name = "lblPrecioVenta";
            this.lblPrecioVenta.Size = new System.Drawing.Size(75, 15);
            this.lblPrecioVenta.TabIndex = 16;
            this.lblPrecioVenta.Text = "Precio Venta:";
            // 
            // cboGanancia
            // 
            this.cboGanancia.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboGanancia.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.cboGanancia.FormattingEnabled = true;
            this.cboGanancia.Items.AddRange(new object[] {
            "%",
            "$"});
            this.cboGanancia.Location = new System.Drawing.Point(380, 190);
            this.cboGanancia.Name = "cboGanancia";
            this.cboGanancia.Size = new System.Drawing.Size(50, 23);
            this.cboGanancia.TabIndex = 15;
            // 
            // txtGanancia
            // 
            this.txtGanancia.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtGanancia.Location = new System.Drawing.Point(290, 190);
            this.txtGanancia.Name = "txtGanancia";
            this.txtGanancia.Size = new System.Drawing.Size(80, 23);
            this.txtGanancia.TabIndex = 14;
            this.txtGanancia.Text = "20.00";
            // 
            // lblGanancia
            // 
            this.lblGanancia.AutoSize = true;
            this.lblGanancia.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblGanancia.Location = new System.Drawing.Point(230, 190);
            this.lblGanancia.Name = "lblGanancia";
            this.lblGanancia.Size = new System.Drawing.Size(59, 15);
            this.lblGanancia.TabIndex = 13;
            this.lblGanancia.Text = "Ganancia:";
            // 
            // txtPrecioCosto
            // 
            this.txtPrecioCosto.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtPrecioCosto.Location = new System.Drawing.Point(95, 190);
            this.txtPrecioCosto.Name = "txtPrecioCosto";
            this.txtPrecioCosto.Size = new System.Drawing.Size(120, 23);
            this.txtPrecioCosto.TabIndex = 12;
            this.txtPrecioCosto.Text = "$0.00";
            // 
            // lblPrecioCosto
            // 
            this.lblPrecioCosto.AutoSize = true;
            this.lblPrecioCosto.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblPrecioCosto.Location = new System.Drawing.Point(15, 190);
            this.lblPrecioCosto.Name = "lblPrecioCosto";
            this.lblPrecioCosto.Size = new System.Drawing.Size(77, 15);
            this.lblPrecioCosto.TabIndex = 11;
            this.lblPrecioCosto.Text = "Precio Costo:";
            // 
            // rdbPaquete
            // 
            this.rdbPaquete.AutoSize = true;
            this.rdbPaquete.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.rdbPaquete.Location = new System.Drawing.Point(355, 155);
            this.rdbPaquete.Name = "rdbPaquete";
            this.rdbPaquete.Size = new System.Drawing.Size(128, 19);
            this.rdbPaquete.TabIndex = 10;
            this.rdbPaquete.TabStop = true;
            this.rdbPaquete.Text = "Como paquete (kit)";
            this.rdbPaquete.UseVisualStyleBackColor = true;
            // 
            // rdbGranel
            // 
            this.rdbGranel.AutoSize = true;
            this.rdbGranel.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.rdbGranel.Location = new System.Drawing.Point(190, 155);
            this.rdbGranel.Name = "rdbGranel";
            this.rdbGranel.Size = new System.Drawing.Size(157, 19);
            this.rdbGranel.TabIndex = 9;
            this.rdbGranel.TabStop = true;
            this.rdbGranel.Text = "A Granel (Usa Decimales)";
            this.rdbGranel.UseVisualStyleBackColor = true;
            // 
            // rdbUnidad
            // 
            this.rdbUnidad.AutoSize = true;
            this.rdbUnidad.Checked = true;
            this.rdbUnidad.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.rdbUnidad.Location = new System.Drawing.Point(75, 155);
            this.rdbUnidad.Name = "rdbUnidad";
            this.rdbUnidad.Size = new System.Drawing.Size(107, 19);
            this.rdbUnidad.TabIndex = 8;
            this.rdbUnidad.TabStop = true;
            this.rdbUnidad.Text = "Por Unidad/Pza";
            this.rdbUnidad.UseVisualStyleBackColor = true;
            // 
            // lblSeVende
            // 
            this.lblSeVende.AutoSize = true;
            this.lblSeVende.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblSeVende.Location = new System.Drawing.Point(15, 155);
            this.lblSeVende.Name = "lblSeVende";
            this.lblSeVende.Size = new System.Drawing.Size(57, 15);
            this.lblSeVende.TabIndex = 7;
            this.lblSeVende.Text = "Se vende:";
            // 
            // txtDescripcion
            // 
            this.txtDescripcion.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtDescripcion.Location = new System.Drawing.Point(140, 120);
            this.txtDescripcion.Name = "txtDescripcion";
            this.txtDescripcion.Size = new System.Drawing.Size(400, 23);
            this.txtDescripcion.TabIndex = 6;
            // 
            // lblDescripcion
            // 
            this.lblDescripcion.AutoSize = true;
            this.lblDescripcion.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblDescripcion.Location = new System.Drawing.Point(15, 120);
            this.lblDescripcion.Name = "lblDescripcion";
            this.lblDescripcion.Size = new System.Drawing.Size(69, 15);
            this.lblDescripcion.TabIndex = 5;
            this.lblDescripcion.Text = "Descripción";
            // 
            // txtCodigoBarras
            // 
            this.txtCodigoBarras.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtCodigoBarras.Location = new System.Drawing.Point(140, 85);
            this.txtCodigoBarras.Name = "txtCodigoBarras";
            this.txtCodigoBarras.Size = new System.Drawing.Size(200, 23);
            this.txtCodigoBarras.TabIndex = 4;
            // 
            // lblCodigoBarras
            // 
            this.lblCodigoBarras.AutoSize = true;
            this.lblCodigoBarras.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblCodigoBarras.Location = new System.Drawing.Point(15, 85);
            this.lblCodigoBarras.Name = "lblCodigoBarras";
            this.lblCodigoBarras.Size = new System.Drawing.Size(97, 15);
            this.lblCodigoBarras.TabIndex = 3;
            this.lblCodigoBarras.Text = "Código de Barras";
            // 
            // txtProducto
            // 
            this.txtProducto.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtProducto.Location = new System.Drawing.Point(75, 50);
            this.txtProducto.Name = "txtProducto";
            this.txtProducto.Size = new System.Drawing.Size(350, 23);
            this.txtProducto.TabIndex = 2;
            // 
            // lblProducto
            // 
            this.lblProducto.AutoSize = true;
            this.lblProducto.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblProducto.Location = new System.Drawing.Point(15, 50);
            this.lblProducto.Name = "lblProducto";
            this.lblProducto.Size = new System.Drawing.Size(59, 15);
            this.lblProducto.TabIndex = 1;
            this.lblProducto.Text = "Producto:";
            // 
            // lblNuevoProducto
            // 
            this.lblNuevoProducto.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblNuevoProducto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.lblNuevoProducto.Location = new System.Drawing.Point(15, 15);
            this.lblNuevoProducto.Name = "lblNuevoProducto";
            this.lblNuevoProducto.Size = new System.Drawing.Size(200, 23);
            this.lblNuevoProducto.TabIndex = 0;
            this.lblNuevoProducto.Text = "NUEVO PRODUCTO";
            // 
            // productos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.ClientSize = new System.Drawing.Size(1302, 571);
            this.Controls.Add(this.pnlNuevoProducto);
            this.Controls.Add(this.pnlActionBar);
            this.Controls.Add(this.lblProductosTitle);
            this.Name = "productos";
            this.Text = "productos";
            this.pnlActionBar.ResumeLayout(false);
            this.pnlNuevoProducto.ResumeLayout(false);
            this.pnlNuevoProducto.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblProductosTitle;
        private System.Windows.Forms.Panel pnlActionBar;
        private System.Windows.Forms.Button btnNuevo;
        private System.Windows.Forms.Button btnModificar;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.Button btnDepartamentosBar;
        private System.Windows.Forms.Button btnVentasPeriodo;
        private System.Windows.Forms.Button btnPromociones;
        private System.Windows.Forms.Button btnImportar;
        private System.Windows.Forms.Button btnCatalogo;
        private System.Windows.Forms.Panel pnlNuevoProducto;
        private System.Windows.Forms.Button btnGuardarProducto;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Label lblNuevoProducto;
        private System.Windows.Forms.Label lblProducto;
        private System.Windows.Forms.TextBox txtProducto;
        private System.Windows.Forms.Label lblCodigoBarras;
        private System.Windows.Forms.TextBox txtCodigoBarras;
        private System.Windows.Forms.Label lblDescripcion;
        private System.Windows.Forms.TextBox txtDescripcion;
        private System.Windows.Forms.Label lblSeVende;
        private System.Windows.Forms.RadioButton rdbUnidad;
        private System.Windows.Forms.RadioButton rdbGranel;
        private System.Windows.Forms.RadioButton rdbPaquete;
        private System.Windows.Forms.Label lblPrecioCosto;
        private System.Windows.Forms.TextBox txtPrecioCosto;
        private System.Windows.Forms.Label lblGanancia;
        private System.Windows.Forms.TextBox txtGanancia;
        private System.Windows.Forms.ComboBox cboGanancia;
        private System.Windows.Forms.Label lblPrecioVenta;
        private System.Windows.Forms.TextBox txtPrecioVenta;
        private System.Windows.Forms.Label lblPrecioMayoreo;
        private System.Windows.Forms.TextBox txtPrecioMayoreo;
        private System.Windows.Forms.Label lblDepartamento;
        private System.Windows.Forms.ComboBox cboDepartamento;
        private System.Windows.Forms.Button btnAdministrarDepartamentos;
        private System.Windows.Forms.Label lblInventario;
        private System.Windows.Forms.CheckBox chkUsaInventario;
        private System.Windows.Forms.Label lblHay;
        private System.Windows.Forms.TextBox txtHay;
        private System.Windows.Forms.Label lblMinimo;
        private System.Windows.Forms.TextBox txtMinimo;
        private System.Windows.Forms.Label lblMaximo;
        private System.Windows.Forms.TextBox txtMaximo;
    }
}
