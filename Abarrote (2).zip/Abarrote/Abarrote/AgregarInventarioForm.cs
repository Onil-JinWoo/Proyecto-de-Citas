using System;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace Abarrote
{
    public class AgregarInventarioForm : Form
    {
        private readonly string _codigo;
        private ProductoInfo _producto;

        private TextBox _txtCodigo;
        private Label _lblDescripcion;
        private Label _lblHay;

        private NumericUpDown _numAgregar;
        private NumericUpDown _numCosto;
        private NumericUpDown _numVenta;
        private NumericUpDown _numMayoreo;

        private Button _btnGuardar;
        private Button _btnCancelar;

        public AgregarInventarioForm(string codigoBarras)
        {
            _codigo = (codigoBarras ?? string.Empty).Trim();
            InicializarUi();
            Load += (s, e) => CargarProducto();
        }

        private void InicializarUi()
        {
            Text = "Agregar inventario";
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ClientSize = new Size(520, 360);
            BackColor = Color.White;

            Label lblTitulo = new Label();
            lblTitulo.Dock = DockStyle.Top;
            lblTitulo.Height = 34;
            lblTitulo.BackColor = Color.FromArgb(128, 80, 160);
            lblTitulo.ForeColor = Color.White;
            lblTitulo.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblTitulo.TextAlign = ContentAlignment.MiddleLeft;
            lblTitulo.Padding = new Padding(10, 0, 0, 0);
            lblTitulo.Text = "AGREGAR INVENTARIO";

            Controls.Add(lblTitulo);

            int xLabel = 20;
            int xInput = 160;
            int y = 55;
            int dy = 32;

            Label lblCodigo = new Label();
            lblCodigo.Text = "Código del Producto";
            lblCodigo.Location = new Point(xLabel, y);
            lblCodigo.AutoSize = true;
            lblCodigo.Font = new Font("Segoe UI", 9F);

            _txtCodigo = new TextBox();
            _txtCodigo.Location = new Point(xInput, y - 3);
            _txtCodigo.Size = new Size(220, 23);
            _txtCodigo.Font = new Font("Segoe UI", 9F);
            _txtCodigo.ReadOnly = true;
            _txtCodigo.Text = _codigo;

            y += dy;

            Label lblDesc = new Label();
            lblDesc.Text = "Descripción";
            lblDesc.Location = new Point(xLabel, y);
            lblDesc.AutoSize = true;
            lblDesc.Font = new Font("Segoe UI", 9F);

            _lblDescripcion = new Label();
            _lblDescripcion.Location = new Point(xInput, y);
            _lblDescripcion.Size = new Size(330, 20);
            _lblDescripcion.Font = new Font("Segoe UI", 9F);

            y += dy;

            Label lblHay = new Label();
            lblHay.Text = "Hay";
            lblHay.Location = new Point(xLabel, y);
            lblHay.AutoSize = true;
            lblHay.Font = new Font("Segoe UI", 9F);

            _lblHay = new Label();
            _lblHay.Location = new Point(xInput, y);
            _lblHay.Size = new Size(200, 20);
            _lblHay.Font = new Font("Segoe UI", 9F);

            y += dy;

            Label lblAgregar = new Label();
            lblAgregar.Text = "Agregar";
            lblAgregar.Location = new Point(xLabel, y);
            lblAgregar.AutoSize = true;
            lblAgregar.Font = new Font("Segoe UI", 9F);

            _numAgregar = new NumericUpDown();
            _numAgregar.Location = new Point(xInput, y - 3);
            _numAgregar.Size = new Size(120, 23);
            _numAgregar.Maximum = 1000000;
            _numAgregar.DecimalPlaces = 0;

            y += dy;

            Label lblCosto = new Label();
            lblCosto.Text = "Precio Costo";
            lblCosto.Location = new Point(xLabel, y);
            lblCosto.AutoSize = true;
            lblCosto.Font = new Font("Segoe UI", 9F);

            _numCosto = new NumericUpDown();
            _numCosto.Location = new Point(xInput, y - 3);
            _numCosto.Size = new Size(120, 23);
            _numCosto.Maximum = 100000000;
            _numCosto.DecimalPlaces = 2;
            _numCosto.ThousandsSeparator = true;

            y += dy;

            Label lblVenta = new Label();
            lblVenta.Text = "Precio Venta";
            lblVenta.Location = new Point(xLabel, y);
            lblVenta.AutoSize = true;
            lblVenta.Font = new Font("Segoe UI", 9F);

            _numVenta = new NumericUpDown();
            _numVenta.Location = new Point(xInput, y - 3);
            _numVenta.Size = new Size(120, 23);
            _numVenta.Maximum = 100000000;
            _numVenta.DecimalPlaces = 2;
            _numVenta.ThousandsSeparator = true;

            y += dy;

            Label lblMayoreo = new Label();
            lblMayoreo.Text = "Precio Mayoreo";
            lblMayoreo.Location = new Point(xLabel, y);
            lblMayoreo.AutoSize = true;
            lblMayoreo.Font = new Font("Segoe UI", 9F);

            _numMayoreo = new NumericUpDown();
            _numMayoreo.Location = new Point(xInput, y - 3);
            _numMayoreo.Size = new Size(120, 23);
            _numMayoreo.Maximum = 100000000;
            _numMayoreo.DecimalPlaces = 2;
            _numMayoreo.ThousandsSeparator = true;

            _btnGuardar = new Button();
            _btnGuardar.Text = "✓ Agregar cantidad a inventario";
            _btnGuardar.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            _btnGuardar.FlatStyle = FlatStyle.Flat;
            _btnGuardar.FlatAppearance.BorderColor = Color.Silver;
            _btnGuardar.Size = new Size(260, 34);
            _btnGuardar.Location = new Point(xInput, 275);
            _btnGuardar.Click += (s, e) => Guardar();

            _btnCancelar = new Button();
            _btnCancelar.Text = "X Cancelar";
            _btnCancelar.Font = new Font("Segoe UI", 9F);
            _btnCancelar.FlatStyle = FlatStyle.Flat;
            _btnCancelar.FlatAppearance.BorderColor = Color.Silver;
            _btnCancelar.Size = new Size(110, 34);
            _btnCancelar.Location = new Point(20, 275);
            _btnCancelar.Click += (s, e) => { DialogResult = DialogResult.Cancel; Close(); };

            Controls.Add(lblCodigo);
            Controls.Add(_txtCodigo);
            Controls.Add(lblDesc);
            Controls.Add(_lblDescripcion);
            Controls.Add(lblHay);
            Controls.Add(_lblHay);
            Controls.Add(lblAgregar);
            Controls.Add(_numAgregar);
            Controls.Add(lblCosto);
            Controls.Add(_numCosto);
            Controls.Add(lblVenta);
            Controls.Add(_numVenta);
            Controls.Add(lblMayoreo);
            Controls.Add(_numMayoreo);
            Controls.Add(_btnGuardar);
            Controls.Add(_btnCancelar);

            AcceptButton = _btnGuardar;
        }

        private void CargarProducto()
        {
            if (string.IsNullOrWhiteSpace(_codigo))
            {
                MessageBox.Show("Captura el código de barras.", "Inventario", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                DialogResult = DialogResult.Cancel;
                Close();
                return;
            }

            _producto = DatabaseHelper.ObtenerProductoPorCodigoBarras(_codigo);
            if (_producto == null)
            {
                MessageBox.Show("Producto no encontrado.", "Inventario", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                DialogResult = DialogResult.Cancel;
                Close();
                return;
            }

            if (_lblDescripcion != null) _lblDescripcion.Text = _producto.Descripcion;
            if (_lblHay != null) _lblHay.Text = _producto.StockActual.ToString(CultureInfo.CurrentCulture);

            if (_numCosto != null) _numCosto.Value = ClampDecimal(_producto.PrecioCosto, _numCosto.Maximum);
            if (_numVenta != null) _numVenta.Value = ClampDecimal(_producto.PrecioVenta, _numVenta.Maximum);
            if (_numMayoreo != null) _numMayoreo.Value = ClampDecimal(_producto.PrecioMayoreo, _numMayoreo.Maximum);

            if (_numAgregar != null)
            {
                _numAgregar.Value = 0;
                _numAgregar.Focus();
                _numAgregar.Select(0, _numAgregar.Text.Length);
            }
        }

        private static decimal ClampDecimal(decimal value, decimal max)
        {
            if (value < 0m) return 0m;
            if (value > max) return max;
            return value;
        }

        private void Guardar()
        {
            if (_producto == null)
                return;

            int agregar = _numAgregar == null ? 0 : (int)_numAgregar.Value;
            decimal costo = _numCosto == null ? 0m : _numCosto.Value;
            decimal venta = _numVenta == null ? 0m : _numVenta.Value;
            decimal mayoreo = _numMayoreo == null ? 0m : _numMayoreo.Value;

            if (agregar <= 0)
            {
                MessageBox.Show("Captura la cantidad a agregar.", "Inventario", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (_numAgregar != null) _numAgregar.Focus();
                return;
            }

            string err;
            if (!DatabaseHelper.AgregarInventarioYActualizarPrecios(_producto.CodigoBarras, agregar, costo, venta, mayoreo, out err))
            {
                MessageBox.Show(string.IsNullOrWhiteSpace(err) ? "No se pudo actualizar el inventario." : err, "Inventario", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult = DialogResult.OK;
            Close();
        }
    }
}
