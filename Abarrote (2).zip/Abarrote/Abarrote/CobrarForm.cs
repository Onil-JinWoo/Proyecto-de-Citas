using System;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace Abarrote
{
    public enum MetodoPago
    {
        Efectivo,
        Credito,
        Mixto,
        Transferencia
    }

    public class CobrarResult
    {
        public MetodoPago Metodo { get; set; }
        public decimal Total { get; set; }
        public decimal Efectivo { get; set; }
        public decimal Credito { get; set; }
        public decimal Transferencia { get; set; }
        public string Referencia { get; set; }

        public decimal PagadoTotal
        {
            get { return Efectivo + Credito + Transferencia; }
        }

        public decimal Cambio
        {
            get
            {
                if (Metodo != MetodoPago.Efectivo)
                    return 0m;

                decimal c = Efectivo - Total;
                return c < 0m ? 0m : c;
            }
        }

        public decimal PagoConParaMostrar
        {
            get
            {
                if (Metodo == MetodoPago.Efectivo)
                    return Efectivo;
                return PagadoTotal;
            }
        }
    }

    public class CobrarForm : Form
    {
        private readonly decimal _total;
        private readonly int _idClienteAsignado;
        private readonly string _nombreClienteAsignado;

        private Label _lblTotal;
        private Button _btnEfectivo;
        private Button _btnCredito;
        private Button _btnMixto;
        private Button _btnTransferencia;

        private Panel _pnlBody;
        private Panel _pnlEfectivo;
        private Panel _pnlTransferencia;
        private Panel _pnlMixto;
        private Panel _pnlCredito;

        private Label _lblCreditoInfo;

        private TextBox _txtEfectivo;
        private Label _lblCambio;

        private TextBox _txtRef;

        private TextBox _txtMixEfectivo;
        private TextBox _txtMixCredito;
        private TextBox _txtMixTransferencia;
        private Label _lblMixRestante;

        private Button _btnCobrar;
        private Button _btnCancelar;

        public CobrarResult Result { get; private set; }

        public CobrarForm(decimal total)
            : this(total, 0, string.Empty)
        {
        }

        public CobrarForm(decimal total, int idClienteAsignado, string nombreClienteAsignado)
        {
            _total = total < 0m ? 0m : total;
            _idClienteAsignado = idClienteAsignado;
            _nombreClienteAsignado = nombreClienteAsignado;
            InitializeUi();
            SetMetodo(MetodoPago.Efectivo);
        }

        private void InitializeUi()
        {
            Text = "Cobrar";
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MinimizeBox = false;
            MaximizeBox = false;
            ShowInTaskbar = false;
            ClientSize = new Size(720, 420);

            _lblTotal = new Label();
            _lblTotal.Dock = DockStyle.Top;
            _lblTotal.Height = 70;
            _lblTotal.Font = new Font("Segoe UI", 34F, FontStyle.Bold);
            _lblTotal.TextAlign = ContentAlignment.MiddleCenter;
            _lblTotal.ForeColor = Color.FromArgb(0, 102, 204);
            _lblTotal.Text = _total.ToString("C2", CultureInfo.CurrentCulture);

            Panel pnlTabs = new Panel();
            pnlTabs.Dock = DockStyle.Top;
            pnlTabs.Height = 70;

            pnlTabs.Padding = new Padding(10, 8, 10, 8);

            _btnEfectivo = new Button();
            _btnEfectivo.Text = "Efectivo";
            _btnEfectivo.Size = new Size(165, 54);
            _btnEfectivo.Location = new Point(10, 8);
            _btnEfectivo.Click += (s, e) => SetMetodo(MetodoPago.Efectivo);

            _btnCredito = new Button();
            _btnCredito.Text = "Crédito";
            _btnCredito.Size = new Size(165, 54);
            _btnCredito.Location = new Point(185, 8);
            _btnCredito.Click += (s, e) => SetMetodo(MetodoPago.Credito);

            _btnMixto = new Button();
            _btnMixto.Text = "Mixto";
            _btnMixto.Size = new Size(165, 54);
            _btnMixto.Location = new Point(360, 8);
            _btnMixto.Click += (s, e) => SetMetodo(MetodoPago.Mixto);

            _btnTransferencia = new Button();
            _btnTransferencia.Text = "Transferencia";
            _btnTransferencia.Size = new Size(165, 54);
            _btnTransferencia.Location = new Point(535, 8);
            _btnTransferencia.Click += (s, e) => SetMetodo(MetodoPago.Transferencia);

            DecorarBotonMetodo(_btnEfectivo, SystemIcons.Information.ToBitmap());
            DecorarBotonMetodo(_btnCredito, SystemIcons.Shield.ToBitmap());
            DecorarBotonMetodo(_btnMixto, SystemIcons.Warning.ToBitmap());
            DecorarBotonMetodo(_btnTransferencia, SystemIcons.Application.ToBitmap());

            pnlTabs.Controls.Add(_btnEfectivo);
            pnlTabs.Controls.Add(_btnCredito);
            pnlTabs.Controls.Add(_btnMixto);
            pnlTabs.Controls.Add(_btnTransferencia);

            _pnlBody = new Panel();
            _pnlBody.Dock = DockStyle.Fill;
            _pnlBody.Padding = new Padding(20, 10, 20, 10);

            InitializePanelEfectivo();
            InitializePanelCredito();
            InitializePanelMixto();
            InitializePanelTransferencia();

            _pnlBody.Controls.Add(_pnlEfectivo);
            _pnlBody.Controls.Add(_pnlCredito);
            _pnlBody.Controls.Add(_pnlMixto);
            _pnlBody.Controls.Add(_pnlTransferencia);

            Panel pnlBottom = new Panel();
            pnlBottom.Dock = DockStyle.Bottom;
            pnlBottom.Height = 60;

            _btnCobrar = new Button();
            _btnCobrar.Text = "F1 - Cobrar";
            _btnCobrar.Size = new Size(180, 36);
            _btnCobrar.Location = new Point(12, 12);
            _btnCobrar.Click += (s, e) => Confirmar();

            _btnCancelar = new Button();
            _btnCancelar.Text = "ESC - Cancelar";
            _btnCancelar.Size = new Size(150, 36);
            _btnCancelar.Location = new Point(555, 12);
            _btnCancelar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            _btnCancelar.Click += (s, e) => { DialogResult = DialogResult.Cancel; Close(); };

            pnlBottom.Controls.Add(_btnCobrar);
            pnlBottom.Controls.Add(_btnCancelar);

            Controls.Add(_pnlBody);
            Controls.Add(pnlBottom);
            Controls.Add(pnlTabs);
            Controls.Add(_lblTotal);

            KeyPreview = true;
            KeyDown += CobrarForm_KeyDown;

            AcceptButton = _btnCobrar;
            CancelButton = _btnCancelar;
        }

        private static void DecorarBotonMetodo(Button b, Bitmap icon)
        {
            if (b == null)
                return;

            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderColor = Color.Silver;
            b.FlatAppearance.BorderSize = 1;

            b.Image = icon;
            b.ImageAlign = ContentAlignment.MiddleLeft;
            b.TextAlign = ContentAlignment.MiddleRight;
            b.Padding = new Padding(8, 0, 8, 0);
        }

        private void CobrarForm_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                e.SuppressKeyPress = true;
                DialogResult = DialogResult.Cancel;
                Close();
                return;
            }

            if (e.KeyCode == Keys.F1)
            {
                e.SuppressKeyPress = true;
                Confirmar();
                return;
            }
        }

        private void InitializePanelEfectivo()
        {
            _pnlEfectivo = new Panel();
            _pnlEfectivo.Dock = DockStyle.Fill;

            Label lblPagoCon = new Label();
            lblPagoCon.Text = "Pagó con:";
            lblPagoCon.Location = new Point(180, 30);
            lblPagoCon.AutoSize = true;
            lblPagoCon.Font = new Font("Segoe UI", 12F, FontStyle.Bold);

            _txtEfectivo = new TextBox();
            _txtEfectivo.Location = new Point(280, 28);
            _txtEfectivo.Width = 220;
            _txtEfectivo.Font = new Font("Consolas", 14F, FontStyle.Bold);
            _txtEfectivo.Text = _total.ToString("0.00", CultureInfo.InvariantCulture);
            _txtEfectivo.TextChanged += (s, e) => ActualizarCambioEfectivo();

            Label lblCambioTitulo = new Label();
            lblCambioTitulo.Text = "Cambio:";
            lblCambioTitulo.Location = new Point(200, 80);
            lblCambioTitulo.AutoSize = true;
            lblCambioTitulo.Font = new Font("Segoe UI", 12F, FontStyle.Bold);

            _lblCambio = new Label();
            _lblCambio.Location = new Point(280, 78);
            _lblCambio.AutoSize = true;
            _lblCambio.Font = new Font("Consolas", 16F, FontStyle.Bold);
            _lblCambio.ForeColor = Color.FromArgb(0, 102, 204);

            _pnlEfectivo.Controls.Add(lblPagoCon);
            _pnlEfectivo.Controls.Add(_txtEfectivo);
            _pnlEfectivo.Controls.Add(lblCambioTitulo);
            _pnlEfectivo.Controls.Add(_lblCambio);
        }

        private void InitializePanelCredito()
        {
            _pnlCredito = new Panel();
            _pnlCredito.Dock = DockStyle.Fill;

            _lblCreditoInfo = new Label();
            _lblCreditoInfo.Location = new Point(40, 40);
            _lblCreditoInfo.AutoSize = true;
            _lblCreditoInfo.Font = new Font("Segoe UI", 11F);
            _pnlCredito.Controls.Add(_lblCreditoInfo);

            ActualizarInfoCredito();
        }

        private void ActualizarInfoCredito()
        {
            if (_lblCreditoInfo == null)
                return;

            if (_idClienteAsignado > 0)
            {
                string n = string.IsNullOrWhiteSpace(_nombreClienteAsignado) ? _idClienteAsignado.ToString() : _nombreClienteAsignado.Trim();
                _lblCreditoInfo.Text = string.Format(CultureInfo.CurrentCulture, "Crédito: se registrará a nombre de {0}", n);
            }
            else
            {
                _lblCreditoInfo.Text = "Crédito: primero asigna un cliente a la venta.";
            }
        }

        private void InitializePanelTransferencia()
        {
            _pnlTransferencia = new Panel();
            _pnlTransferencia.Dock = DockStyle.Fill;

            Label lblRef = new Label();
            lblRef.Text = "Referencia:";
            lblRef.Location = new Point(40, 40);
            lblRef.AutoSize = true;
            lblRef.Font = new Font("Segoe UI", 11F, FontStyle.Bold);

            _txtRef = new TextBox();
            _txtRef.Location = new Point(140, 38);
            _txtRef.Width = 520;
            _txtRef.Font = new Font("Segoe UI", 11F);

            _pnlTransferencia.Controls.Add(lblRef);
            _pnlTransferencia.Controls.Add(_txtRef);
        }

        private void InitializePanelMixto()
        {
            _pnlMixto = new Panel();
            _pnlMixto.Dock = DockStyle.Fill;

            Label l1 = new Label();
            l1.Text = "Efectivo";
            l1.Location = new Point(120, 40);
            l1.AutoSize = true;
            l1.Font = new Font("Segoe UI", 11F, FontStyle.Bold);

            _txtMixEfectivo = new TextBox();
            _txtMixEfectivo.Location = new Point(240, 38);
            _txtMixEfectivo.Width = 160;
            _txtMixEfectivo.Font = new Font("Consolas", 12F, FontStyle.Bold);
            _txtMixEfectivo.TextChanged += (s, e) => ActualizarRestanteMixto();

            Label l2 = new Label();
            l2.Text = "Crédito";
            l2.Location = new Point(120, 85);
            l2.AutoSize = true;
            l2.Font = new Font("Segoe UI", 11F, FontStyle.Bold);

            _txtMixCredito = new TextBox();
            _txtMixCredito.Location = new Point(240, 83);
            _txtMixCredito.Width = 160;
            _txtMixCredito.Font = new Font("Consolas", 12F, FontStyle.Bold);
            _txtMixCredito.TextChanged += (s, e) => ActualizarRestanteMixto();

            Label l3 = new Label();
            l3.Text = "Transferencia";
            l3.Location = new Point(120, 130);
            l3.AutoSize = true;
            l3.Font = new Font("Segoe UI", 11F, FontStyle.Bold);

            _txtMixTransferencia = new TextBox();
            _txtMixTransferencia.Location = new Point(240, 128);
            _txtMixTransferencia.Width = 160;
            _txtMixTransferencia.Font = new Font("Consolas", 12F, FontStyle.Bold);
            _txtMixTransferencia.TextChanged += (s, e) => ActualizarRestanteMixto();

            Label lR = new Label();
            lR.Text = "Restante:";
            lR.Location = new Point(120, 190);
            lR.AutoSize = true;
            lR.Font = new Font("Segoe UI", 12F, FontStyle.Bold);

            _lblMixRestante = new Label();
            _lblMixRestante.Location = new Point(240, 190);
            _lblMixRestante.AutoSize = true;
            _lblMixRestante.Font = new Font("Consolas", 14F, FontStyle.Bold);
            _lblMixRestante.ForeColor = Color.DarkRed;

            _pnlMixto.Controls.Add(l1);
            _pnlMixto.Controls.Add(_txtMixEfectivo);
            _pnlMixto.Controls.Add(l2);
            _pnlMixto.Controls.Add(_txtMixCredito);
            _pnlMixto.Controls.Add(l3);
            _pnlMixto.Controls.Add(_txtMixTransferencia);
            _pnlMixto.Controls.Add(lR);
            _pnlMixto.Controls.Add(_lblMixRestante);
        }

        private void SetMetodo(MetodoPago metodo)
        {
            _pnlEfectivo.Visible = metodo == MetodoPago.Efectivo;
            _pnlCredito.Visible = metodo == MetodoPago.Credito;
            _pnlMixto.Visible = metodo == MetodoPago.Mixto;
            _pnlTransferencia.Visible = metodo == MetodoPago.Transferencia;

            ActualizarBotones(metodo);

            if (metodo == MetodoPago.Credito)
                ActualizarInfoCredito();

            if (metodo == MetodoPago.Efectivo)
            {
                ActualizarCambioEfectivo();
                if (_txtEfectivo != null)
                {
                    _txtEfectivo.Focus();
                    _txtEfectivo.SelectAll();
                }
            }

            if (metodo == MetodoPago.Mixto)
            {
                if (_txtMixEfectivo != null && string.IsNullOrWhiteSpace(_txtMixEfectivo.Text))
                    _txtMixEfectivo.Text = "0";
                if (_txtMixCredito != null && string.IsNullOrWhiteSpace(_txtMixCredito.Text))
                    _txtMixCredito.Text = "0";
                if (_txtMixTransferencia != null && string.IsNullOrWhiteSpace(_txtMixTransferencia.Text))
                    _txtMixTransferencia.Text = "0";

                ActualizarRestanteMixto();
                if (_txtMixEfectivo != null)
                {
                    _txtMixEfectivo.Focus();
                    _txtMixEfectivo.SelectAll();
                }
            }

            if (metodo == MetodoPago.Transferencia)
            {
                if (_txtRef != null)
                    _txtRef.Focus();
            }
        }

        private void ActualizarBotones(MetodoPago metodo)
        {
            Color sel = Color.FromArgb(0, 86, 255);
            Color nsel = SystemColors.Control;
            Color selFore = Color.White;
            Color nselFore = SystemColors.ControlText;

            SetBtnStyle(_btnEfectivo, metodo == MetodoPago.Efectivo, sel, nsel, selFore, nselFore);
            SetBtnStyle(_btnCredito, metodo == MetodoPago.Credito, sel, nsel, selFore, nselFore);
            SetBtnStyle(_btnMixto, metodo == MetodoPago.Mixto, sel, nsel, selFore, nselFore);
            SetBtnStyle(_btnTransferencia, metodo == MetodoPago.Transferencia, sel, nsel, selFore, nselFore);
        }

        private static void SetBtnStyle(Button b, bool selected, Color sel, Color nsel, Color selFore, Color nselFore)
        {
            if (b == null)
                return;

            b.BackColor = selected ? sel : nsel;
            b.ForeColor = selected ? selFore : nselFore;
        }

        private void ActualizarCambioEfectivo()
        {
            decimal ef = ParseDecimal(_txtEfectivo == null ? string.Empty : _txtEfectivo.Text);
            decimal cambio = ef - _total;
            if (cambio < 0m)
                cambio = 0m;

            if (_lblCambio != null)
                _lblCambio.Text = cambio.ToString("C2", CultureInfo.CurrentCulture);
        }

        private void ActualizarRestanteMixto()
        {
            decimal ef = ParseDecimal(_txtMixEfectivo == null ? string.Empty : _txtMixEfectivo.Text);
            decimal cr = ParseDecimal(_txtMixCredito == null ? string.Empty : _txtMixCredito.Text);
            decimal tr = ParseDecimal(_txtMixTransferencia == null ? string.Empty : _txtMixTransferencia.Text);

            decimal pagado = ef + cr + tr;
            decimal restante = _total - pagado;

            if (_lblMixRestante != null)
            {
                _lblMixRestante.Text = restante.ToString("C2", CultureInfo.CurrentCulture);
                _lblMixRestante.ForeColor = restante <= 0m ? Color.FromArgb(76, 175, 80) : Color.DarkRed;
            }
        }

        private void Confirmar()
        {
            MetodoPago metodo = MetodoPago.Efectivo;
            if (_pnlCredito != null && _pnlCredito.Visible)
                metodo = MetodoPago.Credito;
            if (_pnlMixto != null && _pnlMixto.Visible)
                metodo = MetodoPago.Mixto;
            if (_pnlTransferencia != null && _pnlTransferencia.Visible)
                metodo = MetodoPago.Transferencia;

            CobrarResult r = new CobrarResult();
            r.Metodo = metodo;
            r.Total = _total;

            if (metodo == MetodoPago.Efectivo)
            {
                r.Efectivo = ParseDecimal(_txtEfectivo == null ? string.Empty : _txtEfectivo.Text);
                if (r.Efectivo < _total)
                {
                    MessageBox.Show("El efectivo no cubre el total.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }
            else if (metodo == MetodoPago.Credito)
            {
                if (_idClienteAsignado <= 0)
                {
                    MessageBox.Show("Para cobrar a crédito debes asignar un cliente a la venta.", "Crédito", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                r.Credito = _total;
            }
            else if (metodo == MetodoPago.Transferencia)
            {
                r.Transferencia = _total;
                r.Referencia = _txtRef == null ? string.Empty : (_txtRef.Text ?? string.Empty).Trim();
            }
            else if (metodo == MetodoPago.Mixto)
            {
                r.Efectivo = ParseDecimal(_txtMixEfectivo == null ? string.Empty : _txtMixEfectivo.Text);
                r.Credito = ParseDecimal(_txtMixCredito == null ? string.Empty : _txtMixCredito.Text);
                r.Transferencia = ParseDecimal(_txtMixTransferencia == null ? string.Empty : _txtMixTransferencia.Text);

                if (r.Efectivo < 0m || r.Credito < 0m || r.Transferencia < 0m)
                {
                    MessageBox.Show("Los montos no pueden ser negativos.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (r.PagadoTotal < _total)
                {
                    MessageBox.Show("La suma del pago no cubre el total.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (r.PagadoTotal > _total)
                {
                    MessageBox.Show("En mixto la suma no debe exceder el total.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }

            Result = r;
            DialogResult = DialogResult.OK;
            Close();
        }

        private static decimal ParseDecimal(string text)
        {
            string t = (text ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(t))
                return 0m;

            decimal v;
            if (decimal.TryParse(t, NumberStyles.Any, CultureInfo.CurrentCulture, out v))
                return v;
            if (decimal.TryParse(t, NumberStyles.Any, CultureInfo.InvariantCulture, out v))
                return v;
            return 0m;
        }
    }
}
