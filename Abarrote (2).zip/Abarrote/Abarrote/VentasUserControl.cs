using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace Abarrote
{
    public partial class VentasUserControl : UserControl
    {
        private int _idClienteAsignado;
        private string _nombreClienteAsignado;

        public VentasUserControl()
        {
            InitializeComponent();

            btnAgregarProducto.Click += btnAgregarProducto_Click;
            btnBorrarArt.Click += btnBorrarArt_Click;
            btnVarios.Click += btnVarios_Click;
            btnEntradas.Click += btnEntradas_Click;
            btnSalidas.Click += btnSalidas_Click;
            btnMayoreo.Click += btnMayoreo_Click;
            btnArtComun.Click += btnArtComun_Click;
            btnBuscar.Click += btnBuscar_Click;
            btnCobrar.Click += btnCobrar_Click;
            btnAsignarCliente.Click += btnAsignarCliente_Click;
            txtCodigoProducto.KeyDown += txtCodigoProducto_KeyDown;
            dgvProductos.KeyDown += dgvProductos_KeyDown;

            this.KeyDown += VentasUserControl_KeyDown;
            this.PreviewKeyDown += VentasUserControl_PreviewKeyDown;

            ActualizarResumenVenta();
            ActualizarClienteAsignadoUI();
        }

        private void btnAsignarCliente_Click(object sender, EventArgs e)
        {
            AbrirAsignarCliente();
        }

        private void AbrirAsignarCliente()
        {
            using (AssignClientForm f = new AssignClientForm())
            {
                if (f.ShowDialog(this) != DialogResult.OK)
                    return;

                if (f.Desasignar)
                {
                    _idClienteAsignado = 0;
                    _nombreClienteAsignado = string.Empty;
                }
                else
                {
                    _idClienteAsignado = f.IdClienteSeleccionado;
                    _nombreClienteAsignado = f.NombreClienteSeleccionado;
                }

                ActualizarClienteAsignadoUI();
            }
        }

        private void ActualizarClienteAsignadoUI()
        {
            if (btnAsignarCliente == null)
                return;

            if (_idClienteAsignado > 0)
            {
                string n = string.IsNullOrWhiteSpace(_nombreClienteAsignado) ? _idClienteAsignado.ToString() : _nombreClienteAsignado;
                btnAsignarCliente.Text = "Cliente: " + n;
                btnAsignarCliente.BackColor = Color.FromArgb(232, 245, 233);
            }
            else
            {
                btnAsignarCliente.Text = "Asignar cliente";
                btnAsignarCliente.BackColor = SystemColors.Control;
            }
        }

        private void VentasUserControl_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            if (e.KeyCode == Keys.F7 || e.KeyCode == Keys.F8 || e.KeyCode == Keys.F10 || e.KeyCode == Keys.F11 || e.KeyCode == Keys.F12)
                e.IsInputKey = true;
        }

        private void VentasUserControl_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.P)
            {
                e.SuppressKeyPress = true;
                AbrirProductoComun();
                return;
            }

            if (e.KeyCode == Keys.F7)
            {
                e.SuppressKeyPress = true;
                AbrirEntradaEfectivo();
                return;
            }

            if (e.KeyCode == Keys.F8)
            {
                e.SuppressKeyPress = true;
                AbrirSalidaEfectivo();
                return;
            }

            if (e.KeyCode == Keys.F10)
            {
                e.SuppressKeyPress = true;
                AbrirBusquedaProductos();
                return;
            }

            if (e.KeyCode == Keys.F12)
            {
                e.SuppressKeyPress = true;
                AbrirCobro();
                return;
            }

            if (e.KeyCode == Keys.F11)
            {
                e.SuppressKeyPress = true;
                AplicarPrecioMayoreoSeleccionado();
                return;
            }
        }

        private void txtCodigoProducto_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.P)
            {
                e.SuppressKeyPress = true;
                AbrirProductoComun();
                return;
            }

            if (e.KeyCode == Keys.F7)
            {
                e.SuppressKeyPress = true;
                AbrirEntradaEfectivo();
                return;
            }

            if (e.KeyCode == Keys.F8)
            {
                e.SuppressKeyPress = true;
                AbrirSalidaEfectivo();
                return;
            }

            if (e.KeyCode == Keys.F10)
            {
                e.SuppressKeyPress = true;
                AbrirBusquedaProductos();
                return;
            }

            if (e.KeyCode == Keys.F11)
            {
                e.SuppressKeyPress = true;
                AplicarPrecioMayoreoSeleccionado();
                return;
            }

            if (e.KeyCode == Keys.F12)
            {
                e.SuppressKeyPress = true;
                AbrirCobro();
                return;
            }

            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                AgregarProductoDesdeCodigo();
            }
        }

        private void btnAgregarProducto_Click(object sender, EventArgs e)
        {
            AgregarProductoDesdeCodigo();
        }

        private void btnCobrar_Click(object sender, EventArgs e)
        {
            AbrirCobro();
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            AbrirBusquedaProductos();
        }

        private void btnArtComun_Click(object sender, EventArgs e)
        {
            AbrirProductoComun();
        }

        private void AbrirProductoComun()
        {
            using (CommonProductForm f = new CommonProductForm())
            {
                if (f.ShowDialog(this) != DialogResult.OK)
                    return;

                string codigo = string.Format(CultureInfo.InvariantCulture, "COMUN-{0}", DateTime.UtcNow.Ticks);
                int cant = f.Cantidad <= 0 ? 1 : f.Cantidad;
                decimal precio = f.Precio;
                decimal importe = precio * cant;

                dgvProductos.Rows.Add(
                    codigo,
                    f.Descripcion,
                    precio.ToString("C2"),
                    cant,
                    importe.ToString("C2"),
                    0
                );

                ActualizarResumenVenta();
            }
        }

        private void AgregarProductoDesdeCodigo()
        {
            string codigo = txtCodigoProducto.Text == null ? string.Empty : txtCodigoProducto.Text.Trim();
            if (string.IsNullOrWhiteSpace(codigo))
                return;

            AgregarProductoPorCodigo(codigo);

            txtCodigoProducto.Clear();
            txtCodigoProducto.Focus();
        }

        private void AgregarProductoPorCodigo(string codigo)
        {
            if (string.IsNullOrWhiteSpace(codigo))
                return;

            ProductoVentaInfo info = DatabaseHelper.ObtenerProductoVentaPorCodigoBarras(codigo);
            if (info == null)
            {
                MessageBox.Show("Producto no encontrado.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int rowIndex = -1;
            for (int i = 0; i < dgvProductos.Rows.Count; i++)
            {
                object cellValue = dgvProductos.Rows[i].Cells["colCodigoBarras"].Value;
                if (cellValue != null && string.Equals(cellValue.ToString(), info.CodigoBarras, StringComparison.OrdinalIgnoreCase))
                {
                    rowIndex = i;
                    break;
                }
            }

            if (rowIndex >= 0)
            {
                int cantActual = 0;
                object cantValue = dgvProductos.Rows[rowIndex].Cells["colCantidad"].Value;
                if (cantValue != null)
                    int.TryParse(cantValue.ToString(), out cantActual);

                int nuevaCant = cantActual + 1;
                if (info.StockActual > 0 && nuevaCant > info.StockActual)
                {
                    MessageBox.Show(string.Format(CultureInfo.CurrentCulture, "Inventario insuficiente, hay {0} disponibles.", info.StockActual), "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtCodigoProducto.SelectAll();
                    txtCodigoProducto.Focus();
                    return;
                }
                dgvProductos.Rows[rowIndex].Cells["colCantidad"].Value = nuevaCant;

                decimal importe = info.PrecioVenta * nuevaCant;
                dgvProductos.Rows[rowIndex].Cells["colImporte"].Value = importe.ToString("C2");
            }
            else
            {
                int cant = 1;
                if (info.StockActual > 0 && cant > info.StockActual)
                {
                    MessageBox.Show(string.Format(CultureInfo.CurrentCulture, "Inventario insuficiente, hay {0} disponibles.", info.StockActual), "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtCodigoProducto.SelectAll();
                    txtCodigoProducto.Focus();
                    return;
                }
                decimal importe = info.PrecioVenta * cant;

                dgvProductos.Rows.Add(
                    info.CodigoBarras,
                    info.Descripcion,
                    info.PrecioVenta.ToString("C2"),
                    cant,
                    importe.ToString("C2"),
                    info.StockActual
                );
            }

            ActualizarResumenVenta();
        }

        private void AbrirBusquedaProductos()
        {
            using (ProductSearchForm f = new ProductSearchForm())
            {
                if (f.ShowDialog(this) != DialogResult.OK)
                    return;

                if (string.IsNullOrWhiteSpace(f.CodigoSeleccionado))
                    return;

                AgregarProductoPorCodigo(f.CodigoSeleccionado);
            }
        }

        private void AbrirCobro()
        {
            decimal total = 0m;
            if (lblTotalDisplay != null)
                total = ParseCurrency(lblTotalDisplay.Text);

            if (total <= 0m)
            {
                MessageBox.Show("No hay productos para cobrar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            using (CobrarForm f = new CobrarForm(total, _idClienteAsignado, _nombreClienteAsignado))
            {
                if (f.ShowDialog(this) != DialogResult.OK)
                    return;

                if (f.Result == null)
                    return;

                List<DatabaseHelper.VentaDetalleItem> detalle = new List<DatabaseHelper.VentaDetalleItem>();
                if (dgvProductos != null)
                {
                    foreach (DataGridViewRow row in dgvProductos.Rows)
                    {
                        if (row == null || row.IsNewRow)
                            continue;

                        string codigo = row.Cells["colCodigoBarras"].Value == null ? string.Empty : row.Cells["colCodigoBarras"].Value.ToString();
                        string desc = row.Cells["colDescripcion"].Value == null ? string.Empty : row.Cells["colDescripcion"].Value.ToString();

                        decimal precio = 0m;
                        if (row.Cells["colPrecioVenta"].Value != null)
                            precio = ParseCurrency(row.Cells["colPrecioVenta"].Value.ToString());

                        decimal cant = 0m;
                        if (row.Cells["colCantidad"].Value != null)
                        {
                            decimal.TryParse(row.Cells["colCantidad"].Value.ToString(), NumberStyles.Any, CultureInfo.CurrentCulture, out cant);
                            if (cant <= 0m)
                                decimal.TryParse(row.Cells["colCantidad"].Value.ToString(), NumberStyles.Any, CultureInfo.InvariantCulture, out cant);
                        }

                        if (string.IsNullOrWhiteSpace(codigo) || cant <= 0m)
                            continue;

                        DatabaseHelper.VentaDetalleItem it = new DatabaseHelper.VentaDetalleItem();
                        it.CodigoBarras = codigo;
                        it.Descripcion = desc;
                        it.Cantidad = cant;
                        it.PrecioVenta = precio;
                        detalle.Add(it);
                    }
                }

                int idVenta;
                string err;
                if (!DatabaseHelper.ProcesarVenta(total, _idClienteAsignado, detalle, out idVenta, out err))
                {
                    MessageBox.Show(string.Format(CultureInfo.CurrentCulture, "No se pudo registrar la venta: {0}", err), "Venta",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (lblPagoCon != null)
                    lblPagoCon.Text = string.Format(CultureInfo.CurrentCulture, "Pagó Con: {0}", f.Result.PagoConParaMostrar.ToString("C2"));

                if (lblCambio != null)
                    lblCambio.Text = string.Format(CultureInfo.CurrentCulture, "Cambio: {0}", f.Result.Cambio.ToString("C2"));

                if (f.Result.Efectivo > 0m)
                    CashBoxState.EfectivoEnCaja += f.Result.Efectivo - f.Result.Cambio;

                if (dgvProductos != null)
                    dgvProductos.Rows.Clear();

                _idClienteAsignado = 0;
                _nombreClienteAsignado = string.Empty;
                ActualizarClienteAsignadoUI();

                ActualizarResumenVenta();
                txtCodigoProducto.Focus();
            }
        }

        private void btnEntradas_Click(object sender, EventArgs e)
        {
            AbrirEntradaEfectivo();
        }

        private void btnSalidas_Click(object sender, EventArgs e)
        {
            AbrirSalidaEfectivo();
        }

        private void btnMayoreo_Click(object sender, EventArgs e)
        {
            AplicarPrecioMayoreoSeleccionado();
        }

        private void AplicarPrecioMayoreoSeleccionado()
        {
            if (dgvProductos == null || dgvProductos.SelectedRows == null || dgvProductos.SelectedRows.Count == 0)
            {
                MessageBox.Show("Selecciona un producto del ticket para aplicar mayoreo.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            DataGridViewRow row = dgvProductos.SelectedRows[0];
            if (row == null)
                return;

            object codValue = row.Cells["colCodigoBarras"].Value;
            string codigo = codValue == null ? string.Empty : codValue.ToString();
            if (string.IsNullOrWhiteSpace(codigo))
                return;

            ProductoVentaInfo info = DatabaseHelper.ObtenerProductoVentaPorCodigoBarras(codigo);
            if (info == null)
            {
                MessageBox.Show("Producto no encontrado.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            decimal precioMayoreo = info.PrecioMayoreo;
            if (precioMayoreo <= 0m)
            {
                MessageBox.Show("Este producto no tiene precio de mayoreo.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            int cant = 0;
            object cantValue = row.Cells["colCantidad"].Value;
            if (cantValue != null)
                int.TryParse(cantValue.ToString(), out cant);
            if (cant <= 0)
                cant = 1;

            row.Cells["colPrecioVenta"].Value = precioMayoreo.ToString("C2");
            decimal importe = precioMayoreo * cant;
            row.Cells["colImporte"].Value = importe.ToString("C2");

            ActualizarResumenVenta();
        }

        private void AbrirEntradaEfectivo()
        {
            using (CashEntryForm f = new CashEntryForm())
            {
                if (f.ShowDialog(this) != DialogResult.OK)
                    return;

                MessageBox.Show(
                    string.Format(CultureInfo.CurrentCulture, "Entrada registrada: {0}", f.Monto.ToString("C2")),
                    "Entrada de efectivo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
        }

        private void AbrirSalidaEfectivo()
        {
            using (CashExitForm f = new CashExitForm())
            {
                if (f.ShowDialog(this) != DialogResult.OK)
                    return;

                MessageBox.Show(
                    string.Format(CultureInfo.CurrentCulture, "Salida registrada: {0}", f.Monto.ToString("C2")),
                    "Salida de efectivo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
        }

        private void btnVarios_Click(object sender, EventArgs e)
        {
            string codigo = string.Empty;
            int cantidad = 0;
            if (!TryPedirVarios(out codigo, out cantidad))
                return;

            ProductoVentaInfo info = DatabaseHelper.ObtenerProductoVentaPorCodigoBarras(codigo);
            if (info == null)
            {
                MessageBox.Show("Producto no encontrado.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (cantidad <= 0)
                return;

            int rowIndex = -1;
            for (int i = 0; i < dgvProductos.Rows.Count; i++)
            {
                object cellValue = dgvProductos.Rows[i].Cells["colCodigoBarras"].Value;
                if (cellValue != null && string.Equals(cellValue.ToString(), info.CodigoBarras, StringComparison.OrdinalIgnoreCase))
                {
                    rowIndex = i;
                    break;
                }
            }

            int cantActual = 0;
            if (rowIndex >= 0)
            {
                object cantValue = dgvProductos.Rows[rowIndex].Cells["colCantidad"].Value;
                if (cantValue != null)
                    int.TryParse(cantValue.ToString(), out cantActual);
            }

            int nuevaCant = cantActual + cantidad;
            if (info.StockActual > 0 && nuevaCant > info.StockActual)
            {
                MessageBox.Show(string.Format(CultureInfo.CurrentCulture, "Inventario insuficiente, hay {0} disponibles.", info.StockActual), "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (rowIndex >= 0)
            {
                dgvProductos.Rows[rowIndex].Cells["colCantidad"].Value = nuevaCant;
                decimal importe = info.PrecioVenta * nuevaCant;
                dgvProductos.Rows[rowIndex].Cells["colImporte"].Value = importe.ToString("C2");
            }
            else
            {
                decimal importe = info.PrecioVenta * nuevaCant;
                dgvProductos.Rows.Add(
                    info.CodigoBarras,
                    info.Descripcion,
                    info.PrecioVenta.ToString("C2"),
                    nuevaCant,
                    importe.ToString("C2"),
                    info.StockActual
                );
            }

            ActualizarResumenVenta();
            txtCodigoProducto.Focus();
        }

        private static bool TryPedirVarios(out string codigo, out int cantidad)
        {
            codigo = string.Empty;
            cantidad = 0;

            using (Form f = new Form())
            {
                f.Text = "Varios Productos...";
                f.FormBorderStyle = FormBorderStyle.FixedDialog;
                f.StartPosition = FormStartPosition.CenterParent;
                f.MinimizeBox = false;
                f.MaximizeBox = false;
                f.ShowInTaskbar = false;
                f.ClientSize = new Size(420, 170);

                Label lblCodigo = new Label();
                lblCodigo.AutoSize = true;
                lblCodigo.Text = "Código del Producto:";
                lblCodigo.Location = new Point(12, 20);

                TextBox txtCodigo = new TextBox();
                txtCodigo.Location = new Point(12, 40);
                txtCodigo.Size = new Size(260, 23);

                Label lblCantidad = new Label();
                lblCantidad.AutoSize = true;
                lblCantidad.Text = "Cantidad:";
                lblCantidad.Location = new Point(12, 75);

                NumericUpDown nudCantidad = new NumericUpDown();
                nudCantidad.Location = new Point(12, 95);
                nudCantidad.Size = new Size(120, 23);
                nudCantidad.Minimum = 1;
                nudCantidad.Maximum = 100000;
                nudCantidad.DecimalPlaces = 0;
                nudCantidad.Value = 1;

                Button btnOk = new Button();
                btnOk.Text = "Aceptar";
                btnOk.DialogResult = DialogResult.OK;
                btnOk.Location = new Point(300, 40);
                btnOk.Size = new Size(90, 28);

                Button btnCancel = new Button();
                btnCancel.Text = "Cancelar";
                btnCancel.DialogResult = DialogResult.Cancel;
                btnCancel.Location = new Point(300, 75);
                btnCancel.Size = new Size(90, 28);

                f.Controls.Add(lblCodigo);
                f.Controls.Add(txtCodigo);
                f.Controls.Add(lblCantidad);
                f.Controls.Add(nudCantidad);
                f.Controls.Add(btnOk);
                f.Controls.Add(btnCancel);
                f.AcceptButton = btnOk;
                f.CancelButton = btnCancel;

                DialogResult r = f.ShowDialog();
                if (r != DialogResult.OK)
                    return false;

                string c = (txtCodigo.Text ?? string.Empty).Trim();
                if (string.IsNullOrWhiteSpace(c))
                {
                    MessageBox.Show("Captura un código de producto.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

                codigo = c;
                cantidad = (int)nudCantidad.Value;
                return true;
            }
        }

        private void btnBorrarArt_Click(object sender, EventArgs e)
        {
            QuitarProductoSeleccionado(true);
        }

        private void dgvProductos_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.P)
            {
                e.SuppressKeyPress = true;
                AbrirProductoComun();
                return;
            }

            if (e.KeyCode == Keys.F10)
            {
                e.SuppressKeyPress = true;
                AbrirBusquedaProductos();
                return;
            }

            if (e.KeyCode == Keys.F7)
            {
                e.SuppressKeyPress = true;
                AbrirEntradaEfectivo();
                return;
            }

            if (e.KeyCode == Keys.F8)
            {
                e.SuppressKeyPress = true;
                AbrirSalidaEfectivo();
                return;
            }

            if (e.KeyCode == Keys.F12)
            {
                e.SuppressKeyPress = true;
                AbrirCobro();
                return;
            }

            if (e.KeyCode != Keys.Delete)
                return;

            e.SuppressKeyPress = true;
            QuitarProductoSeleccionado(true);
        }

        private void QuitarProductoSeleccionado(bool confirmar)
        {
            if (dgvProductos == null || dgvProductos.SelectedRows == null || dgvProductos.SelectedRows.Count == 0)
            {
                MessageBox.Show("Selecciona un producto para quitar del ticket.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (confirmar && !ConfirmarQuitarProducto())
                return;

            DataGridViewRow row = dgvProductos.SelectedRows[0];
            if (row != null)
                dgvProductos.Rows.Remove(row);

            ActualizarResumenVenta();
        }

        private void ActualizarResumenVenta()
        {
            decimal total = 0m;
            int totalProductos = 0;

            if (dgvProductos != null)
            {
                foreach (DataGridViewRow row in dgvProductos.Rows)
                {
                    if (row == null || row.IsNewRow)
                        continue;

                    int cant = 0;
                    object cantValue = row.Cells["colCantidad"].Value;
                    if (cantValue != null)
                        int.TryParse(cantValue.ToString(), out cant);
                    if (cant > 0)
                        totalProductos += cant;

                    object importeValue = row.Cells["colImporte"].Value;
                    decimal importe = ParseCurrency(importeValue == null ? string.Empty : importeValue.ToString());
                    total += importe;
                }
            }

            if (lblTotal != null)
                lblTotal.Text = string.Format(CultureInfo.CurrentCulture, "Total: {0}", total.ToString("C2"));

            if (lblTotalDisplay != null)
                lblTotalDisplay.Text = total.ToString("C2");

            if (lblProductCount != null)
                lblProductCount.Text = string.Format(CultureInfo.CurrentCulture, "{0} Productos en la venta actual.", totalProductos);
        }

        private static decimal ParseCurrency(string value)
        {
            decimal d = 0m;
            if (string.IsNullOrWhiteSpace(value))
                return 0m;

            decimal.TryParse(value.Trim(), NumberStyles.Currency, CultureInfo.CurrentCulture, out d);
            return d;
        }

        private static bool ConfirmarQuitarProducto()
        {
            using (Form f = new Form())
            {
                f.Text = "Confirmar";
                f.FormBorderStyle = FormBorderStyle.FixedDialog;
                f.StartPosition = FormStartPosition.CenterParent;
                f.MinimizeBox = false;
                f.MaximizeBox = false;
                f.ShowInTaskbar = false;
                f.ClientSize = new Size(340, 140);

                Label lbl = new Label();
                lbl.AutoSize = false;
                lbl.Text = "¿Borrar producto seleccionado?";
                lbl.Location = new Point(20, 20);
                lbl.Size = new Size(300, 30);
                lbl.TextAlign = ContentAlignment.MiddleLeft;
                lbl.Font = new Font("Segoe UI", 9F, FontStyle.Regular);

                Button btnOk = new Button();
                btnOk.Text = "Borrar producto";
                btnOk.DialogResult = DialogResult.OK;
                btnOk.Location = new Point(80, 80);
                btnOk.Size = new Size(110, 28);

                Button btnCancel = new Button();
                btnCancel.Text = "Cancelar";
                btnCancel.DialogResult = DialogResult.Cancel;
                btnCancel.Location = new Point(200, 80);
                btnCancel.Size = new Size(80, 28);

                f.Controls.Add(lbl);
                f.Controls.Add(btnOk);
                f.Controls.Add(btnCancel);
                f.AcceptButton = btnOk;
                f.CancelButton = btnCancel;

                return f.ShowDialog() == DialogResult.OK;
            }
        }
    }
}
