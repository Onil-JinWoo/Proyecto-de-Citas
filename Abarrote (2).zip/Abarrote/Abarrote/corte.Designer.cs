﻿namespace Abarrote
{
    partial class corte
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.btnCorteCajero = new System.Windows.Forms.Button();
            this.btnCorteDia = new System.Windows.Forms.Button();
            this.panelEntradasEfectivo = new System.Windows.Forms.Panel();
            this.lblEntradasEfectivo = new System.Windows.Forms.Label();
            this.lblEntradasEfectivoValor = new System.Windows.Forms.Label();
            this.panelGanancia = new System.Windows.Forms.Panel();
            this.lblGanancia = new System.Windows.Forms.Label();
            this.lblGananciaValor = new System.Windows.Forms.Label();
            this.panelVentasDepartamento = new System.Windows.Forms.Panel();
            this.lblVentasDepartamento = new System.Windows.Forms.Label();
            this.lblVentasDepartamentoValor = new System.Windows.Forms.Label();
            this.panelImpuestos = new System.Windows.Forms.Panel();
            this.lblImpuestos = new System.Windows.Forms.Label();
            this.lblImpuestosValor = new System.Windows.Forms.Label();
            this.panelIngresosContado = new System.Windows.Forms.Panel();
            this.lblIngresosContado = new System.Windows.Forms.Label();
            this.lblIngresosContadoValor = new System.Windows.Forms.Label();
            this.panelSalidasEfectivo = new System.Windows.Forms.Panel();
            this.lblSalidasEfectivo = new System.Windows.Forms.Label();
            this.lblSalidasEfectivoValor = new System.Windows.Forms.Label();
            this.panelPagosCreditos = new System.Windows.Forms.Panel();
            this.lblPagosCreditos = new System.Windows.Forms.Label();
            this.lblPagosCreditosValor = new System.Windows.Forms.Label();
            this.panelClientesMasVentas = new System.Windows.Forms.Panel();
            this.lblClientesMasVentas = new System.Windows.Forms.Label();
            this.lblClientesMasVentasValor = new System.Windows.Forms.Label();
            this.panelClientesMasGanancia = new System.Windows.Forms.Panel();
            this.lblClientesMasGanancia = new System.Windows.Forms.Label();
            this.lblClientesMasGananciaValor = new System.Windows.Forms.Label();
            this.panelBotones = new System.Windows.Forms.Panel();
            this.panelContenido = new System.Windows.Forms.Panel();
            this.panelBotones.SuspendLayout();
            this.panelContenido.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.lblTitulo.Location = new System.Drawing.Point(20, 20);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(0, 37);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "CORTE";
            // 
            // panelBotones
            // 
            this.panelBotones.BackColor = System.Drawing.Color.White;
            this.panelBotones.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelBotones.Controls.Add(this.btnCorteCajero);
            this.panelBotones.Controls.Add(this.btnCorteDia);
            this.panelBotones.Controls.Add(this.lblTitulo);
            this.panelBotones.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelBotones.Location = new System.Drawing.Point(0, 0);
            this.panelBotones.Name = "panelBotones";
            this.panelBotones.Size = new System.Drawing.Size(1164, 100);
            this.panelBotones.TabIndex = 1;
            // 
            // btnCorteCajero
            // 
            this.btnCorteCajero.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnCorteCajero.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCorteCajero.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCorteCajero.ForeColor = System.Drawing.Color.White;
            this.btnCorteCajero.Location = new System.Drawing.Point(200, 40);
            this.btnCorteCajero.Name = "btnCorteCajero";
            this.btnCorteCajero.Size = new System.Drawing.Size(200, 40);
            this.btnCorteCajero.TabIndex = 1;
            this.btnCorteCajero.Text = "Hacer corte de cajero";
            this.btnCorteCajero.UseVisualStyleBackColor = false;
            // 
            // btnCorteDia
            // 
            this.btnCorteDia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.btnCorteDia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCorteDia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCorteDia.ForeColor = System.Drawing.Color.White;
            this.btnCorteDia.Location = new System.Drawing.Point(420, 40);
            this.btnCorteDia.Name = "btnCorteDia";
            this.btnCorteDia.Size = new System.Drawing.Size(200, 40);
            this.btnCorteDia.TabIndex = 2;
            this.btnCorteDia.Text = "Hacer corte del día";
            this.btnCorteDia.UseVisualStyleBackColor = false;
            // 
            // panelContenido
            // 
            this.panelContenido.AutoScroll = true;
            this.panelContenido.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.panelContenido.Controls.Add(this.panelEntradasEfectivo);
            this.panelContenido.Controls.Add(this.panelGanancia);
            this.panelContenido.Controls.Add(this.panelVentasDepartamento);
            this.panelContenido.Controls.Add(this.panelImpuestos);
            this.panelContenido.Controls.Add(this.panelIngresosContado);
            this.panelContenido.Controls.Add(this.panelSalidasEfectivo);
            this.panelContenido.Controls.Add(this.panelPagosCreditos);
            this.panelContenido.Controls.Add(this.panelClientesMasVentas);
            this.panelContenido.Controls.Add(this.panelClientesMasGanancia);
            this.panelContenido.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelContenido.Location = new System.Drawing.Point(0, 100);
            this.panelContenido.Name = "panelContenido";
            this.panelContenido.Padding = new System.Windows.Forms.Padding(20);
            this.panelContenido.Size = new System.Drawing.Size(1164, 471);
            this.panelContenido.TabIndex = 2;
            // 
            // panelEntradasEfectivo
            // 
            this.panelEntradasEfectivo.BackColor = System.Drawing.Color.White;
            this.panelEntradasEfectivo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelEntradasEfectivo.Controls.Add(this.lblEntradasEfectivoValor);
            this.panelEntradasEfectivo.Controls.Add(this.lblEntradasEfectivo);
            this.panelEntradasEfectivo.Location = new System.Drawing.Point(20, 20);
            this.panelEntradasEfectivo.Name = "panelEntradasEfectivo";
            this.panelEntradasEfectivo.Size = new System.Drawing.Size(550, 80);
            this.panelEntradasEfectivo.TabIndex = 0;
            // 
            // lblEntradasEfectivo
            // 
            this.lblEntradasEfectivo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEntradasEfectivo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.lblEntradasEfectivo.Location = new System.Drawing.Point(15, 10);
            this.lblEntradasEfectivo.Name = "lblEntradasEfectivo";
            this.lblEntradasEfectivo.Size = new System.Drawing.Size(200, 23);
            this.lblEntradasEfectivo.TabIndex = 0;
            this.lblEntradasEfectivo.Text = "Entradas de Efectivo";
            // 
            // lblEntradasEfectivoValor
            // 
            this.lblEntradasEfectivoValor.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEntradasEfectivoValor.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(100)))), ((int)(((byte)(100)))));
            this.lblEntradasEfectivoValor.Location = new System.Drawing.Point(15, 40);
            this.lblEntradasEfectivoValor.Name = "lblEntradasEfectivoValor";
            this.lblEntradasEfectivoValor.Size = new System.Drawing.Size(520, 23);
            this.lblEntradasEfectivoValor.TabIndex = 1;
            this.lblEntradasEfectivoValor.Text = "No hubo Entradas en Efectivo";
            // 
            // panelGanancia
            // 
            this.panelGanancia.BackColor = System.Drawing.Color.White;
            this.panelGanancia.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelGanancia.Controls.Add(this.lblGananciaValor);
            this.panelGanancia.Controls.Add(this.lblGanancia);
            this.panelGanancia.Location = new System.Drawing.Point(20, 380);
            this.panelGanancia.Name = "panelGanancia";
            this.panelGanancia.Size = new System.Drawing.Size(550, 80);
            this.panelGanancia.TabIndex = 8;
            // 
            // lblGanancia
            // 
            this.lblGanancia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGanancia.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.lblGanancia.Location = new System.Drawing.Point(15, 10);
            this.lblGanancia.Name = "lblGanancia";
            this.lblGanancia.Size = new System.Drawing.Size(200, 23);
            this.lblGanancia.TabIndex = 0;
            this.lblGanancia.Text = "Ganancia";
            // 
            // lblGananciaValor
            // 
            this.lblGananciaValor.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGananciaValor.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(100)))), ((int)(((byte)(100)))));
            this.lblGananciaValor.Location = new System.Drawing.Point(15, 40);
            this.lblGananciaValor.Name = "lblGananciaValor";
            this.lblGananciaValor.Size = new System.Drawing.Size(520, 23);
            this.lblGananciaValor.TabIndex = 1;
            this.lblGananciaValor.Text = "$0.00";
            // 
            // panelVentasDepartamento
            // 
            this.panelVentasDepartamento.BackColor = System.Drawing.Color.White;
            this.panelVentasDepartamento.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelVentasDepartamento.Controls.Add(this.lblVentasDepartamentoValor);
            this.panelVentasDepartamento.Controls.Add(this.lblVentasDepartamento);
            this.panelVentasDepartamento.Location = new System.Drawing.Point(590, 20);
            this.panelVentasDepartamento.Name = "panelVentasDepartamento";
            this.panelVentasDepartamento.Size = new System.Drawing.Size(550, 80);
            this.panelVentasDepartamento.TabIndex = 1;
            // 
            // lblVentasDepartamento
            // 
            this.lblVentasDepartamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVentasDepartamento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.lblVentasDepartamento.Location = new System.Drawing.Point(15, 10);
            this.lblVentasDepartamento.Name = "lblVentasDepartamento";
            this.lblVentasDepartamento.Size = new System.Drawing.Size(200, 23);
            this.lblVentasDepartamento.TabIndex = 0;
            this.lblVentasDepartamento.Text = "Ventas por Departamento";
            // 
            // lblVentasDepartamentoValor
            // 
            this.lblVentasDepartamentoValor.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVentasDepartamentoValor.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(100)))), ((int)(((byte)(100)))));
            this.lblVentasDepartamentoValor.Location = new System.Drawing.Point(15, 40);
            this.lblVentasDepartamentoValor.Name = "lblVentasDepartamentoValor";
            this.lblVentasDepartamentoValor.Size = new System.Drawing.Size(520, 23);
            this.lblVentasDepartamentoValor.TabIndex = 1;
            this.lblVentasDepartamentoValor.Text = "No se registró ninguna venta";
            // 
            // panelImpuestos
            // 
            this.panelImpuestos.BackColor = System.Drawing.Color.White;
            this.panelImpuestos.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelImpuestos.Controls.Add(this.lblImpuestosValor);
            this.panelImpuestos.Controls.Add(this.lblImpuestos);
            this.panelImpuestos.Location = new System.Drawing.Point(20, 110);
            this.panelImpuestos.Name = "panelImpuestos";
            this.panelImpuestos.Size = new System.Drawing.Size(550, 80);
            this.panelImpuestos.TabIndex = 2;
            // 
            // lblImpuestos
            // 
            this.lblImpuestos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblImpuestos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.lblImpuestos.Location = new System.Drawing.Point(15, 10);
            this.lblImpuestos.Name = "lblImpuestos";
            this.lblImpuestos.Size = new System.Drawing.Size(200, 23);
            this.lblImpuestos.TabIndex = 0;
            this.lblImpuestos.Text = "Impuestos";
            // 
            // lblImpuestosValor
            // 
            this.lblImpuestosValor.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblImpuestosValor.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(100)))), ((int)(((byte)(100)))));
            this.lblImpuestosValor.Location = new System.Drawing.Point(15, 40);
            this.lblImpuestosValor.Name = "lblImpuestosValor";
            this.lblImpuestosValor.Size = new System.Drawing.Size(520, 23);
            this.lblImpuestosValor.TabIndex = 1;
            this.lblImpuestosValor.Text = "No hubo ventas";
            // 
            // panelIngresosContado
            // 
            this.panelIngresosContado.BackColor = System.Drawing.Color.White;
            this.panelIngresosContado.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelIngresosContado.Controls.Add(this.lblIngresosContadoValor);
            this.panelIngresosContado.Controls.Add(this.lblIngresosContado);
            this.panelIngresosContado.Location = new System.Drawing.Point(590, 110);
            this.panelIngresosContado.Name = "panelIngresosContado";
            this.panelIngresosContado.Size = new System.Drawing.Size(550, 80);
            this.panelIngresosContado.TabIndex = 3;
            // 
            // lblIngresosContado
            // 
            this.lblIngresosContado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIngresosContado.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.lblIngresosContado.Location = new System.Drawing.Point(15, 10);
            this.lblIngresosContado.Name = "lblIngresosContado";
            this.lblIngresosContado.Size = new System.Drawing.Size(200, 23);
            this.lblIngresosContado.TabIndex = 0;
            this.lblIngresosContado.Text = "Ingresos de contado";
            // 
            // lblIngresosContadoValor
            // 
            this.lblIngresosContadoValor.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIngresosContadoValor.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(100)))), ((int)(((byte)(100)))));
            this.lblIngresosContadoValor.Location = new System.Drawing.Point(15, 40);
            this.lblIngresosContadoValor.Name = "lblIngresosContadoValor";
            this.lblIngresosContadoValor.Size = new System.Drawing.Size(520, 23);
            this.lblIngresosContadoValor.TabIndex = 1;
            this.lblIngresosContadoValor.Text = "No hubo ingresos de contado  $0.00";
            // 
            // panelSalidasEfectivo
            // 
            this.panelSalidasEfectivo.BackColor = System.Drawing.Color.White;
            this.panelSalidasEfectivo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelSalidasEfectivo.Controls.Add(this.lblSalidasEfectivoValor);
            this.panelSalidasEfectivo.Controls.Add(this.lblSalidasEfectivo);
            this.panelSalidasEfectivo.Location = new System.Drawing.Point(20, 200);
            this.panelSalidasEfectivo.Name = "panelSalidasEfectivo";
            this.panelSalidasEfectivo.Size = new System.Drawing.Size(550, 80);
            this.panelSalidasEfectivo.TabIndex = 4;
            // 
            // lblSalidasEfectivo
            // 
            this.lblSalidasEfectivo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalidasEfectivo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.lblSalidasEfectivo.Location = new System.Drawing.Point(15, 10);
            this.lblSalidasEfectivo.Name = "lblSalidasEfectivo";
            this.lblSalidasEfectivo.Size = new System.Drawing.Size(200, 23);
            this.lblSalidasEfectivo.TabIndex = 0;
            this.lblSalidasEfectivo.Text = "Salidas de Efectivo";
            // 
            // lblSalidasEfectivoValor
            // 
            this.lblSalidasEfectivoValor.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalidasEfectivoValor.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(100)))), ((int)(((byte)(100)))));
            this.lblSalidasEfectivoValor.Location = new System.Drawing.Point(15, 40);
            this.lblSalidasEfectivoValor.Name = "lblSalidasEfectivoValor";
            this.lblSalidasEfectivoValor.Size = new System.Drawing.Size(520, 23);
            this.lblSalidasEfectivoValor.TabIndex = 1;
            this.lblSalidasEfectivoValor.Text = "No hubo Salidas en Efectivo";
            // 
            // panelPagosCreditos
            // 
            this.panelPagosCreditos.BackColor = System.Drawing.Color.White;
            this.panelPagosCreditos.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelPagosCreditos.Controls.Add(this.lblPagosCreditosValor);
            this.panelPagosCreditos.Controls.Add(this.lblPagosCreditos);
            this.panelPagosCreditos.Location = new System.Drawing.Point(590, 200);
            this.panelPagosCreditos.Name = "panelPagosCreditos";
            this.panelPagosCreditos.Size = new System.Drawing.Size(550, 80);
            this.panelPagosCreditos.TabIndex = 5;
            // 
            // lblPagosCreditos
            // 
            this.lblPagosCreditos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPagosCreditos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.lblPagosCreditos.Location = new System.Drawing.Point(15, 10);
            this.lblPagosCreditos.Name = "lblPagosCreditos";
            this.lblPagosCreditos.Size = new System.Drawing.Size(200, 23);
            this.lblPagosCreditos.TabIndex = 0;
            this.lblPagosCreditos.Text = "Pagos de Créditos";
            // 
            // lblPagosCreditosValor
            // 
            this.lblPagosCreditosValor.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPagosCreditosValor.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(100)))), ((int)(((byte)(100)))));
            this.lblPagosCreditosValor.Location = new System.Drawing.Point(15, 40);
            this.lblPagosCreditosValor.Name = "lblPagosCreditosValor";
            this.lblPagosCreditosValor.Size = new System.Drawing.Size(520, 23);
            this.lblPagosCreditosValor.TabIndex = 1;
            this.lblPagosCreditosValor.Text = "No se recibieron pagos de créditos";
            // 
            // panelClientesMasVentas
            // 
            this.panelClientesMasVentas.BackColor = System.Drawing.Color.White;
            this.panelClientesMasVentas.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelClientesMasVentas.Controls.Add(this.lblClientesMasVentasValor);
            this.panelClientesMasVentas.Controls.Add(this.lblClientesMasVentas);
            this.panelClientesMasVentas.Location = new System.Drawing.Point(20, 290);
            this.panelClientesMasVentas.Name = "panelClientesMasVentas";
            this.panelClientesMasVentas.Size = new System.Drawing.Size(550, 80);
            this.panelClientesMasVentas.TabIndex = 6;
            // 
            // lblClientesMasVentas
            // 
            this.lblClientesMasVentas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClientesMasVentas.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.lblClientesMasVentas.Location = new System.Drawing.Point(15, 10);
            this.lblClientesMasVentas.Name = "lblClientesMasVentas";
            this.lblClientesMasVentas.Size = new System.Drawing.Size(200, 23);
            this.lblClientesMasVentas.TabIndex = 0;
            this.lblClientesMasVentas.Text = "Clientes con más ventas";
            // 
            // lblClientesMasVentasValor
            // 
            this.lblClientesMasVentasValor.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClientesMasVentasValor.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(100)))), ((int)(((byte)(100)))));
            this.lblClientesMasVentasValor.Location = new System.Drawing.Point(15, 40);
            this.lblClientesMasVentasValor.Name = "lblClientesMasVentasValor";
            this.lblClientesMasVentasValor.Size = new System.Drawing.Size(520, 23);
            this.lblClientesMasVentasValor.TabIndex = 1;
            this.lblClientesMasVentasValor.Text = "No hubo ventas";
            // 
            // panelClientesMasGanancia
            // 
            this.panelClientesMasGanancia.BackColor = System.Drawing.Color.White;
            this.panelClientesMasGanancia.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelClientesMasGanancia.Controls.Add(this.lblClientesMasGananciaValor);
            this.panelClientesMasGanancia.Controls.Add(this.lblClientesMasGanancia);
            this.panelClientesMasGanancia.Location = new System.Drawing.Point(590, 290);
            this.panelClientesMasGanancia.Name = "panelClientesMasGanancia";
            this.panelClientesMasGanancia.Size = new System.Drawing.Size(550, 80);
            this.panelClientesMasGanancia.TabIndex = 7;
            // 
            // lblClientesMasGanancia
            // 
            this.lblClientesMasGanancia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClientesMasGanancia.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.lblClientesMasGanancia.Location = new System.Drawing.Point(15, 10);
            this.lblClientesMasGanancia.Name = "lblClientesMasGanancia";
            this.lblClientesMasGanancia.Size = new System.Drawing.Size(200, 23);
            this.lblClientesMasGanancia.TabIndex = 0;
            this.lblClientesMasGanancia.Text = "Clientes con más ganancia";
            // 
            // lblClientesMasGananciaValor
            // 
            this.lblClientesMasGananciaValor.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClientesMasGananciaValor.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(100)))), ((int)(((byte)(100)))));
            this.lblClientesMasGananciaValor.Location = new System.Drawing.Point(15, 40);
            this.lblClientesMasGananciaValor.Name = "lblClientesMasGananciaValor";
            this.lblClientesMasGananciaValor.Size = new System.Drawing.Size(520, 23);
            this.lblClientesMasGananciaValor.TabIndex = 1;
            this.lblClientesMasGananciaValor.Text = "No hubo ventas";
            // 
            // corte
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.Controls.Add(this.panelContenido);
            this.Controls.Add(this.panelBotones);
            this.Name = "corte";
            this.Size = new System.Drawing.Size(1164, 571);
            this.panelBotones.ResumeLayout(false);
            this.panelContenido.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Button btnCorteCajero;
        private System.Windows.Forms.Button btnCorteDia;
        private System.Windows.Forms.Panel panelBotones;
        private System.Windows.Forms.Panel panelContenido;
        private System.Windows.Forms.Panel panelEntradasEfectivo;
        private System.Windows.Forms.Label lblEntradasEfectivo;
        private System.Windows.Forms.Label lblEntradasEfectivoValor;
        private System.Windows.Forms.Panel panelGanancia;
        private System.Windows.Forms.Label lblGanancia;
        private System.Windows.Forms.Label lblGananciaValor;
        private System.Windows.Forms.Panel panelVentasDepartamento;
        private System.Windows.Forms.Label lblVentasDepartamento;
        private System.Windows.Forms.Label lblVentasDepartamentoValor;
        private System.Windows.Forms.Panel panelImpuestos;
        private System.Windows.Forms.Label lblImpuestos;
        private System.Windows.Forms.Label lblImpuestosValor;
        private System.Windows.Forms.Panel panelIngresosContado;
        private System.Windows.Forms.Label lblIngresosContado;
        private System.Windows.Forms.Label lblIngresosContadoValor;
        private System.Windows.Forms.Panel panelSalidasEfectivo;
        private System.Windows.Forms.Label lblSalidasEfectivo;
        private System.Windows.Forms.Label lblSalidasEfectivoValor;
        private System.Windows.Forms.Panel panelPagosCreditos;
        private System.Windows.Forms.Label lblPagosCreditos;
        private System.Windows.Forms.Label lblPagosCreditosValor;
        private System.Windows.Forms.Panel panelClientesMasVentas;
        private System.Windows.Forms.Label lblClientesMasVentas;
        private System.Windows.Forms.Label lblClientesMasVentasValor;
        private System.Windows.Forms.Panel panelClientesMasGanancia;
        private System.Windows.Forms.Label lblClientesMasGanancia;
        private System.Windows.Forms.Label lblClientesMasGananciaValor;
    }
}