using System;
using System.Drawing;
using System.Windows.Forms;

namespace Abarrote
{
    public partial class Form1 : Form
    {
        private Button _activeMenuButton;
        private System.Windows.Forms.Timer _dateTimeTimer;
        private VentasUserControl _ventasView;
        private productos _productosView;
        private ClientesUserControl _clientesView;
        private InventarioUserControl _inventarioView;
        private factura _facturasView;
        private credito _creditoView;
        private corte _corteView;
        private ReportesUserControl _reportesView;
        private ConfiguracionUserControl _configuracionView;

        public Form1()
        {
            InitializeComponent();

            if (lblUser != null)
                lblUser.Text = string.Format("Le atiende: {0}", UserSessionState.NombreParaMostrar);

            AplicarDisenoMenuPrincipal();
            AplicarPermisosMenu();

            this.StartPosition = FormStartPosition.CenterScreen;
            this.WindowState = FormWindowState.Maximized;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Resize += Form1_Resize;

            CargarVistas();
            InicializarTimerFechaHora();
            MostrarVista(DeterminarVistaInicial());
        }

        private Vista DeterminarVistaInicial()
        {
            if (UserSessionState.EsAdmin)
                return Vista.Ventas;

            if (UserSessionState.PermisoVentas)
                return Vista.Ventas;

            if (UserSessionState.PermisoAgregarProductos)
                return Vista.Productos;

            return Vista.Ventas;
        }

        private void AplicarPermisosMenu()
        {
            if (UserSessionState.EsAdmin)
            {
                if (btnVentas != null) { btnVentas.Visible = true; btnVentas.Enabled = true; }
                if (btnProductos != null) { btnProductos.Visible = true; btnProductos.Enabled = true; }
                if (btnClientes != null) { btnClientes.Visible = true; btnClientes.Enabled = true; }
                if (btnInventario != null) { btnInventario.Visible = true; btnInventario.Enabled = true; }
                if (btnFacturas != null) { btnFacturas.Visible = true; btnFacturas.Enabled = true; }
                if (btnCreditos != null) { btnCreditos.Visible = true; btnCreditos.Enabled = true; }
                if (btnCorte != null) { btnCorte.Visible = true; btnCorte.Enabled = true; }
                if (btnReportes != null) { btnReportes.Visible = true; btnReportes.Enabled = true; }
                if (btnConfiguracion != null) { btnConfiguracion.Visible = true; btnConfiguracion.Enabled = true; }
                if (btnCompras != null) { btnCompras.Visible = true; btnCompras.Enabled = true; }
            }
            else
            {
                if (btnVentas != null) { btnVentas.Visible = true; btnVentas.Enabled = UserSessionState.PermisoVentas; }
                if (btnProductos != null) { btnProductos.Visible = true; btnProductos.Enabled = UserSessionState.PermisoAgregarProductos; }

                if (btnClientes != null) { btnClientes.Visible = true; btnClientes.Enabled = false; }
                if (btnInventario != null) { btnInventario.Visible = true; btnInventario.Enabled = false; }
                if (btnFacturas != null) { btnFacturas.Visible = true; btnFacturas.Enabled = false; }
                if (btnCreditos != null) { btnCreditos.Visible = true; btnCreditos.Enabled = false; }
                if (btnCorte != null) { btnCorte.Visible = true; btnCorte.Enabled = false; }
                if (btnReportes != null) { btnReportes.Visible = true; btnReportes.Enabled = false; }
                if (btnConfiguracion != null) { btnConfiguracion.Visible = true; btnConfiguracion.Enabled = false; }
                if (btnCompras != null) { btnCompras.Visible = true; btnCompras.Enabled = false; }
            }

            RelayoutMenuButtons();
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            if (this.WindowState != FormWindowState.Maximized)
                this.WindowState = FormWindowState.Maximized;
        }

        private void CargarVistas()
        {
            _ventasView = new VentasUserControl { Dock = DockStyle.Fill, Visible = false };
            _productosView = new productos();
            _productosView.TopLevel = false;
            _productosView.FormBorderStyle = FormBorderStyle.None;
            _productosView.Dock = DockStyle.Fill;
            _productosView.Visible = false;
            _productosView.Show();
            _clientesView = new ClientesUserControl { Dock = DockStyle.Fill, Visible = false };
            _inventarioView = new InventarioUserControl { Dock = DockStyle.Fill, Visible = false };
            _facturasView = new factura { Dock = DockStyle.Fill, Visible = false };
            _creditoView = new credito { Dock = DockStyle.Fill, Visible = false };
            _corteView = new corte { Dock = DockStyle.Fill, Visible = false };
            _reportesView = new ReportesUserControl { Dock = DockStyle.Fill, Visible = false };
            _configuracionView = new ConfiguracionUserControl { Dock = DockStyle.Fill, Visible = false };

            pnlMainContent.Controls.Add(_ventasView);
            pnlMainContent.Controls.Add(_productosView);
            pnlMainContent.Controls.Add(_clientesView);
            pnlMainContent.Controls.Add(_inventarioView);
            pnlMainContent.Controls.Add(_facturasView);
            pnlMainContent.Controls.Add(_creditoView);
            pnlMainContent.Controls.Add(_corteView);
            pnlMainContent.Controls.Add(_reportesView);
            pnlMainContent.Controls.Add(_configuracionView);
        }

        private void InicializarTimerFechaHora()
        {
            _dateTimeTimer = new System.Windows.Forms.Timer();
            _dateTimeTimer.Interval = 1000;
            _dateTimeTimer.Tick += (s, e) => ActualizarFechaHora();
            _dateTimeTimer.Start();
            ActualizarFechaHora();
        }

        private void ActualizarFechaHora()
        {
            lblStatusDateTime.Text = DateTime.Now.ToString("dd - MMM  h:mm tt",
                new System.Globalization.CultureInfo("es-MX"));
        }

        private enum Vista { Ventas, Productos, Clientes, Inventario, Facturas, Creditos, Corte, Reportes, Configuracion }

        private void MostrarVista(Vista vista)
        {
            if (_ventasView != null) _ventasView.Visible = vista == Vista.Ventas;
            if (_productosView != null) _productosView.Visible = vista == Vista.Productos;
            if (_clientesView != null) _clientesView.Visible = vista == Vista.Clientes;
            if (_inventarioView != null) _inventarioView.Visible = vista == Vista.Inventario;
            if (_facturasView != null) _facturasView.Visible = vista == Vista.Facturas;
            if (_creditoView != null) _creditoView.Visible = vista == Vista.Creditos;
            if (_corteView != null) _corteView.Visible = vista == Vista.Corte;
            if (_reportesView != null) _reportesView.Visible = vista == Vista.Reportes;
            if (_configuracionView != null) _configuracionView.Visible = vista == Vista.Configuracion;

            // Traer al frente la vista activa
            if (vista == Vista.Ventas && _ventasView != null) _ventasView.BringToFront();
            if (vista == Vista.Productos && _productosView != null) _productosView.BringToFront();
            if (vista == Vista.Clientes && _clientesView != null) _clientesView.BringToFront();
            if (vista == Vista.Inventario && _inventarioView != null) _inventarioView.BringToFront();
            if (vista == Vista.Facturas && _facturasView != null) _facturasView.BringToFront();
            if (vista == Vista.Creditos && _creditoView != null) _creditoView.BringToFront();
            if (vista == Vista.Corte && _corteView != null) _corteView.BringToFront();
            if (vista == Vista.Reportes && _reportesView != null) _reportesView.BringToFront();
            if (vista == Vista.Configuracion && _configuracionView != null) _configuracionView.BringToFront();

            if (vista == Vista.Ventas) SetActiveMenuButton(btnVentas);
            if (vista == Vista.Creditos) SetActiveMenuButton(btnCreditos);
            if (vista == Vista.Clientes) SetActiveMenuButton(btnClientes);
            if (vista == Vista.Productos) SetActiveMenuButton(btnProductos);
            if (vista == Vista.Inventario) SetActiveMenuButton(btnInventario);
            if (vista == Vista.Facturas) SetActiveMenuButton(btnFacturas);
            if (vista == Vista.Corte) SetActiveMenuButton(btnCorte);
            if (vista == Vista.Reportes) SetActiveMenuButton(btnReportes);
            if (vista == Vista.Configuracion) SetActiveMenuButton(btnConfiguracion);
        }

        private void AplicarDisenoMenuPrincipal()
        {
            if (pnlMenuBar != null)
            {
                pnlMenuBar.Height = 42;
                pnlMenuBar.BackColor = Color.FromArgb(240, 240, 240);
                pnlMenuBar.Padding = new Padding(6, 6, 6, 6);
                pnlMenuBar.Resize -= PnlMenuBar_Resize;
                pnlMenuBar.Resize += PnlMenuBar_Resize;
            }

            EstilizarBotonMenu(btnVentas, "F1 Ventas", SystemIcons.Application.ToBitmap());
            EstilizarBotonMenu(btnCreditos, "F2 Créditos", SystemIcons.Shield.ToBitmap());
            EstilizarBotonMenu(btnClientes, "Clientes", SystemIcons.Information.ToBitmap());
            EstilizarBotonMenu(btnProductos, "F3 Productos", SystemIcons.Asterisk.ToBitmap());
            EstilizarBotonMenu(btnInventario, "F4 Inventario", SystemIcons.Warning.ToBitmap());
            EstilizarBotonMenu(btnCompras, "Compras", SystemIcons.Question.ToBitmap());
            EstilizarBotonMenu(btnConfiguracion, "Configuración", SystemIcons.WinLogo.ToBitmap());
            EstilizarBotonMenu(btnFacturas, "Facturas", SystemIcons.Application.ToBitmap());
            EstilizarBotonMenu(btnCorte, "Corte", SystemIcons.Error.ToBitmap());
            EstilizarBotonMenu(btnReportes, "Reportes", SystemIcons.Application.ToBitmap());
            EstilizarBotonMenu(btnSalir, "Salir", SystemIcons.Hand.ToBitmap());

            RelayoutMenuButtons();

            SetActiveMenuButton(btnVentas);
        }

        private void PnlMenuBar_Resize(object sender, EventArgs e)
        {
            RelayoutMenuButtons();
        }

        private void RelayoutMenuButtons()
        {
            if (pnlMenuBar == null)
                return;

            int x = pnlMenuBar.Padding.Left;
            int y = pnlMenuBar.Padding.Top;
            int h = 32;
            int gap = 6;

            Button[] leftButtons = new Button[]
            {
                btnVentas,
                btnCreditos,
                btnClientes,
                btnProductos,
                btnInventario,
                btnCompras,
                btnConfiguracion,
                btnFacturas,
                btnCorte,
                btnReportes
            };

            for (int i = 0; i < leftButtons.Length; i++)
            {
                Button b = leftButtons[i];
                if (b == null)
                    continue;

                if (!b.Visible)
                    continue;

                b.Height = h;
                b.AutoSize = false;

                int w = MedirAnchoBotonMenu(b);
                b.Width = w;
                b.Location = new Point(x, y);

                x += w + gap;
            }

            if (btnSalir != null)
            {
                btnSalir.Height = h;
                btnSalir.AutoSize = false;
                btnSalir.Width = MedirAnchoBotonMenu(btnSalir);

                int rightX = pnlMenuBar.Width - pnlMenuBar.Padding.Right - btnSalir.Width;
                if (rightX < x + gap)
                    rightX = x + gap;

                btnSalir.Location = new Point(rightX, y);
                btnSalir.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            }
        }

        private static int MedirAnchoBotonMenu(Button b)
        {
            if (b == null)
                return 90;

            Size textSize = TextRenderer.MeasureText(b.Text ?? string.Empty, b.Font);
            int iconW = b.Image == null ? 0 : b.Image.Width;

            int paddingW = b.Padding.Left + b.Padding.Right;
            int internalGap = b.Image == null ? 12 : 18;

            int w = paddingW + iconW + internalGap + textSize.Width;
            if (w < 90) w = 90;
            if (w > 220) w = 220;
            return w;
        }

        private static void EstilizarBotonMenu(Button b, string text, Bitmap icon)
        {
            if (b == null)
                return;

            b.Text = text;
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderSize = 1;
            b.FlatAppearance.BorderColor = Color.FromArgb(210, 210, 210);
            b.BackColor = Color.White;
            b.ForeColor = Color.FromArgb(40, 40, 40);
            b.Font = new Font("Segoe UI", 9F, FontStyle.Regular);
            b.TextImageRelation = TextImageRelation.ImageBeforeText;
            b.ImageAlign = ContentAlignment.MiddleLeft;
            b.TextAlign = ContentAlignment.MiddleCenter;
            b.Padding = new Padding(8, 0, 8, 0);
            b.Height = 32;
            if (b.Width < 90) b.Width = 90;

            if (icon != null)
                b.Image = new Bitmap(icon, new Size(16, 16));

            b.FlatAppearance.MouseOverBackColor = Color.FromArgb(232, 242, 255);
            b.FlatAppearance.MouseDownBackColor = Color.FromArgb(210, 232, 255);
        }

        private void SetActiveMenuButton(Button b)
        {
            if (_activeMenuButton != null)
            {
                _activeMenuButton.BackColor = Color.White;
                _activeMenuButton.ForeColor = Color.FromArgb(40, 40, 40);
                _activeMenuButton.FlatAppearance.BorderColor = Color.FromArgb(210, 210, 210);
            }

            _activeMenuButton = b;
            if (_activeMenuButton != null)
            {
                _activeMenuButton.BackColor = Color.FromArgb(0, 86, 255);
                _activeMenuButton.ForeColor = Color.White;
                _activeMenuButton.FlatAppearance.BorderColor = Color.FromArgb(0, 86, 255);
            }
        }

        private void btnVentas_Click(object sender, EventArgs e)
        {
            MostrarVista(Vista.Ventas);
        }

        private void btnProductos_Click(object sender, EventArgs e)
        {
            MostrarVista(Vista.Productos);
        }

        public void MostrarProductos()
        {
            MostrarVista(Vista.Productos);
        }

        public void MostrarFormularioEnPanel(Form form)
        {
            if (form == null)
                return;

            form.TopLevel = false;
            form.Dock = DockStyle.Fill;
            form.FormBorderStyle = FormBorderStyle.None;

            // No limpiar el panel para no perder las vistas existentes.
            for (int i = 0; i < pnlMainContent.Controls.Count; i++)
                pnlMainContent.Controls[i].Visible = false;

            if (!pnlMainContent.Controls.Contains(form))
                pnlMainContent.Controls.Add(form);

            form.Visible = true;
            form.BringToFront();
            form.Show();
        }

        private void btnClientes_Click(object sender, EventArgs e)
        {
            MostrarVista(Vista.Clientes);
        }

        private void btnInventario_Click(object sender, EventArgs e)
        {
            MostrarVista(Vista.Inventario);
        }

        private void btnFacturas_Click(object sender, EventArgs e)
        {
            MostrarVista(Vista.Facturas);
        }

        private void btnCreditos_Click(object sender, EventArgs e)
        {
            MostrarVista(Vista.Creditos);
        }

        private void btnCorte_Click(object sender, EventArgs e)
        {
            MostrarVista(Vista.Corte);
        }

        private void btnReportes_Click(object sender, EventArgs e)
        {
            MostrarVista(Vista.Reportes);
        }

        private void btnConfiguracion_Click(object sender, EventArgs e)
        {
            MostrarVista(Vista.Configuracion);
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Desea salir de la aplicación?", "Salir",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}
