using System;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace Abarrote
{
    public class EstadoCuentaClienteForm : Form
    {
        private readonly int _idCliente;
        private readonly string _nombreCliente;

        private Label _lblNombre;
        private Label _lblSaldo;
        private DataGridView _dgv;
        private Button _btnCerrar;

        public EstadoCuentaClienteForm(int idCliente, string nombreCliente)
        {
            _idCliente = idCliente;
            _nombreCliente = nombreCliente;

            InitializeUi();
            Shown += (s, e) => Cargar();
        }

        private void InitializeUi()
        {
            Text = "Estado de Cuenta";
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.Sizable;
            MinimizeBox = false;
            MaximizeBox = true;
            ShowInTaskbar = false;
            ClientSize = new Size(860, 520);

            Panel pnlTop = new Panel();
            pnlTop.Dock = DockStyle.Top;
            pnlTop.Height = 80;
            pnlTop.Padding = new Padding(12, 10, 12, 10);
            pnlTop.BackColor = Color.White;

            _lblNombre = new Label();
            _lblNombre.Dock = DockStyle.Left;
            _lblNombre.Width = 560;
            _lblNombre.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            _lblNombre.TextAlign = ContentAlignment.MiddleLeft;
            _lblNombre.Text = string.IsNullOrWhiteSpace(_nombreCliente) ? ("Cliente #" + _idCliente.ToString(CultureInfo.InvariantCulture)) : _nombreCliente;

            _lblSaldo = new Label();
            _lblSaldo.Dock = DockStyle.Fill;
            _lblSaldo.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            _lblSaldo.ForeColor = Color.FromArgb(0, 150, 0);
            _lblSaldo.TextAlign = ContentAlignment.MiddleRight;
            _lblSaldo.Text = "$0.00";

            pnlTop.Controls.Add(_lblSaldo);
            pnlTop.Controls.Add(_lblNombre);

            _dgv = new DataGridView();
            _dgv.Dock = DockStyle.Fill;
            _dgv.AllowUserToAddRows = false;
            _dgv.AllowUserToDeleteRows = false;
            _dgv.ReadOnly = true;
            _dgv.RowHeadersVisible = false;
            _dgv.MultiSelect = false;
            _dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            _dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            Panel pnlBottom = new Panel();
            pnlBottom.Dock = DockStyle.Bottom;
            pnlBottom.Height = 55;

            _btnCerrar = new Button();
            _btnCerrar.Text = "Cerrar";
            _btnCerrar.Size = new Size(110, 32);
            _btnCerrar.Location = new Point(ClientSize.Width - 130, 12);
            _btnCerrar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            _btnCerrar.Click += (s, e) => { DialogResult = DialogResult.OK; Close(); };

            pnlBottom.Controls.Add(_btnCerrar);

            Controls.Add(_dgv);
            Controls.Add(pnlBottom);
            Controls.Add(pnlTop);

            KeyPreview = true;
            KeyDown += (s, e) =>
            {
                if (e.KeyCode == Keys.Escape)
                {
                    e.SuppressKeyPress = true;
                    DialogResult = DialogResult.OK;
                    Close();
                }
            };
        }

        private void Cargar()
        {
            if (_idCliente <= 0)
                return;

            DataTable dt = DatabaseHelper.ObtenerEstadoCuentaCliente(_idCliente, false);
            _dgv.DataSource = dt;

            if (_dgv.Columns.Contains("Monto"))
            {
                _dgv.Columns["Monto"].DefaultCellStyle.Format = "C2";
                _dgv.Columns["Monto"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            }

            decimal saldo = 0m;
            if (dt != null && dt.Columns.Contains("Monto"))
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    object v = dt.Rows[i]["Monto"];
                    if (v != null && v != DBNull.Value)
                        saldo += Convert.ToDecimal(v);
                }
            }

            _lblSaldo.Text = saldo.ToString("C2", CultureInfo.CurrentCulture);
        }
    }
}
