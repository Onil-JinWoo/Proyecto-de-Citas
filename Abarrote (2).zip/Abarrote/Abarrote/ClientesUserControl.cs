using System;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Abarrote
{
    public partial class ClientesUserControl : UserControl
    {
        private int _idClienteActual;
        private ImageList _imgClientes;
        private bool _cargadoInicial;

        public ClientesUserControl()
        {
            InitializeComponent();

            if (btnNuevoCliente != null)
                btnNuevoCliente.Click += btnNuevoCliente_Click;
            if (btnGuardar != null)
                btnGuardar.Click += btnGuardar_Click;
            if (btnEliminar != null)
                btnEliminar.Click += btnEliminar_Click;
            if (chkTieneCredito != null)
                chkTieneCredito.CheckedChanged += chkTieneCredito_CheckedChanged;
            if (cboLimiteCreditoTipo != null)
                cboLimiteCreditoTipo.SelectedIndexChanged += cboLimiteCreditoTipo_SelectedIndexChanged;
            if (txtBuscar != null)
                txtBuscar.TextChanged += txtBuscar_TextChanged;
            if (lstClientes != null)
                lstClientes.SelectedIndexChanged += lstClientes_SelectedIndexChanged;
            if (lstClientes != null)
                lstClientes.DoubleClick += lstClientes_DoubleClick;
            if (txtNombres != null)
                txtNombres.TextChanged += txtNombres_TextChanged;
            if (txtApellidos != null)
                txtApellidos.TextChanged += txtApellidos_TextChanged;

            this.Load += ClientesUserControl_Load;

            LimpiarFormulario();
            CargarListado();
        }

        private void ClientesUserControl_Load(object sender, EventArgs e)
        {
            if (_cargadoInicial)
                return;

            _cargadoInicial = true;
            // Asegura que el control ya esté creado/pintado antes de cargar datos
            if (this.IsHandleCreated)
                this.BeginInvoke(new MethodInvoker(RefrescarListadoCompleto));
            else
                RefrescarListadoCompleto();
        }

        protected override void OnVisibleChanged(EventArgs e)
        {
            base.OnVisibleChanged(e);
            if (this.Visible)
            {
                if (this.IsHandleCreated)
                    this.BeginInvoke(new MethodInvoker(RefrescarListadoCompleto));
                else
                    RefrescarListadoCompleto();
            }
        }

        private void RefrescarListadoCompleto()
        {
            if (txtBuscar != null && !string.IsNullOrWhiteSpace(txtBuscar.Text))
                txtBuscar.Text = string.Empty;

            CargarListado(true);
        }

        private void PrepararImageListClientes()
        {
            if (lstClientes == null)
                return;

            if (_imgClientes != null)
            {
                lstClientes.SmallImageList = null;
                _imgClientes.Dispose();
                _imgClientes = null;
            }

            _imgClientes = new ImageList();
            _imgClientes.ColorDepth = ColorDepth.Depth32Bit;
            _imgClientes.ImageSize = new Size(36, 36);
            _imgClientes.TransparentColor = Color.Transparent;
            lstClientes.SmallImageList = _imgClientes;

            // Asegura que se vean las imágenes en modo Details
            lstClientes.HideSelection = false;
        }

        private static string ObtenerInicialesDesdeNombreCompleto(string nombreCompleto)
        {
            if (string.IsNullOrWhiteSpace(nombreCompleto))
                return "";

            string[] parts = nombreCompleto.Trim().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length == 0)
                return "";
            if (parts.Length == 1)
                return ObtenerIniciales(parts[0], string.Empty);

            string nombre = parts[0];
            string apellido = parts[parts.Length - 1];
            return ObtenerIniciales(nombre, apellido);
        }

        private void ActualizarAvatar()
        {
            if (picClienteAvatar == null)
                return;

            string nombres = txtNombres == null ? string.Empty : txtNombres.Text;
            string apellidos = txtApellidos == null ? string.Empty : txtApellidos.Text;
            string iniciales = ObtenerIniciales(nombres, apellidos);

            Image old = picClienteAvatar.Image;
            picClienteAvatar.Image = CrearAvatarIniciales(iniciales, picClienteAvatar.Width, picClienteAvatar.Height);
            if (old != null)
                old.Dispose();
        }

        private static string ObtenerIniciales(string nombres, string apellidos)
        {
            string n = string.IsNullOrWhiteSpace(nombres) ? string.Empty : nombres.Trim();
            string a = string.IsNullOrWhiteSpace(apellidos) ? string.Empty : apellidos.Trim();

            char c1 = '\0';
            char c2 = '\0';

            if (n.Length > 0)
                c1 = char.ToUpperInvariant(n[0]);
            if (a.Length > 0)
                c2 = char.ToUpperInvariant(a[0]);

            if (c1 == '\0' && c2 == '\0')
                return "";
            if (c2 == '\0')
                return c1.ToString();
            if (c1 == '\0')
                return c2.ToString();
            return c1.ToString() + c2.ToString();
        }

        private static Bitmap CrearAvatarIniciales(string iniciales, int width, int height)
        {
            int w = width <= 0 ? 120 : width;
            int h = height <= 0 ? 120 : height;

            Bitmap bmp = new Bitmap(w, h);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.Clear(Color.Transparent);

                string txt = string.IsNullOrWhiteSpace(iniciales) ? "?" : iniciales.Trim().ToUpperInvariant();
                Color bg = Color.FromArgb(26, 35, 126);

                int hash = txt.GetHashCode();
                int r = 50 + (Math.Abs(hash) % 150);
                int gr = 50 + (Math.Abs(hash / 7) % 150);
                int b = 50 + (Math.Abs(hash / 13) % 150);
                bg = Color.FromArgb(r, gr, b);

                using (SolidBrush brush = new SolidBrush(bg))
                    g.FillEllipse(brush, 0, 0, w - 1, h - 1);

                using (Pen pen = new Pen(Color.White, 2f))
                    g.DrawEllipse(pen, 1, 1, w - 3, h - 3);

                float fontSize = Math.Min(w, h) * 0.42f;
                using (Font font = new Font("Segoe UI", fontSize, FontStyle.Bold, GraphicsUnit.Pixel))
                using (SolidBrush textBrush = new SolidBrush(Color.White))
                using (StringFormat sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center })
                {
                    RectangleF rect = new RectangleF(0, 0, w, h);
                    g.DrawString(txt, font, textBrush, rect, sf);
                }
            }

            return bmp;
        }

        private void ActualizarUICredito()
        {
            bool tieneCredito = chkTieneCredito != null && chkTieneCredito.Checked;

            if (lblLimiteCredito != null)
                lblLimiteCredito.Visible = tieneCredito;
            if (cboLimiteCreditoTipo != null)
                cboLimiteCreditoTipo.Visible = tieneCredito;
            if (txtLimiteCreditoMonto != null)
                txtLimiteCreditoMonto.Visible = tieneCredito;

            if (!tieneCredito)
            {
                if (cboLimiteCreditoTipo != null)
                    cboLimiteCreditoTipo.SelectedIndex = -1;
                if (txtLimiteCreditoMonto != null)
                    txtLimiteCreditoMonto.Text = "0";
                return;
            }

            if (cboLimiteCreditoTipo != null && cboLimiteCreditoTipo.SelectedIndex < 0)
                cboLimiteCreditoTipo.SelectedIndex = 0; // Ilimitado

            bool esMaximo = cboLimiteCreditoTipo != null &&
                            cboLimiteCreditoTipo.SelectedItem != null &&
                            cboLimiteCreditoTipo.SelectedItem.ToString().Trim().ToLower().StartsWith("de");

            if (txtLimiteCreditoMonto != null)
            {
                txtLimiteCreditoMonto.Enabled = esMaximo;
                if (!esMaximo)
                    txtLimiteCreditoMonto.Text = "0";
            }
        }

        private void CargarListado(bool mostrarMensajes)
        {
            if (lstClientes == null)
                return;

            string texto = txtBuscar == null ? string.Empty : txtBuscar.Text.Trim();
            DataTable dt = DatabaseHelper.ObtenerClientes(texto, mostrarMensajes);

            PrepararImageListClientes();

            lstClientes.BeginUpdate();
            lstClientes.Items.Clear();

            if (dt != null)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    int id = 0;
                    object idObj = dt.Rows[i]["IdCliente"]; if (idObj != null && idObj != DBNull.Value) id = Convert.ToInt32(idObj);

                    string nombre = string.Empty;
                    object nObj = dt.Rows[i]["NombreCompleto"]; if (nObj != null && nObj != DBNull.Value) nombre = nObj.ToString();

                    string correo = string.Empty;
                    if (dt.Columns.Contains("CorreoElectronico"))
                    {
                        object cObj = dt.Rows[i]["CorreoElectronico"]; if (cObj != null && cObj != DBNull.Value) correo = cObj.ToString();
                    }

                    string telefono = string.Empty;
                    if (dt.Columns.Contains("Telefono"))
                    {
                        object tObj = dt.Rows[i]["Telefono"]; if (tObj != null && tObj != DBNull.Value) telefono = tObj.ToString();
                    }

                    string detalle = string.Empty;
                    if (!string.IsNullOrWhiteSpace(correo) && !string.IsNullOrWhiteSpace(telefono))
                        detalle = correo + "  -  " + telefono;
                    else if (!string.IsNullOrWhiteSpace(correo))
                        detalle = correo;
                    else if (!string.IsNullOrWhiteSpace(telefono))
                        detalle = telefono;

                    string iniciales = ObtenerInicialesDesdeNombreCompleto(nombre);
                    string imageKey = id.ToString();
                    if (_imgClientes != null && !_imgClientes.Images.ContainsKey(imageKey))
                    {
                        Bitmap bmp = CrearAvatarIniciales(iniciales, _imgClientes.ImageSize.Width, _imgClientes.ImageSize.Height);
                        _imgClientes.Images.Add(imageKey, bmp);
                    }

                    ListViewItem it = new ListViewItem(id.ToString());
                    if (_imgClientes != null)
                        it.ImageKey = imageKey;
                    it.SubItems.Add(nombre);
                    it.SubItems.Add(detalle);
                    it.Tag = id;
                    lstClientes.Items.Add(it);
                }
            }

            lstClientes.EndUpdate();
        }

        private void CargarListado()
        {
            CargarListado(false);
        }

        private void CargarClienteEnFormulario(int idCliente)
        {
            DataRow r = DatabaseHelper.ObtenerClientePorId(idCliente, false);
            if (r == null)
                return;

            _idClienteActual = idCliente;

            if (txtNombres != null) txtNombres.Text = r.Table.Columns.Contains("Nombres") && r["Nombres"] != DBNull.Value ? r["Nombres"].ToString() : string.Empty;
            if (txtApellidos != null) txtApellidos.Text = r.Table.Columns.Contains("Apellidos") && r["Apellidos"] != DBNull.Value ? r["Apellidos"].ToString() : string.Empty;
            if (txtTelefono != null) txtTelefono.Text = r.Table.Columns.Contains("Telefono") && r["Telefono"] != DBNull.Value ? r["Telefono"].ToString() : string.Empty;
            if (txtCorreo != null) txtCorreo.Text = r.Table.Columns.Contains("CorreoElectronico") && r["CorreoElectronico"] != DBNull.Value ? r["CorreoElectronico"].ToString() : string.Empty;
            if (txtDomicilio1 != null) txtDomicilio1.Text = r.Table.Columns.Contains("Domicilio1") && r["Domicilio1"] != DBNull.Value ? r["Domicilio1"].ToString() : string.Empty;
            if (txtDomicilio2 != null) txtDomicilio2.Text = r.Table.Columns.Contains("Domicilio2") && r["Domicilio2"] != DBNull.Value ? r["Domicilio2"].ToString() : string.Empty;
            if (txtColonia != null) txtColonia.Text = r.Table.Columns.Contains("Colonia") && r["Colonia"] != DBNull.Value ? r["Colonia"].ToString() : string.Empty;
            if (txtCodigoPostal != null) txtCodigoPostal.Text = r.Table.Columns.Contains("CodigoPostal") && r["CodigoPostal"] != DBNull.Value ? r["CodigoPostal"].ToString() : string.Empty;
            if (txtNotas != null) txtNotas.Text = r.Table.Columns.Contains("Notas") && r["Notas"] != DBNull.Value ? r["Notas"].ToString() : string.Empty;

            if (chkTieneCredito != null)
            {
                bool val = false;
                if (r.Table.Columns.Contains("TieneCredito") && r["TieneCredito"] != DBNull.Value)
                    val = Convert.ToBoolean(r["TieneCredito"]);
                chkTieneCredito.Checked = val;
            }

            // Municipio/Estado: si vienen como texto, lo colocamos en el combo si existe
            string mun = r.Table.Columns.Contains("Municipio") && r["Municipio"] != DBNull.Value ? r["Municipio"].ToString() : string.Empty;
            string edo = r.Table.Columns.Contains("Estado") && r["Estado"] != DBNull.Value ? r["Estado"].ToString() : string.Empty;
            if (cboMunicipio != null)
            {
                if (cboMunicipio.Items.Count == 0)
                    cboMunicipio.Items.Add(mun);
                if (!string.IsNullOrWhiteSpace(mun) && cboMunicipio.Items.Contains(mun))
                    cboMunicipio.SelectedItem = mun;
                else if (!string.IsNullOrWhiteSpace(mun))
                {
                    cboMunicipio.Items.Add(mun);
                    cboMunicipio.SelectedItem = mun;
                }
            }
            if (cboEstado != null)
            {
                if (cboEstado.Items.Count == 0)
                    cboEstado.Items.Add(edo);
                if (!string.IsNullOrWhiteSpace(edo) && cboEstado.Items.Contains(edo))
                    cboEstado.SelectedItem = edo;
                else if (!string.IsNullOrWhiteSpace(edo))
                {
                    cboEstado.Items.Add(edo);
                    cboEstado.SelectedItem = edo;
                }
            }

            ActualizarUICredito();
            ActualizarAvatar();
        }

        private void lstClientes_DoubleClick(object sender, EventArgs e)
        {
            if (lstClientes == null)
                return;

            if (lstClientes.SelectedItems == null || lstClientes.SelectedItems.Count == 0)
                return;

            ListViewItem it = lstClientes.SelectedItems[0];
            if (it == null || it.Tag == null)
                return;

            int id = 0;
            try { id = Convert.ToInt32(it.Tag); }
            catch { id = 0; }

            if (id <= 0)
                return;

            CargarClienteEnFormulario(id);
        }

        private void LimpiarFormulario()
        {
            _idClienteActual = 0;
            if (txtNombres != null) txtNombres.Clear();
            if (txtApellidos != null) txtApellidos.Clear();
            if (txtTelefono != null) txtTelefono.Clear();
            if (txtCorreo != null) txtCorreo.Clear();
            if (txtDomicilio1 != null) txtDomicilio1.Clear();
            if (txtDomicilio2 != null) txtDomicilio2.Clear();
            if (txtColonia != null) txtColonia.Clear();
            if (txtCodigoPostal != null) txtCodigoPostal.Clear();
            if (txtNotas != null) txtNotas.Clear();
            if (chkTieneCredito != null) chkTieneCredito.Checked = false;

            if (cboMunicipio != null) cboMunicipio.SelectedIndex = -1;
            if (cboEstado != null) cboEstado.SelectedIndex = -1;

            if (cboLimiteCreditoTipo != null) cboLimiteCreditoTipo.SelectedIndex = -1;
            if (txtLimiteCreditoMonto != null) txtLimiteCreditoMonto.Text = "0";
            ActualizarUICredito();
            ActualizarAvatar();
        }

        private void btnNuevoCliente_Click(object sender, EventArgs e)
        {
            LimpiarFormulario();
            if (txtNombres != null)
                txtNombres.Focus();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            string nombres = txtNombres == null ? string.Empty : txtNombres.Text.Trim();
            if (string.IsNullOrWhiteSpace(nombres))
            {
                MessageBox.Show("El campo 'Nombres' es obligatorio.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (txtNombres != null) txtNombres.Focus();
                return;
            }

            string apellidos = txtApellidos == null ? string.Empty : txtApellidos.Text.Trim();
            string telefono = txtTelefono == null ? string.Empty : txtTelefono.Text.Trim();
            string correo = txtCorreo == null ? string.Empty : txtCorreo.Text.Trim();
            string domicilio1 = txtDomicilio1 == null ? string.Empty : txtDomicilio1.Text.Trim();
            string domicilio2 = txtDomicilio2 == null ? string.Empty : txtDomicilio2.Text.Trim();
            string colonia = txtColonia == null ? string.Empty : txtColonia.Text.Trim();
            string municipio = string.Empty;
            if (cboMunicipio != null)
                municipio = cboMunicipio.SelectedItem != null ? cboMunicipio.SelectedItem.ToString() : cboMunicipio.Text.Trim();

            string estado = string.Empty;
            if (cboEstado != null)
                estado = cboEstado.SelectedItem != null ? cboEstado.SelectedItem.ToString() : cboEstado.Text.Trim();
            string cp = txtCodigoPostal == null ? string.Empty : txtCodigoPostal.Text.Trim();
            string notas = txtNotas == null ? string.Empty : txtNotas.Text.Trim();
            bool tieneCredito = chkTieneCredito != null && chkTieneCredito.Checked;

            if (tieneCredito)
            {
                DialogResult r = MessageBox.Show(
                    "Este cliente quedará con crédito autorizado. ¿Deseas continuar?",
                    "Confirmar crédito",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                if (r != DialogResult.Yes)
                    return;

                bool esMaximo = cboLimiteCreditoTipo != null &&
                                cboLimiteCreditoTipo.SelectedItem != null &&
                                cboLimiteCreditoTipo.SelectedItem.ToString().Trim().ToLower().StartsWith("de");

                if (esMaximo)
                {
                    decimal monto = 0m;
                    string txt = txtLimiteCreditoMonto == null ? string.Empty : txtLimiteCreditoMonto.Text.Trim();
                    if (string.IsNullOrWhiteSpace(txt) || !decimal.TryParse(txt, out monto) || monto <= 0m)
                    {
                        MessageBox.Show("Captura un monto válido para el límite de crédito (mayor a 0).", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        if (txtLimiteCreditoMonto != null)
                            txtLimiteCreditoMonto.Focus();
                        return;
                    }
                }
            }

            int id = DatabaseHelper.GuardarCliente(
                _idClienteActual,
                nombres,
                apellidos,
                telefono,
                correo,
                domicilio1,
                domicilio2,
                colonia,
                municipio,
                estado,
                cp,
                notas,
                tieneCredito,
                true);

            if (id <= 0)
                return;

            _idClienteActual = id;
            CargarListado();
            SeleccionarEnLista(id);
            ActualizarAvatar();
        }

        private void chkTieneCredito_CheckedChanged(object sender, EventArgs e)
        {
            if (chkTieneCredito == null)
                return;

            if (chkTieneCredito.Checked)
            {
                DialogResult r = MessageBox.Show(
                    "¿Autorizar crédito para este cliente?",
                    "Crédito autorizado",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                if (r != DialogResult.Yes)
                    chkTieneCredito.Checked = false;
            }

            ActualizarUICredito();
        }

        private void cboLimiteCreditoTipo_SelectedIndexChanged(object sender, EventArgs e)
        {
            ActualizarUICredito();
        }

        private void txtNombres_TextChanged(object sender, EventArgs e)
        {
            ActualizarAvatar();
        }

        private void txtApellidos_TextChanged(object sender, EventArgs e)
        {
            ActualizarAvatar();
        }

        private void SeleccionarEnLista(int idCliente)
        {
            if (lstClientes == null)
                return;

            for (int i = 0; i < lstClientes.Items.Count; i++)
            {
                ListViewItem it = lstClientes.Items[i];
                if (it != null && it.Tag != null && Convert.ToInt32(it.Tag) == idCliente)
                {
                    it.Selected = true;
                    it.Focused = true;
                    it.EnsureVisible();
                    break;
                }
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            int idEliminar = _idClienteActual;
            if (idEliminar <= 0)
            {
                int tmp = 0;
                if (!TryPedirIdClienteEliminar(out tmp))
                    return;

                idEliminar = tmp;
            }

            DialogResult r = MessageBox.Show("¿Eliminar este cliente?", "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r != DialogResult.Yes)
                return;

            if (DatabaseHelper.EliminarCliente(idEliminar, true))
            {
                if (_idClienteActual == idEliminar)
                    LimpiarFormulario();

                CargarListado(true);
            }
        }

        private static bool TryPedirIdClienteEliminar(out int idCliente)
        {
            idCliente = 0;

            using (Form f = new Form())
            {
                f.Text = "Eliminar cliente";
                f.FormBorderStyle = FormBorderStyle.FixedDialog;
                f.StartPosition = FormStartPosition.CenterParent;
                f.MinimizeBox = false;
                f.MaximizeBox = false;
                f.ShowInTaskbar = false;
                f.ClientSize = new Size(420, 140);

                Label lbl = new Label();
                lbl.AutoSize = false;
                lbl.Text = "Este cliente no está seleccionado en el formulario.\r\n\r\nEscribe el Folio / IdCliente a eliminar:";
                lbl.Location = new Point(12, 10);
                lbl.Size = new Size(396, 60);

                TextBox txt = new TextBox();
                txt.Location = new Point(12, 75);
                txt.Size = new Size(260, 23);

                Button btnOk = new Button();
                btnOk.Text = "Aceptar";
                btnOk.DialogResult = DialogResult.OK;
                btnOk.Location = new Point(284, 73);
                btnOk.Size = new Size(60, 26);

                Button btnCancel = new Button();
                btnCancel.Text = "Cancelar";
                btnCancel.DialogResult = DialogResult.Cancel;
                btnCancel.Location = new Point(348, 73);
                btnCancel.Size = new Size(60, 26);

                f.Controls.Add(lbl);
                f.Controls.Add(txt);
                f.Controls.Add(btnOk);
                f.Controls.Add(btnCancel);

                f.AcceptButton = btnOk;
                f.CancelButton = btnCancel;

                DialogResult r = f.ShowDialog();
                if (r != DialogResult.OK)
                    return false;

                int tmp = 0;
                if (!int.TryParse((txt.Text ?? string.Empty).Trim(), out tmp) || tmp <= 0)
                {
                    MessageBox.Show("Captura un Folio / IdCliente válido.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

                idCliente = tmp;
                return true;
            }
        }

        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            CargarListado();
        }

        private void lstClientes_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstClientes == null || lstClientes.SelectedItems == null || lstClientes.SelectedItems.Count == 0)
                return;

            ListViewItem it = lstClientes.SelectedItems[0];
            if (it == null || it.Tag == null)
                return;

            int id = Convert.ToInt32(it.Tag);
            CargarClienteEnFormulario(id);
        }

        private void btnEliminar_Click_1(object sender, EventArgs e)
        {

        }
    }
}
