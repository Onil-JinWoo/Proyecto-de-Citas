using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace Abarrote
{
    public class ProductSearchForm : Form
    {
        private Panel _hdr;
        private Label _lblHdr;
        private Label _lblHint;
        private TextBox _txtBuscar;
        private DataGridView _dgv;
        private Button _btnAceptar;
        private Button _btnCancelar;

        public string CodigoSeleccionado { get; private set; }

        public ProductSearchForm()
        {
            InitializeUi();
        }

        private void InitializeUi()
        {
            Text = "Búsqueda de Productos";
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.SizableToolWindow;
            MinimizeBox = false;
            MaximizeBox = false;
            ShowInTaskbar = false;
            ClientSize = new Size(820, 520);

            _hdr = new Panel();
            _hdr.Dock = DockStyle.Top;
            _hdr.Height = 30;
            _hdr.BackColor = Color.FromArgb(0, 86, 255);

            _lblHdr = new Label();
            _lblHdr.AutoSize = false;
            _lblHdr.Dock = DockStyle.Fill;
            _lblHdr.TextAlign = ContentAlignment.MiddleLeft;
            _lblHdr.Padding = new Padding(10, 0, 0, 0);
            _lblHdr.ForeColor = Color.White;
            _lblHdr.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            _lblHdr.Text = "BÚSQUEDA DE PRODUCTOS";

            _hdr.Controls.Add(_lblHdr);

            _lblHint = new Label();
            _lblHint.Dock = DockStyle.Top;
            _lblHint.Height = 22;
            _lblHint.Padding = new Padding(10, 0, 0, 0);
            _lblHint.Font = new Font("Segoe UI", 8F);
            _lblHint.Text = "Teclea las primeras letras del producto... (o ingrese el símbolo de % para buscar en toda la descripción)";

            _txtBuscar = new TextBox();
            _txtBuscar.Dock = DockStyle.Top;
            _txtBuscar.Margin = new Padding(10);
            _txtBuscar.Font = new Font("Segoe UI", 10F);
            _txtBuscar.TextChanged += (s, e) => CargarResultados();
            _txtBuscar.KeyDown += txtBuscar_KeyDown;

            _dgv = new DataGridView();
            _dgv.Dock = DockStyle.Fill;
            _dgv.ReadOnly = true;
            _dgv.AllowUserToAddRows = false;
            _dgv.AllowUserToDeleteRows = false;
            _dgv.RowHeadersVisible = false;
            _dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            _dgv.MultiSelect = false;
            _dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            _dgv.CellDoubleClick += (s, e) => AceptarSeleccion();
            _dgv.KeyDown += dgv_KeyDown;

            Panel pnlBottom = new Panel();
            pnlBottom.Dock = DockStyle.Bottom;
            pnlBottom.Height = 55;

            _btnAceptar = new Button();
            _btnAceptar.Text = "ENTER - Aceptar";
            _btnAceptar.Location = new Point(12, 10);
            _btnAceptar.Size = new Size(200, 32);
            _btnAceptar.Click += (s, e) => AceptarSeleccion();

            _btnCancelar = new Button();
            _btnCancelar.Text = "ESC - Cancelar";
            _btnCancelar.Location = new Point(680, 10);
            _btnCancelar.Size = new Size(120, 32);
            _btnCancelar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            _btnCancelar.Click += (s, e) => { DialogResult = DialogResult.Cancel; Close(); };

            pnlBottom.Controls.Add(_btnAceptar);
            pnlBottom.Controls.Add(_btnCancelar);

            Controls.Add(_dgv);
            Controls.Add(pnlBottom);
            Controls.Add(_txtBuscar);
            Controls.Add(_lblHint);
            Controls.Add(_hdr);

            AcceptButton = _btnAceptar;
            CancelButton = _btnCancelar;
        }

        private void txtBuscar_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Down)
            {
                e.SuppressKeyPress = true;
                if (_dgv.Rows.Count > 0)
                {
                    _dgv.Focus();
                    _dgv.ClearSelection();
                    _dgv.Rows[0].Selected = true;
                }
                return;
            }
        }

        private void dgv_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                AceptarSeleccion();
                return;
            }
        }

        private void CargarResultados()
        {
            string texto = _txtBuscar == null ? string.Empty : (_txtBuscar.Text ?? string.Empty).Trim();

            if (string.IsNullOrWhiteSpace(texto))
            {
                _dgv.DataSource = null;
                return;
            }

            DataTable dt = DatabaseHelper.ObtenerProductosCatalogo(texto, null, false);
            if (dt == null)
                dt = new DataTable();

            _dgv.DataSource = dt;

            if (_dgv.Columns.Contains("Codigo"))
                _dgv.Columns["Codigo"].Visible = false;

            if (_dgv.Columns.Contains("Costo"))
                _dgv.Columns["Costo"].Visible = false;

            if (_dgv.Columns.Contains("P. Mayoreo"))
                _dgv.Columns["P. Mayoreo"].Visible = false;

            if (_dgv.Columns.Contains("Inv. Mínimo"))
                _dgv.Columns["Inv. Mínimo"].Visible = false;

            if (_dgv.Columns.Contains("Inv. Máximo"))
                _dgv.Columns["Inv. Máximo"].Visible = false;

            if (_dgv.Columns.Contains("Tipo Venta"))
                _dgv.Columns["Tipo Venta"].Visible = false;

            if (_dgv.Columns.Contains("Existencia"))
                _dgv.Columns["Existencia"].FillWeight = 20;

            if (_dgv.Columns.Contains("P. Venta"))
                _dgv.Columns["P. Venta"].FillWeight = 25;

            if (_dgv.Columns.Contains("Departamento"))
                _dgv.Columns["Departamento"].FillWeight = 25;

            if (_dgv.Columns.Contains("Descripción del Producto"))
                _dgv.Columns["Descripción del Producto"].FillWeight = 80;

            if (_dgv.Rows.Count > 0)
            {
                _dgv.ClearSelection();
                _dgv.Rows[0].Selected = true;
            }
        }

        private void AceptarSeleccion()
        {
            if (_dgv == null || _dgv.SelectedRows == null || _dgv.SelectedRows.Count == 0)
                return;

            DataGridViewRow row = _dgv.SelectedRows[0];
            if (row == null)
                return;

            object cod = row.Cells["Codigo"].Value;
            string codigo = cod == null ? string.Empty : cod.ToString();
            if (string.IsNullOrWhiteSpace(codigo))
                return;

            CodigoSeleccionado = codigo;
            DialogResult = DialogResult.OK;
            Close();
        }
    }
}
