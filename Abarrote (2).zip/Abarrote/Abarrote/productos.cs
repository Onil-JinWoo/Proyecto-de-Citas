using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Drawing;
using System.Windows.Forms;
using System.Configuration;

namespace Abarrote
{
    public partial class productos : Form
    {
        private bool _actualizandoGanancia;
        private bool _modoEdicion;
        private int _idProductoEdicion;
        private Panel _pnlContenido;

        private Panel _pnlPromociones;
        private TextBox _txtPromoNombre;
        private TextBox _txtPromoCodigo;
        private NumericUpDown _numPromoDesde;
        private NumericUpDown _numPromoHasta;
        private NumericUpDown _numPromoPrecio;
        private Button _btnGuardarPromo;
        private DataGridView _dgvPromos;
        private Button _btnEliminarPromo;

        private Panel _pnlPaquete;
        private Panel _pnlProductoHost;
        private Panel _pnlPaqueteHost;
        private Button _btnTabProducto;
        private Button _btnTabPaquete;
        private PackageContentForm _paqueteEditor;
        private DataGridView _dgvPaquete;

        public productos()
        {
            InitializeComponent();

            InicializarNavegacionProductos();

            txtGanancia.ReadOnly = true;
            if (cboGanancia != null)
            {
                cboGanancia.DropDownStyle = ComboBoxStyle.DropDownList;
                cboGanancia.Items.Clear();
                cboGanancia.Items.Add("%");
                cboGanancia.SelectedIndex = 0;
                cboGanancia.Enabled = false;
            }
            txtPrecioCosto.TextChanged += Precio_TextChanged;
            txtPrecioVenta.TextChanged += Precio_TextChanged;
            RecalcularGanancia();

            btnAdministrarDepartamentos.Click += btnAdministrarDepartamentos_Click;

            if (rdbPaquete != null)
                rdbPaquete.CheckedChanged += TipoVenta_CheckedChanged;
            if (rdbUnidad != null)
                rdbUnidad.CheckedChanged += TipoVenta_CheckedChanged;
            if (rdbGranel != null)
                rdbGranel.CheckedChanged += TipoVenta_CheckedChanged;

            InicializarContenidoPaqueteUI();
            ActualizarVisibilidadContenidoPaquete();

            if (btnNuevo != null)
                btnNuevo.Click += btnNuevo_Click;
            if (btnDepartamentosBar != null)
                btnDepartamentosBar.Click += btnDepartamentosBar_Click;
            if (btnModificar != null)
                btnModificar.Click += btnModificar_Click;
            if (btnEliminar != null)
                btnEliminar.Click += btnEliminar_Click;
            if (btnVentasPeriodo != null)
                btnVentasPeriodo.Click += btnVentasPeriodo_Click;
            if (btnPromociones != null)
                btnPromociones.Click += btnPromociones_Click;
            if (btnImportar != null)
                btnImportar.Click += BotonPendiente_Click;
            if (btnCatalogo != null)
                btnCatalogo.Click += btnCatalogo_Click;

            CargarDepartamentos();
        }

        private void btnPromociones_Click(object sender, EventArgs e)
        {
            MostrarVistaPromociones();
        }

        private void TipoVenta_CheckedChanged(object sender, EventArgs e)
        {
            ActualizarVisibilidadContenidoPaquete();
        }

        private void InicializarContenidoPaqueteUI()
        {
            if (pnlNuevoProducto == null)
                return;

            if (_pnlPaquete != null)
                return;

            _btnTabProducto = new Button();
            _btnTabProducto.Text = "Producto";
            _btnTabProducto.FlatStyle = FlatStyle.Flat;
            _btnTabProducto.FlatAppearance.BorderColor = Color.Silver;
            _btnTabProducto.Location = new Point(15, 45);
            _btnTabProducto.Size = new Size(120, 28);
            _btnTabProducto.Click += (s, e) => MostrarTabProducto();

            _btnTabPaquete = new Button();
            _btnTabPaquete.Text = "Contenido del paquete";
            _btnTabPaquete.FlatStyle = FlatStyle.Flat;
            _btnTabPaquete.FlatAppearance.BorderColor = Color.Silver;
            _btnTabPaquete.Location = new Point(140, 45);
            _btnTabPaquete.Size = new Size(170, 28);
            _btnTabPaquete.Click += (s, e) => MostrarTabPaquete();

            _dgvPaquete = new DataGridView();
            _dgvPaquete.Location = new Point(0, 0);
            _dgvPaquete.Size = new Size(10, 10);
            _dgvPaquete.Visible = false;
            _dgvPaquete.AllowUserToAddRows = false;
            _dgvPaquete.AllowUserToDeleteRows = false;
            _dgvPaquete.ReadOnly = true;
            _dgvPaquete.MultiSelect = false;
            _dgvPaquete.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            _dgvPaquete.RowHeadersVisible = false;
            _dgvPaquete.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            DataTable dt = new DataTable();
            dt.Columns.Add("CodigoBarras", typeof(string));
            dt.Columns.Add("Cantidad", typeof(int));
            _dgvPaquete.DataSource = dt;

            _pnlProductoHost = new Panel();
            _pnlProductoHost.Location = new Point(15, 80);
            _pnlProductoHost.Size = new Size(pnlNuevoProducto.Width - 30, pnlNuevoProducto.Height - 140);
            _pnlProductoHost.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;

            _pnlPaqueteHost = new Panel();
            _pnlPaqueteHost.Location = _pnlProductoHost.Location;
            _pnlPaqueteHost.Size = _pnlProductoHost.Size;
            _pnlPaqueteHost.Anchor = _pnlProductoHost.Anchor;
            _pnlPaqueteHost.Visible = false;

            pnlNuevoProducto.Controls.Add(_btnTabProducto);
            pnlNuevoProducto.Controls.Add(_btnTabPaquete);
            pnlNuevoProducto.Controls.Add(_pnlProductoHost);
            pnlNuevoProducto.Controls.Add(_pnlPaqueteHost);

            MoverControlesProductoAHost();
            MostrarTabProducto();
        }

        private void MoverControlesProductoAHost()
        {
            if (pnlNuevoProducto == null || _pnlProductoHost == null)
                return;

            Control[] toMove = new Control[pnlNuevoProducto.Controls.Count];
            pnlNuevoProducto.Controls.CopyTo(toMove, 0);

            for (int i = 0; i < toMove.Length; i++)
            {
                Control c = toMove[i];
                if (c == null)
                    continue;

                if (c == _btnTabProducto || c == _btnTabPaquete || c == _pnlProductoHost || c == _pnlPaqueteHost)
                    continue;

                if (c == btnGuardarProducto || c == btnCancelar || c == lblNuevoProducto)
                    continue;

                pnlNuevoProducto.Controls.Remove(c);
                _pnlProductoHost.Controls.Add(c);
            }
        }

        private void EnsurePaqueteEditorEmbebido()
        {
            if (_pnlPaqueteHost == null)
                return;

            if (_paqueteEditor != null)
                return;

            DataTable dt = _dgvPaquete == null ? null : _dgvPaquete.DataSource as DataTable;
            _paqueteEditor = new PackageContentForm(dt, true);
            _paqueteEditor.TopLevel = false;
            _paqueteEditor.FormBorderStyle = FormBorderStyle.None;
            _paqueteEditor.Dock = DockStyle.Fill;

            _pnlPaqueteHost.Controls.Add(_paqueteEditor);
            _paqueteEditor.Show();
        }

        private void MostrarTabProducto()
        {
            if (_pnlProductoHost != null) _pnlProductoHost.Visible = true;
            if (_pnlPaqueteHost != null) _pnlPaqueteHost.Visible = false;

            EstiloTab(_btnTabProducto, true);
            EstiloTab(_btnTabPaquete, false);
        }

        private void MostrarTabPaquete()
        {
            EnsurePaqueteEditorEmbebido();
            if (_pnlProductoHost != null) _pnlProductoHost.Visible = false;
            if (_pnlPaqueteHost != null) _pnlPaqueteHost.Visible = true;

            EstiloTab(_btnTabProducto, false);
            EstiloTab(_btnTabPaquete, true);
        }

        private static void EstiloTab(Button b, bool active)
        {
            if (b == null)
                return;

            b.BackColor = active ? Color.White : Color.FromArgb(245, 245, 245);
            b.ForeColor = Color.Black;
        }

        private void ActualizarVisibilidadContenidoPaquete()
        {
            if (_btnTabPaquete == null)
                return;

            bool esPaquete = rdbPaquete != null && rdbPaquete.Checked;
            _btnTabPaquete.Visible = esPaquete;
            if (!esPaquete)
                MostrarTabProducto();
        }

        private void InicializarNavegacionProductos()
        {
            if (_pnlContenido != null)
                return;

            _pnlContenido = new Panel();
            _pnlContenido.Dock = DockStyle.None;
            _pnlContenido.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            _pnlContenido.BackColor = this.BackColor;
            _pnlContenido.Padding = new Padding(10);

            this.Controls.Add(_pnlContenido);

            // Layout manual estable (evita que el contenido se "corte" por Dock/Z-Order)
            AjustarLayoutContenido();
            this.Resize -= productos_Resize;
            this.Resize += productos_Resize;

            if (pnlNuevoProducto != null)
            {
                this.Controls.Remove(pnlNuevoProducto);
                pnlNuevoProducto.Parent = _pnlContenido;
                pnlNuevoProducto.Dock = DockStyle.Fill;
                pnlNuevoProducto.Location = new System.Drawing.Point(10, 10);
            }
        }

        private void productos_Resize(object sender, EventArgs e)
        {
            AjustarLayoutContenido();
        }

        private void AjustarLayoutContenido()
        {
            if (_pnlContenido == null)
                return;

            int top = 0;
            if (lblProductosTitle != null && lblProductosTitle.Visible)
                top += lblProductosTitle.Height;
            if (pnlActionBar != null && pnlActionBar.Visible)
                top += pnlActionBar.Height;

            int w = this.ClientSize.Width;
            int h = this.ClientSize.Height - top;
            if (h < 0) h = 0;

            _pnlContenido.Location = new System.Drawing.Point(0, top);
            _pnlContenido.Size = new System.Drawing.Size(w, h);
        }

        private void MostrarVistaNuevo()
        {
            if (_pnlContenido == null)
                return;

            _pnlContenido.Controls.Clear();
            if (pnlNuevoProducto != null)
            {
                pnlNuevoProducto.Parent = _pnlContenido;
                pnlNuevoProducto.Dock = DockStyle.Fill;
                pnlNuevoProducto.Visible = true;
                _pnlContenido.Controls.Add(pnlNuevoProducto);
            }

            CargarDepartamentos();
        }

        private void MostrarVistaPromociones()
        {
            if (_pnlContenido == null)
                return;

            EnsurePromocionesUI();

            _pnlContenido.Controls.Clear();
            if (_pnlPromociones != null)
            {
                _pnlPromociones.Parent = _pnlContenido;
                _pnlPromociones.Dock = DockStyle.Fill;
                _pnlPromociones.Visible = true;
                _pnlContenido.Controls.Add(_pnlPromociones);
            }

            RefrescarPromociones();
        }

        private void EnsurePromocionesUI()
        {
            if (_pnlPromociones != null)
                return;

            _pnlPromociones = new Panel();
            _pnlPromociones.BackColor = Color.White;
            _pnlPromociones.Padding = new Padding(15);

            Label lblNueva = new Label();
            lblNueva.AutoSize = true;
            lblNueva.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblNueva.ForeColor = Color.FromArgb(210, 140, 70);
            lblNueva.Text = "NUEVA PROMOCIÓN";
            lblNueva.Location = new Point(15, 15);

            Label lblNom = new Label();
            lblNom.AutoSize = true;
            lblNom.Font = new Font("Segoe UI", 9F);
            lblNom.Text = "Nombre de la Promoción";
            lblNom.Location = new Point(15, 50);

            _txtPromoNombre = new TextBox();
            _txtPromoNombre.Font = new Font("Segoe UI", 9F);
            _txtPromoNombre.Location = new Point(170, 47);
            _txtPromoNombre.Size = new Size(420, 23);

            Label lblCod = new Label();
            lblCod.AutoSize = true;
            lblCod.Font = new Font("Segoe UI", 9F);
            lblCod.Text = "Código de Barras";
            lblCod.Location = new Point(15, 80);

            _txtPromoCodigo = new TextBox();
            _txtPromoCodigo.Font = new Font("Segoe UI", 9F);
            _txtPromoCodigo.Location = new Point(170, 77);
            _txtPromoCodigo.Size = new Size(220, 23);

            Label lblRango = new Label();
            lblRango.AutoSize = true;
            lblRango.Font = new Font("Segoe UI", 9F);
            lblRango.Text = "Cuando la cantidad vaya desde";
            lblRango.Location = new Point(15, 112);

            _numPromoDesde = new NumericUpDown();
            _numPromoDesde.DecimalPlaces = 2;
            _numPromoDesde.Maximum = 1000000;
            _numPromoDesde.Location = new Point(210, 110);
            _numPromoDesde.Size = new Size(80, 23);

            Label lblHasta = new Label();
            lblHasta.AutoSize = true;
            lblHasta.Font = new Font("Segoe UI", 9F);
            lblHasta.Text = "hasta";
            lblHasta.Location = new Point(300, 112);

            _numPromoHasta = new NumericUpDown();
            _numPromoHasta.DecimalPlaces = 2;
            _numPromoHasta.Maximum = 1000000;
            _numPromoHasta.Location = new Point(345, 110);
            _numPromoHasta.Size = new Size(80, 23);

            Label lblPrecio = new Label();
            lblPrecio.AutoSize = true;
            lblPrecio.Font = new Font("Segoe UI", 9F);
            lblPrecio.Text = "Usar precio unitario";
            lblPrecio.Location = new Point(15, 145);

            _numPromoPrecio = new NumericUpDown();
            _numPromoPrecio.DecimalPlaces = 2;
            _numPromoPrecio.Maximum = 100000000;
            _numPromoPrecio.Location = new Point(170, 143);
            _numPromoPrecio.Size = new Size(120, 23);
            _numPromoPrecio.ThousandsSeparator = true;

            _btnGuardarPromo = new Button();
            _btnGuardarPromo.Text = "✓ Guardar Nueva Promoción";
            _btnGuardarPromo.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            _btnGuardarPromo.FlatStyle = FlatStyle.Flat;
            _btnGuardarPromo.FlatAppearance.BorderColor = Color.Silver;
            _btnGuardarPromo.Location = new Point(170, 175);
            _btnGuardarPromo.Size = new Size(220, 32);
            _btnGuardarPromo.Click += (s, e) => GuardarPromocion();

            Label lblVig = new Label();
            lblVig.AutoSize = true;
            lblVig.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblVig.ForeColor = Color.FromArgb(210, 140, 70);
            lblVig.Text = "PROMOCIONES VIGENTES";
            lblVig.Location = new Point(15, 230);

            _btnEliminarPromo = new Button();
            _btnEliminarPromo.Text = "Eliminar";
            _btnEliminarPromo.Font = new Font("Segoe UI", 9F);
            _btnEliminarPromo.FlatStyle = FlatStyle.Flat;
            _btnEliminarPromo.FlatAppearance.BorderColor = Color.Silver;
            _btnEliminarPromo.Size = new Size(90, 28);
            _btnEliminarPromo.Location = new Point(900, 225);
            _btnEliminarPromo.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            _btnEliminarPromo.Click += (s, e) => EliminarPromocionSeleccionada();

            _dgvPromos = new DataGridView();
            _dgvPromos.Location = new Point(15, 260);
            _dgvPromos.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            _dgvPromos.Size = new Size(980, 340);
            _dgvPromos.AllowUserToAddRows = false;
            _dgvPromos.AllowUserToDeleteRows = false;
            _dgvPromos.ReadOnly = true;
            _dgvPromos.MultiSelect = false;
            _dgvPromos.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            _dgvPromos.RowHeadersVisible = false;
            _dgvPromos.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            _pnlPromociones.Controls.Add(lblNueva);
            _pnlPromociones.Controls.Add(lblNom);
            _pnlPromociones.Controls.Add(_txtPromoNombre);
            _pnlPromociones.Controls.Add(lblCod);
            _pnlPromociones.Controls.Add(_txtPromoCodigo);
            _pnlPromociones.Controls.Add(lblRango);
            _pnlPromociones.Controls.Add(_numPromoDesde);
            _pnlPromociones.Controls.Add(lblHasta);
            _pnlPromociones.Controls.Add(_numPromoHasta);
            _pnlPromociones.Controls.Add(lblPrecio);
            _pnlPromociones.Controls.Add(_numPromoPrecio);
            _pnlPromociones.Controls.Add(_btnGuardarPromo);
            _pnlPromociones.Controls.Add(lblVig);
            _pnlPromociones.Controls.Add(_btnEliminarPromo);
            _pnlPromociones.Controls.Add(_dgvPromos);

            _pnlPromociones.Resize += (s, e) => AjustarLayoutPromociones();
            AjustarLayoutPromociones();
        }

        private void AjustarLayoutPromociones()
        {
            if (_pnlPromociones == null || _dgvPromos == null || _btnEliminarPromo == null)
                return;

            int w = _pnlPromociones.ClientSize.Width;
            int h = _pnlPromociones.ClientSize.Height;

            int gridTop = 260;
            int gridLeft = 15;
            int gridRightPad = 15;
            int gridBottomPad = 15;

            _dgvPromos.Location = new Point(gridLeft, gridTop);
            _dgvPromos.Size = new Size(Math.Max(200, w - gridLeft - gridRightPad), Math.Max(120, h - gridTop - gridBottomPad));

            _btnEliminarPromo.Location = new Point(Math.Max(15, w - gridRightPad - _btnEliminarPromo.Width), _btnEliminarPromo.Location.Y);
        }

        private void GuardarPromocion()
        {
            string nombre = _txtPromoNombre == null ? string.Empty : (_txtPromoNombre.Text ?? string.Empty).Trim();
            string codigo = _txtPromoCodigo == null ? string.Empty : (_txtPromoCodigo.Text ?? string.Empty).Trim();
            decimal desde = _numPromoDesde == null ? 0m : _numPromoDesde.Value;
            decimal hasta = _numPromoHasta == null ? 0m : _numPromoHasta.Value;
            decimal precio = _numPromoPrecio == null ? 0m : _numPromoPrecio.Value;

            if (string.IsNullOrWhiteSpace(nombre))
            {
                MessageBox.Show("Captura el nombre de la promoción.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (_txtPromoNombre != null) _txtPromoNombre.Focus();
                return;
            }
            if (string.IsNullOrWhiteSpace(codigo))
            {
                MessageBox.Show("Captura el código de barras.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (_txtPromoCodigo != null) _txtPromoCodigo.Focus();
                return;
            }
            if (hasta <= 0m || hasta < desde)
            {
                MessageBox.Show("Revisa el rango de cantidad (desde / hasta).", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (precio <= 0m)
            {
                MessageBox.Show("Captura un precio de promoción válido.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string err;
            if (!DatabaseHelper.CrearPromocion(nombre, codigo, desde, hasta, precio, out err))
            {
                MessageBox.Show(string.IsNullOrWhiteSpace(err) ? "No se pudo guardar la promoción." : err, "Promociones", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (_txtPromoNombre != null) _txtPromoNombre.Text = string.Empty;
            if (_txtPromoCodigo != null) _txtPromoCodigo.Text = string.Empty;
            if (_numPromoDesde != null) _numPromoDesde.Value = 0m;
            if (_numPromoHasta != null) _numPromoHasta.Value = 0m;
            if (_numPromoPrecio != null) _numPromoPrecio.Value = 0m;

            RefrescarPromociones();
        }

        private void EliminarPromocionSeleccionada()
        {
            if (_dgvPromos == null || _dgvPromos.CurrentRow == null)
                return;

            object v = _dgvPromos.CurrentRow.Cells["IdPromocion"].Value;
            int id = v == null || v == DBNull.Value ? 0 : Convert.ToInt32(v);
            if (id <= 0)
                return;

            if (MessageBox.Show("¿Desea eliminar (desactivar) la promoción seleccionada?", "Promociones", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            string err;
            if (!DatabaseHelper.DesactivarPromocion(id, out err))
            {
                MessageBox.Show(string.IsNullOrWhiteSpace(err) ? "No se pudo eliminar la promoción." : err, "Promociones", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            RefrescarPromociones();
        }

        private void RefrescarPromociones()
        {
            if (_dgvPromos == null)
                return;

            DataTable dt;
            string err;
            if (!DatabaseHelper.ObtenerPromocionesVigentes(out dt, out err))
            {
                MessageBox.Show(string.IsNullOrWhiteSpace(err) ? "No se pudieron cargar promociones." : err, "Promociones", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            _dgvPromos.DataSource = dt;
            if (_dgvPromos.Columns.Contains("IdPromocion"))
                _dgvPromos.Columns["IdPromocion"].Visible = false;
        }

        public void NavegarANuevo()
        {
            LimpiarFormulario();
            MostrarVistaNuevo();
        }

        private void MostrarSubFormulario(Form form)
        {
            if (_pnlContenido == null || form == null)
                return;

            _pnlContenido.Controls.Clear();

            form.TopLevel = false;
            form.Dock = DockStyle.Fill;
            form.FormBorderStyle = FormBorderStyle.None;

            _pnlContenido.Controls.Add(form);
            form.Show();
        }

        private Form1 ObtenerFormPrincipal()
        {
            Form1 main = this.TopLevelControl as Form1;
            if (main != null)
                return main;

            System.Windows.Forms.Control c = this.Parent;
            while (c != null)
            {
                Form1 f = c as Form1;
                if (f != null)
                    return f;
                c = c.Parent;
            }

            return null;
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            if (!UserSessionState.EsAdmin && !UserSessionState.PermisoAgregarProductos)
            {
                MessageBox.Show("No tienes permiso para agregar productos.", "Permisos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            LimpiarFormulario();
            MostrarVistaNuevo();
        }

        private void btnDepartamentosBar_Click(object sender, EventArgs e)
        {
            btnAdministrarDepartamentos_Click(sender, e);
        }

        private void BotonPendiente_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Función pendiente de configurar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            MostrarSubFormulario(new ModificarProducto());
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            MostrarSubFormulario(new EliminarProducto());
        }

        private void btnVentasPeriodo_Click(object sender, EventArgs e)
        {
            MostrarSubFormulario(new VentasPorPeriodo());
        }

        private void btnCatalogo_Click(object sender, EventArgs e)
        {
            MostrarSubFormulario(new CatalogoProductos());
        }

        private void OcultarPanelesModificarEliminar()
        {
        }

        public void PrepararComoEditorEmbebido()
        {
            if (lblProductosTitle != null)
                lblProductosTitle.Visible = false;
            if (pnlActionBar != null)
                pnlActionBar.Visible = false;

            if (pnlNuevoProducto != null)
            {
                pnlNuevoProducto.Location = new System.Drawing.Point(12, 12);
                pnlNuevoProducto.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;
                pnlNuevoProducto.Width = this.ClientSize.Width - 24;
                pnlNuevoProducto.Height = this.ClientSize.Height - 24;
            }

            OcultarPanelesModificarEliminar();
        }

        public bool CargarProductoParaEdicion(string codigoBarras)
        {
            string codigo = codigoBarras == null ? string.Empty : codigoBarras.Trim();
            if (string.IsNullOrWhiteSpace(codigo))
            {
                MessageBox.Show("Ingrese el código de barras.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            ProductoInfo p = DatabaseHelper.ObtenerProductoPorCodigoBarras(codigo);
            if (p == null)
            {
                MessageBox.Show("Producto no encontrado.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            CargarProductoEnFormulario(p);
            _modoEdicion = true;
            _idProductoEdicion = p.IdProducto;
            if (btnGuardarProducto != null)
                btnGuardarProducto.Text = "✓ Actualizar";
            return true;
        }

        private void CargarProductoEnFormulario(ProductoInfo p)
        {
            if (p == null)
                return;

            string producto = p.Descripcion;
            string desc = string.Empty;
            int ix = producto == null ? -1 : producto.IndexOf(" - ");
            if (ix > 0)
            {
                desc = producto.Substring(ix + 3).Trim();
                producto = producto.Substring(0, ix).Trim();
            }

            txtProducto.Text = producto;
            txtDescripcion.Text = desc;
            txtCodigoBarras.Text = p.CodigoBarras;
            txtPrecioCosto.Text = p.PrecioCosto.ToString("0.00");
            txtPrecioVenta.Text = p.PrecioVenta.ToString("0.00");
            txtPrecioMayoreo.Text = p.PrecioMayoreo.ToString("0.00");
            txtHay.Text = p.StockActual.ToString();
            txtMinimo.Text = p.StockMinimo.ToString();
            txtMaximo.Text = p.StockMaximo.ToString();
            chkUsaInventario.Checked = p.UsaInventario;

            if (string.Equals(p.TipoVenta, "Granel", StringComparison.OrdinalIgnoreCase))
                rdbGranel.Checked = true;
            else if (string.Equals(p.TipoVenta, "Paquete", StringComparison.OrdinalIgnoreCase))
                rdbPaquete.Checked = true;
            else
                rdbUnidad.Checked = true;

            if (!string.IsNullOrWhiteSpace(p.Departamento))
            {
                int sel = -1;
                for (int i = 0; i < cboDepartamento.Items.Count; i++)
                {
                    object it = cboDepartamento.Items[i];
                    string text = it == null ? string.Empty : it.ToString();
                    if (string.Equals(text, p.Departamento, StringComparison.OrdinalIgnoreCase))
                    {
                        sel = i;
                        break;
                    }
                }
                if (sel >= 0)
                    cboDepartamento.SelectedIndex = sel;
            }

            RecalcularGanancia();

            if (string.Equals(p.TipoVenta, "Paquete", StringComparison.OrdinalIgnoreCase) && _dgvPaquete != null)
            {
                DataTable dtPack = DatabaseHelper.ObtenerContenidoPaquete(p.IdProducto);
                DataTable dtLocal = _dgvPaquete.DataSource as DataTable;
                if (dtLocal != null)
                {
                    dtLocal.Rows.Clear();
                    if (dtPack != null)
                    {
                        foreach (System.Data.DataRow rr in dtPack.Rows)
                        {
                            string c = rr["CodigoBarrasItem"] == null ? string.Empty : rr["CodigoBarrasItem"].ToString();
                            int q = rr["Cantidad"] == null || rr["Cantidad"] == DBNull.Value ? 0 : Convert.ToInt32(rr["Cantidad"]);
                            if (string.IsNullOrWhiteSpace(c) || q <= 0)
                                continue;

                            System.Data.DataRow nl = dtLocal.NewRow();
                            nl["CodigoBarras"] = c;
                            nl["Cantidad"] = q;
                            dtLocal.Rows.Add(nl);
                        }
                    }
                }
            }
        }

        private void LimpiarFormulario()
        {
            txtProducto.Clear();
            txtCodigoBarras.Clear();
            txtDescripcion.Clear();
            txtPrecioCosto.Text = "$0.00";
            txtPrecioVenta.Text = "$0.00";
            txtPrecioMayoreo.Text = "$0.00";
            txtHay.Text = "0";
            txtMinimo.Text = "0";
            txtMaximo.Text = "0";

            if (rdbUnidad != null)
                rdbUnidad.Checked = true;
            if (chkUsaInventario != null)
                chkUsaInventario.Checked = true;

            if (cboDepartamento != null && cboDepartamento.Items.Count > 0)
                cboDepartamento.SelectedIndex = 0;

            RecalcularGanancia();
            if (txtProducto != null)
                txtProducto.Focus();

            _modoEdicion = false;
            _idProductoEdicion = 0;
            if (btnGuardarProducto != null)
                btnGuardarProducto.Text = "✓ Guardar";

            if (_dgvPaquete != null)
            {
                DataTable dt = _dgvPaquete.DataSource as DataTable;
                if (dt != null)
                    dt.Rows.Clear();
            }

            ActualizarVisibilidadContenidoPaquete();
        }

        private void btnAdministrarDepartamentos_Click(object sender, EventArgs e)
        {
            MostrarSubFormulario(new departamentos());
        }

        private void CargarDepartamentos()
        {
            System.Data.DataTable dt = DatabaseHelper.ObtenerDepartamentos(false);
            if (dt == null)
            {
                cboDepartamento.DataSource = null;
                cboDepartamento.Items.Clear();
                cboDepartamento.Items.Add("- Sin Departamento -");
                cboDepartamento.SelectedIndex = 0;
                return;
            }

            cboDepartamento.DisplayMember = "Nombre";
            cboDepartamento.ValueMember = "IdDepartamento";
            cboDepartamento.DataSource = dt;
            if (cboDepartamento.Items.Count > 0)
                cboDepartamento.SelectedIndex = 0;
        }

        private void Precio_TextChanged(object sender, EventArgs e)
        {
            RecalcularGanancia();
        }

        private void RecalcularGanancia()
        {
            if (_actualizandoGanancia)
                return;

            _actualizandoGanancia = true;
            try
            {
                decimal costo;
                decimal venta;

                if (!TryParseMoney(txtPrecioCosto.Text, out costo) || costo <= 0)
                {
                    txtGanancia.Text = "0";
                    return;
                }

                if (!TryParseMoney(txtPrecioVenta.Text, out venta) || venta < 0)
                {
                    txtGanancia.Text = "0";
                    return;
                }

                decimal gananciaPct = ((venta - costo) / costo) * 100m;
                if (gananciaPct < 0)
                    gananciaPct = 0;

                txtGanancia.Text = gananciaPct.ToString("0.##", CultureInfo.CurrentCulture);
            }
            finally
            {
                _actualizandoGanancia = false;
            }
        }

        private static bool TryParseMoney(string text, out decimal value)
        {
            value = 0m;
            if (text == null)
                return false;

            string cleaned = text.Trim();
            if (cleaned.Length == 0)
                return false;

            cleaned = cleaned.Replace("$", "").Replace("%", "");
            return decimal.TryParse(cleaned, NumberStyles.Any, CultureInfo.CurrentCulture, out value);
        }

        private void btnGuardarProducto_Click(object sender, EventArgs e)
        {
            try
            {
                // Validar que el campo nombre no esté vacío o solo espacios
                if (string.IsNullOrWhiteSpace(txtProducto.Text))
                {
                    MessageBox.Show("Por favor ingrese el nombre del producto.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtProducto.Focus(); // Poner foco en el campo nombre
                    return;
                }

                // Validar que el nombre tenga al menos 2 caracteres
                if (txtProducto.Text.Trim().Length < 2)
                {
                    MessageBox.Show("El nombre del producto debe tener al menos 2 caracteres.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtProducto.Focus();
                    return;
                }

                // Validar que haya un departamento seleccionado
                if (cboDepartamento.SelectedItem == null)
                {
                    MessageBox.Show("Por favor seleccione un departamento.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    cboDepartamento.Focus();
                    return;
                }

                // Validar que los campos numéricos tengan valores válidos
                decimal precioCosto, ganancia, precioVenta, precioMayoreo;
                int hay, minimo, maximo;

                if (!TryParseMoney(txtPrecioCosto.Text, out precioCosto) || precioCosto < 0)
                {
                    MessageBox.Show("Por favor ingrese un precio de costo válido.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtPrecioCosto.Focus();
                    return;
                }

                if (!TryParseMoney(txtPrecioVenta.Text, out precioVenta) || precioVenta < 0)
                {
                    MessageBox.Show("Por favor ingrese un precio de venta válido.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtPrecioVenta.Focus();
                    return;
                }

                if (!TryParseMoney(txtGanancia.Text, out ganancia) || ganancia < 0)
                {
                    MessageBox.Show("Por favor ingrese un valor válido en el campo 'Ganancia'.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtGanancia.Focus();
                    return;
                }

                if (!TryParseMoney(txtPrecioMayoreo.Text, out precioMayoreo) || precioMayoreo < 0)
                {
                    MessageBox.Show("Por favor ingrese un precio de mayoreo válido.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtPrecioMayoreo.Focus();
                    return;
                }

                if (!int.TryParse(txtHay.Text, out hay) || hay < 0)
                {
                    MessageBox.Show("Por favor ingrese una cantidad válida en el campo 'Hay'.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtHay.Focus();
                    return;
                }

                if (!int.TryParse(txtMinimo.Text, out minimo) || minimo < 0)
                {
                    MessageBox.Show("Por favor ingrese un valor válido en el campo 'Mínimo'.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtMinimo.Focus();
                    return;
                }

                if (!int.TryParse(txtMaximo.Text, out maximo) || maximo < 0)
                {
                    MessageBox.Show("Por favor ingrese un valor válido en el campo 'Máximo'.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtMaximo.Focus();
                    return;
                }

                string descripcionDb = txtProducto.Text.Trim();
                if (!string.IsNullOrWhiteSpace(txtDescripcion.Text))
                {
                    descripcionDb = descripcionDb + " - " + txtDescripcion.Text.Trim();
                }

                string tipoVenta = rdbUnidad.Checked ? "Unidad" : rdbGranel.Checked ? "Granel" : "Paquete";

                bool ok;
                if (_modoEdicion)
                {
                    ok = DatabaseHelper.ActualizarProducto(
                        _idProductoEdicion,
                        descripcionDb,
                        txtCodigoBarras.Text.Trim(),
                        tipoVenta,
                        precioCosto,
                        ganancia,
                        precioVenta,
                        precioMayoreo,
                        cboDepartamento.Text,
                        chkUsaInventario.Checked,
                        hay,
                        minimo,
                        maximo
                    );

                    if (ok)
                        MessageBox.Show("Producto actualizado exitosamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    ok = DatabaseHelper.GuardarProducto(
                        descripcionDb,
                        txtCodigoBarras.Text.Trim(),
                        tipoVenta,
                        precioCosto,
                        ganancia,
                        precioVenta,
                        precioMayoreo,
                        cboDepartamento.Text,
                        chkUsaInventario.Checked,
                        hay,
                        minimo,
                        maximo
                    );

                    if (ok)
                        MessageBox.Show("Producto guardado exitosamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                if (ok && string.Equals(tipoVenta, "Paquete", StringComparison.OrdinalIgnoreCase))
                {
                    int idProducto = _modoEdicion ? _idProductoEdicion : DatabaseHelper.ObtenerIdProductoPorCodigoBarras(txtCodigoBarras.Text.Trim());
                    if (idProducto > 0 && _dgvPaquete != null)
                    {
                        Dictionary<string, int> items = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
                        DataTable dt = _dgvPaquete.DataSource as DataTable;
                        if (dt != null)
                        {
                            foreach (System.Data.DataRow rr in dt.Rows)
                            {
                                string c = rr["CodigoBarras"] == null ? string.Empty : rr["CodigoBarras"].ToString();
                                int q = rr["Cantidad"] == null || rr["Cantidad"] == DBNull.Value ? 0 : Convert.ToInt32(rr["Cantidad"]);
                                if (string.IsNullOrWhiteSpace(c) || q <= 0)
                                    continue;
                                items[c] = q;
                            }
                        }

                        string err;
                        if (!DatabaseHelper.GuardarContenidoPaquete(idProducto, items, out err))
                        {
                            MessageBox.Show(string.Format("No se pudo guardar contenido del paquete: {0}", err), "Paquete", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                    }
                }

                if (ok)
                {
                    OcultarPanelesModificarEliminar();
                    LimpiarFormulario();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(string.Format("Error al guardar producto: {0}", ex.Message), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
