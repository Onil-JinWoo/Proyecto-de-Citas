using System;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace Abarrote
{
    public class CashInBoxForm : Form
    {
        private Label _lblTitle;
        private TextBox _txtMonto;
        private Button _btnRegistrar;

        public decimal EfectivoInicial { get; private set; }

        public CashInBoxForm()
        {
            InitializeUi();
        }

        private void InitializeUi()
        {
            Text = "Dinero en caja";
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = true;
            ClientSize = new Size(360, 170);

            _lblTitle = new Label();
            _lblTitle.AutoSize = false;
            _lblTitle.Location = new Point(12, 15);
            _lblTitle.Size = new Size(336, 35);
            _lblTitle.Font = new Font("Segoe UI", 14F, FontStyle.Regular);
            _lblTitle.TextAlign = ContentAlignment.MiddleCenter;
            _lblTitle.Text = "¿ Efectivo Inicial en Caja ?";

            _txtMonto = new TextBox();
            _txtMonto.Location = new Point(70, 60);
            _txtMonto.Size = new Size(220, 32);
            _txtMonto.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            _txtMonto.TextAlign = HorizontalAlignment.Center;
            _txtMonto.Text = 0m.ToString("C2", CultureInfo.CurrentCulture);
            _txtMonto.Enter += (s, e) =>
            {
                if (_txtMonto != null)
                    _txtMonto.SelectAll();
            };

            _btnRegistrar = new Button();
            _btnRegistrar.Location = new Point(70, 110);
            _btnRegistrar.Size = new Size(220, 32);
            _btnRegistrar.Text = "Registrar dinero inicial en caja";
            _btnRegistrar.Click += btnRegistrar_Click;

            AcceptButton = _btnRegistrar;

            Controls.Add(_lblTitle);
            Controls.Add(_txtMonto);
            Controls.Add(_btnRegistrar);
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            string raw = _txtMonto == null ? string.Empty : (_txtMonto.Text ?? string.Empty).Trim();
            decimal monto = 0m;

            if (!TryParseMonto(raw, out monto) || monto < 0m)
            {
                MessageBox.Show("Captura un monto válido.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (_txtMonto != null)
                {
                    _txtMonto.SelectAll();
                    _txtMonto.Focus();
                }
                return;
            }

            EfectivoInicial = monto;
            CashBoxState.EfectivoEnCaja = monto;

            string err;
            DatabaseHelper.RegistrarMovimientoCaja("FONDO", monto, "Fondo de caja", UserSessionState.Usuario, out err);
            DialogResult = DialogResult.OK;
            Close();
        }

        private static bool TryParseMonto(string value, out decimal monto)
        {
            monto = 0m;
            if (string.IsNullOrWhiteSpace(value))
                return false;

            string v = value.Trim();

            if (decimal.TryParse(v, NumberStyles.Currency, CultureInfo.CurrentCulture, out monto))
                return true;

            // fallback: allow plain number without currency symbol
            return decimal.TryParse(v, NumberStyles.Number, CultureInfo.CurrentCulture, out monto);
        }
    }
}
